package ezieco.eziflow.engine.expression.extension.functions;

import java.util.List;

import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;
import ezieco.eziflow.engine.utils.TypeConverterUtil;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class ConvertFunction implements ExtensionFunctionRegister {

	private static final String GET_INTVALUE = "getIntValue";
	private static final String GET_LONGVALUE = "getLongValue";
	private static final String GET_FLOATVALUE = "getFloatValue";
	private static final String GET_DOUBLEVALUE = "getDoubleValue";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(null, GET_INTVALUE, new GetIntValueFunction());
		functionContext.registerFunction(null, GET_LONGVALUE, new GetLongValueFunction());
		functionContext.registerFunction(null, GET_FLOATVALUE, new GetFloatValueFunction());
		functionContext.registerFunction(null, GET_DOUBLEVALUE, new GetDoubleValueFunction());
	}

	// getIntValue( primitiveValue )
	private class GetIntValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				return TypeConverterUtil.getPrimitiveValueAs(list.get(0), Integer.class);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// getLongValue( primitiveValue )
	private class GetLongValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				return TypeConverterUtil.getPrimitiveValueAs(list.get(0), Long.class);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// getFloatValue( primitiveValue )
	private class GetFloatValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				return TypeConverterUtil.getPrimitiveValueAs(list.get(0), Float.class);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// getDoubleValue( primitiveValue )
	private class GetDoubleValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				return TypeConverterUtil.getPrimitiveValueAs(list.get(0), Double.class);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}
}
