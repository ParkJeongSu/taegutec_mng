package ezieco.eziflow.engine.expression.extension.functions;

import java.util.List;

import org.jaxen.FunctionCallException;
import org.jaxen.jdom.JDOMXPath;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class XmlFunction implements ExtensionFunctionRegister {

	private final String EVALULATE_XPATH = "evaluateXPath";
	private final String SELECT_SINGLENODE = "selectSingleNode";
	private final String SELECT_NODES = "selectNodes";
	private final String GET_ELEMENTTEXT = "getNodeText";
	private final String SET_ELEMENTTEXT = "setNodeText";
	private final String GET_ATTRIBUTETEXT = "getAttributeText";
	private final String SET_ATTRIBUTETEXT = "setAttributeText";
	private final String CREATE_DOCUMENT = "createDocument";
	private final String CREATE_NODE = "createNode";
	private final String CREATE_ATTRIBUTE = "createAttribute";
	private final String ADD_CHILDNODE = "addChildNode";
	private final String ADD_ATTRIBUTE = "addAttribute";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(null, EVALULATE_XPATH, new EvaluateXPathFunction());
		functionContext.registerFunction(null, SELECT_SINGLENODE, new SelectSingleNodeFunction());
		functionContext.registerFunction(null, SELECT_NODES, new SelectNodesFunction());
		functionContext.registerFunction(null, GET_ELEMENTTEXT, new GetNodeTextFunction());
		functionContext.registerFunction(null, SET_ELEMENTTEXT, new SetNodeTextFunction());
		functionContext.registerFunction(null, GET_ATTRIBUTETEXT, new GetAttributeTextFunction());
		functionContext.registerFunction(null, SET_ATTRIBUTETEXT, new SetAttributeTextFunction());
		functionContext.registerFunction(null, CREATE_DOCUMENT, new CreateDocumentFunction());
		functionContext.registerFunction(null, CREATE_NODE, new CreateNodeFunction());
		functionContext.registerFunction(null, CREATE_ATTRIBUTE, new CreateAttributeFunction());
		functionContext.registerFunction(null, ADD_CHILDNODE, new AddChildNodeFunction());
		functionContext.registerFunction(null, ADD_ATTRIBUTE, new AddAttributeFunction());
	}

	// evaluateXPath( 'variableName', 'XPath' )
	private class EvaluateXPathFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0),
						Document.class.getSimpleName() + "/" + Element.class.getSimpleName());
				checkTypeOfValue(target);

				JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1));
				return jdomXPath.evaluate(target);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// selectSingleNode( Element, 'XPath' )
	// selectSingleNode( 'variableName', 'XPath' )
	private class SelectSingleNodeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0),
						Document.class.getSimpleName() + "/" + Element.class.getSimpleName());
				checkTypeOfValue(target);

				JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1));
				return jdomXPath.selectSingleNode(target);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// selectNodes( Element, 'XPath' )
	// selectNodes( 'variableName', 'XPath' )
	private class SelectNodesFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0),
						Document.class.getSimpleName() + "/" + Element.class.getSimpleName());
				checkTypeOfValue(target);

				JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1));
				return jdomXPath.selectNodes(target);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// getNodeText( Element )
	// getNodeText( 'variableName', 'XPath' )
	private class GetNodeTextFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0),
						Document.class.getSimpleName() + "/" + Element.class.getSimpleName());
				checkTypeOfValue(target);

				Element element = null;

				if (list.size() == 1)
					element = (Element) target;
				else {
					JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1));
					element = (Element) jdomXPath.selectSingleNode(target);
				}

				return element.getText();
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// setNodeText( Element, 'value' )
	// setNodeText( 'variableName', 'XPath', 'value' )
	private class SetNodeTextFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0),
						Document.class.getSimpleName() + "/" + Element.class.getSimpleName());
				checkTypeOfValue(target);

				Element element = null;

				if (list.size() == 2) {
					element = (Element) target;
					element.setText((String) list.get(1));
				} else {
					JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1));
					element = (Element) jdomXPath.selectSingleNode(target);
					element.setText((String) list.get(2));
				}

				return true;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// getAttributeText( Attribute )
	// getAttributeText( 'variableName', 'XPath', 'attributeName' )
	private class GetAttributeTextFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0), Attribute.class.getSimpleName());
				checkAttributeTypeOfValue(target);

				Attribute attribute = null;

				if (list.size() == 1)
					attribute = (Attribute) target;
				else {
					JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1) + "/@" + (String) list.get(2));
					attribute = (Attribute) jdomXPath.selectSingleNode(target);
				}

				return attribute.getValue();
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// setAttributeText( Attribute, 'value' )
	// setAttributeText( 'variableName', 'XPath', 'attributeName', 'value' )
	private class SetAttributeTextFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0), Attribute.class.getSimpleName());
				checkAttributeTypeOfValue(target);

				Attribute attribute = null;

				if (list.size() == 2) {
					attribute = (Attribute) target;
					attribute.setValue((String) list.get(1));
				} else {
					JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1) + "/@" + (String) list.get(2));
					attribute = (Attribute) jdomXPath.selectSingleNode(target);
					attribute.setValue((String) list.get(3));
				}

				return true;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// Document createDocument()
	// Document createDocument( 'rootNodeName'[, 'rootNodeText']? )
	private class CreateDocumentFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Document doc = new Document();

				if (list.size() > 0) {
					Element root = new Element((String) list.get(0));

					if (list.size() == 2)
						root.setText((String) list.get(1));

					doc.setRootElement(root);
				}

				return doc;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// Element createNode( 'NodeName'[, 'NodeText']? )
	private class CreateNodeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Element node = new Element((String) list.get(0));

				if (list.size() == 2)
					node.setText((String) list.get(1));

				return node;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// Attribute createAttribute( 'AttributeName', 'AttributeText')
	private class CreateAttributeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				return new Attribute((String) list.get(0), (String) list.get(1));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// void addChildNode( Element, Element )
	// void addChildNode( 'variableName', 'XPath', Element )
	private class AddChildNodeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0),
						Document.class.getSimpleName() + "/" + Element.class.getSimpleName());
				checkTypeOfValue(target);

				Element element = null;

				if (list.size() == 2) {
					element = (Element) target;
					element.addContent((Element) list.get(1));
				} else {
					JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1));
					element = (Element) jdomXPath.selectSingleNode(target);
					element.addContent((Element) list.get(2));
				}

				return true;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// void addAttribute( Element, Attribute )
	// void addAttribute( 'variableName', 'XPath', Attribute )
	private class AddAttributeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object target = getParameterValue(list.get(0),
						Document.class.getSimpleName() + "/" + Element.class.getSimpleName());
				checkTypeOfValue(target);

				Element element = null;

				if (list.size() == 2) {
					element = (Element) target;
					element.setAttribute((Attribute) list.get(1));
				} else {
					JDOMXPath jdomXPath = new JDOMXPath((String) list.get(1));
					element = (Element) jdomXPath.selectSingleNode(target);
					element.setAttribute((Attribute) list.get(2));
				}

				return true;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	protected void checkTypeOfValue(Object value) {
		if (!Document.class.isAssignableFrom(value.getClass()) && !Element.class.isAssignableFrom(value.getClass()))
			throw new ClassCastException(String.format("The first argument(%s) is not an instance of %s",
					value.getClass().getName(), Document.class.getName() + "/" + Element.class.getName()));
	}

	protected void checkAttributeTypeOfValue(Object value) {
		if (!Attribute.class.isAssignableFrom(value.getClass()))
			throw new ClassCastException(String.format("The first argument(%s) is not an instance of %s",
					value.getClass().getName(), Attribute.class.getName()));
	}
}
