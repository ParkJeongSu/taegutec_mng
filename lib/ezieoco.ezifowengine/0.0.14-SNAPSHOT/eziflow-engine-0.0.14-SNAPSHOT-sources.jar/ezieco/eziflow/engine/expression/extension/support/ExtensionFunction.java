package ezieco.eziflow.engine.expression.extension.support;

import java.lang.reflect.Array;
import java.util.List;

import org.jaxen.Context;
import org.jaxen.Function;
import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.utils.TypeConverterUtil;

@SuppressWarnings("rawtypes")
public abstract class ExtensionFunction implements Function {

	@Override
	public Object call(Context context, List args) throws FunctionCallException {
		return call(args);
	}

	protected abstract Object call(List args) throws FunctionCallException;

	public EziFlowRuntimeContext getFlowRuntimeContext() {
		return EziFlowRuntimeContext.currenttRuntimeContext();
	}

	protected Object getParameterValue(Object param, String clsName) {
		Object value = null;

		if (param == null) {
			throw new NullPointerException(
					String.format("The first argument(VariableName or %s value) is null", clsName));
		} else if (param instanceof String) {
			String arg = (String) param;

			if (getFlowRuntimeContext().getVariableData().getVariables().containsKey(arg)) {
				value = getFlowRuntimeContext().getVariableData().getValue(arg);

				if (value == null) {
					throw new NullPointerException(String.format("Variable [%s] is null", arg));
				}
			} else {
				value = arg;
			}
		} else {
			value = param;
		}

		return value;
	}

	protected void checkValueType(Object value, Class<?> clazz) {
		if (Array.class.equals(clazz) && !value.getClass().isArray()) {
			throw new ClassCastException(String.format("The first argument(%s) is not an %s",
					value.getClass().getName(), clazz.getSimpleName()));
		} else if (!Array.class.equals(clazz) && !clazz.isAssignableFrom(value.getClass())) {
			throw new ClassCastException(String.format("The first argument(%s) is not an instance of %s",
					value.getClass().getName(), clazz.getName()));
		}
	}

	protected int getIntValue(Object value) {
		return TypeConverterUtil.getPrimitiveValueAs(value, Integer.class);
	}
}
