package ezieco.eziflow.engine.expression.extension.functions;

import java.util.List;

import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;
import ezieco.eziflow.engine.utils.TypeConverterUtil;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class CommonFunction implements ExtensionFunctionRegister {

	private static final String GET_VARIABLE = "getVariable";
	private static final String SET_VARIABLE = "setVariable";
	private static final String IS_NULL = "isNull";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(GET_VARIABLE, new GetVariableFunction());
		functionContext.registerFunction(SET_VARIABLE, new SetVariableFunction());
		functionContext.registerFunction(IS_NULL, new IsNullFunction());
	}

//	public EziFlowRuntimeContext getFlowRuntimeContext() {
//		return EziFlowRuntimeContext.currenttRuntimeContext();
//	}

	private class GetVariableFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				return super.getFlowRuntimeContext().getVariableData().getValue((String) list.get(0));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	private class SetVariableFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			String vname = (String) list.get(0);
			try {
				Class clazz = super.getFlowRuntimeContext().getVariableData().getVariable(vname).getClazz();
				Object object = TypeConverterUtil.getPrimitiveValueAs(list.get(1), clazz);
				super.getFlowRuntimeContext().getVariableData().setValue(vname, object);

				return Boolean.TRUE;
			} catch (Exception e) {
				return Boolean.FALSE;
			}
		}
	}

	// Boolean isNull( 'variableName' )
	// Boolean isNull( value )
	private class IsNullFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = list.get(0);

				if (obj instanceof String) {
					String arg = (String) obj;

					if (super.getFlowRuntimeContext().getVariableData().getVariables().containsKey(arg)) {
						return Boolean.valueOf(null == super.getFlowRuntimeContext().getVariableData().getValue(arg));
					}
				}

				return Boolean.valueOf(null == obj);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}
}
