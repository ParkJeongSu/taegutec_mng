package ezieco.eziflow.engine.expression.extension;

import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;

public interface ExtensionFunctionRegister {
	public void registerFunction(ExtensionFunctionContext functionContext);
}
