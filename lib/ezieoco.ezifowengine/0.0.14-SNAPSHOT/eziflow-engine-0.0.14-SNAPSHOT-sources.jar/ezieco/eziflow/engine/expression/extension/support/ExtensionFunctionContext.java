package ezieco.eziflow.engine.expression.extension.support;

import org.jaxen.Function;
import org.jaxen.XPathFunctionContext;

public class ExtensionFunctionContext extends XPathFunctionContext {
	public void registerFunction(String localName, Function function) {
		super.registerFunction(null, localName, function);
	}
}
