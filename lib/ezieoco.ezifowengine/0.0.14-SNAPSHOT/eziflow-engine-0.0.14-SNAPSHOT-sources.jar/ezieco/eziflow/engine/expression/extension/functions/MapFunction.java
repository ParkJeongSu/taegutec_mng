package ezieco.eziflow.engine.expression.extension.functions;

import java.util.List;
import java.util.Map;

import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class MapFunction implements ExtensionFunctionRegister {
	private final String ISMAPEMPTY = "isMapEmpty";
	private final String GET_MAPSIZE = "getMapSize";
	private final String GET_MAPVALUE = "getMapValue";
	private final String PUT_MAP_VALUE = "putMapValue";
	private final String MAP_CONTAINSKEY = "mapContainsKey";
	private final String MAP_CONTAINSVALUE = "mapContainsValue";
	private final String REMOVE_MAPVALUE = "removeMapValue";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(null, ISMAPEMPTY, new IsMapEmptyFunction());
		functionContext.registerFunction(null, GET_MAPSIZE, new GetMapSizeFunction());
		functionContext.registerFunction(null, GET_MAPVALUE, new GetMapValueFunction());
		functionContext.registerFunction(null, PUT_MAP_VALUE, new PutMapValueFunction());
		functionContext.registerFunction(null, MAP_CONTAINSKEY, new MapContainsKeyFunction());
		functionContext.registerFunction(null, MAP_CONTAINSVALUE, new MapContainsValueFunction());
		functionContext.registerFunction(null, REMOVE_MAPVALUE, new RemoveMapValueFunction());
	}

	// boolean isMapEmpty( map )
	// boolean isMapEmpty( 'variableName' )
	private class IsMapEmptyFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Map.class.getSimpleName());
				checkValueType(obj, Map.class);
				Map map = (Map) obj;

				return map.isEmpty();
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// int getMapSize( map )
	// int getMapSize( 'variableName' )
	private class GetMapSizeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Map.class.getSimpleName());
				checkValueType(obj, Map.class);
				Map map = (Map) obj;

				return map.size();
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// Object getMapValue( map, key )
	// Object getMapValue( 'variableName', key )
	private class GetMapValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Map.class.getSimpleName());
				checkValueType(obj, Map.class);
				Map map = (Map) obj;

				return map.get(list.get(1));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// void putMapValue( map, key, value )
	// void putMapValue( 'variableName', key, value )
	@SuppressWarnings("unchecked")
	private class PutMapValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Map.class.getSimpleName());
				checkValueType(obj, Map.class);
				Map map = (Map) obj;

				return map.put(list.get(1), list.get(2));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// boolean mapContainsKey( map, key )
	// boolean mapContainsKey( 'variableName', key )
	private class MapContainsKeyFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Map.class.getSimpleName());
				checkValueType(obj, Map.class);
				Map map = (Map) obj;

				return map.containsKey(list.get(1));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// boolean mapContainsValue( map, value )
	// boolean mapContainsValue( 'variableName', value )
	private class MapContainsValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Map.class.getSimpleName());
				checkValueType(obj, Map.class);
				Map map = (Map) obj;

				return map.containsValue(list.get(1));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// Object removeMapValue( map, key )
	// Object removeMapValue( 'variableName', key )
	private class RemoveMapValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Map.class.getSimpleName());
				checkValueType(obj, Map.class);
				Map map = (Map) obj;

				return map.remove(list.get(1));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}
}
