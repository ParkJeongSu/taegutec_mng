package ezieco.eziflow.engine.expression;

import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;

public interface EziFlowExpression {
	Object xpathQuery(String condition);
	
	public void addExtensionFunction(ExtensionFunctionRegister exFunction);
}
