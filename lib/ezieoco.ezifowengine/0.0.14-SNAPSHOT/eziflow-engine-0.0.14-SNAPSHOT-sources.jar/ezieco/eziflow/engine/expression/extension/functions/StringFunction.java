package ezieco.eziflow.engine.expression.extension.functions;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class StringFunction implements ExtensionFunctionRegister {

	private final String ISEMPTY = "isEmpty";
	private final String ISNOTEMPTY = "isNotEmpty";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(ISEMPTY, new IsEmptyFunction());
		functionContext.registerFunction(null, ISNOTEMPTY, new IsNotEmptyFunction());
	}

	// isEmpty('variableName')
	private class IsEmptyFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), String.class.getSimpleName());
				checkValueType(obj, String.class);
				String value = (String) obj;

				return StringUtils.isEmpty(value);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// isNotEmpty('variableName')
	private class IsNotEmptyFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), String.class.getSimpleName());
				checkValueType(obj, String.class);
				String value = (String) obj;

				return StringUtils.isNotEmpty(value);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}
}
