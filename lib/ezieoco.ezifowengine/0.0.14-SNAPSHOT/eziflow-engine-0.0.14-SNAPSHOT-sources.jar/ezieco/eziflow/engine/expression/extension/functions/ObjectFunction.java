package ezieco.eziflow.engine.expression.extension.functions;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.List;

import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;
import ezieco.eziflow.engine.utils.TypeConverterUtil;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class ObjectFunction implements ExtensionFunctionRegister {
	private final String NEWINSTANCE = "newInstance";
	private final String CREATE_VARIABLE = "createVariable";
	private final String GET_FIELD = "getField";
	private final String SET_FILED = "setField";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(null, NEWINSTANCE, new NewInstanceFuction());
		functionContext.registerFunction(null, CREATE_VARIABLE, new CreateVariableFuction());
		functionContext.registerFunction(null, GET_FIELD, new GetFieldFuction());
		functionContext.registerFunction(null, SET_FILED, new SetFieldFunction());
	}

	// Object newInstance( 'type'[, length]? )
	private class NewInstanceFuction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				String type = (String) list.get(0);
				Class cls = TypeConverterUtil.resolveTypeFromClassDescriptor(type);

				Object instance = null;
				if (cls.isArray()) {
					int length = 0;
					if (list.size() == 2)
						length = getIntValue(list.get(1));

					instance = Array.newInstance(cls.getComponentType(), length);
				} else
					instance = cls.newInstance();

				return instance;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// void createVariable( 'variableName'[, length]? )
	private class CreateVariableFuction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				String variableName = (String) list.get(0);
				Class variableClass = null;

				variableClass = getFlowRuntimeContext().getVariableData().getVariable(variableName).getClazz();

				Object instance = null;
				if (variableClass.isArray()) {
					int length = 0;
					if (list.size() == 2)
						length = getIntValue(list.get(1));

					instance = Array.newInstance(variableClass.getComponentType(), length);
				} else
					instance = variableClass.newInstance();

				getFlowRuntimeContext().getVariableData().setValue(variableName, instance);

				return instance;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// Object getFiled( 'variableName', 'fieldName[.fieldName]*' )
	// Object getFiled( object, 'fieldName[.fieldName]*' )
	private class GetFieldFuction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Object.class.getSimpleName());

				String fields = (String) list.get(1);
				String[] fieldNames = fields.split("\\.");

				return getFieldValue(obj, fieldNames);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// void setFiled( 'variableName', 'fieldName[.fieldName]*', value )
	// void setFiled( object, 'fieldName[.fieldName]*', value )
	private class SetFieldFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), Object.class.getSimpleName());

				String fields = (String) list.get(1);
				String[] fieldNames = fields.split("\\.");

				Object value = list.get(2);

				setField(obj, fieldNames, value);

				return Boolean.TRUE;
			} catch (Exception ex) {
				throw new FunctionCallException(ex.toString(), ex);
			}
		}
	}

	private Object getFieldValue(Object obj, String[] fieldNames) throws NoSuchFieldException, IllegalAccessException {
		Field field = null;

		for (String fieldName : fieldNames) {
			field = getFieldIncludingSuperclasses(obj, fieldName);
			obj = field.get(obj);
		}

		return obj;
	}

	private void setField(Object obj, String[] fieldNames, Object value)
			throws NoSuchFieldException, IllegalAccessException {
		Field field = null;
		Object fieldObject = obj;

		for (String fieldName : fieldNames) {
			obj = fieldObject;

			field = getFieldIncludingSuperclasses(fieldObject, fieldName);
			fieldObject = field.get(fieldObject);
		}

		value = TypeConverterUtil.getPrimitiveValueAs(value, field.getType());
		field.set(obj, value);
	}

	private Field getFieldIncludingSuperclasses(Object obj, String fieldName) throws NoSuchFieldException {
		Class<?> currentClass = obj.getClass();

		while (currentClass != null) {
			try {
				Field field = currentClass.getDeclaredField(fieldName);
				field.setAccessible(true);
				return field;
			} catch (NoSuchFieldException e) {
				// 현재 클래스에 필드가 없으면 상위 클래스로 이동
				currentClass = currentClass.getSuperclass();
			}
		}

		throw new NoSuchFieldException("Field '" + fieldName + "' not found in " + obj.getClass());
	}
}
