package ezieco.eziflow.engine.expression.extension.functions;

import java.util.List;

import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class ListFunction implements ExtensionFunctionRegister {

	private final String ADD_LISTVALUE = "addListValue";
	private final String SET_LISTVALUE = "setListValue";
	private final String ISLISTEMPTY = "isListEmpty";
	private final String LIST_CONTAINSVALUE = "listContainsValue";
	private final String GET_LISTSIZE = "getListSize";
	private final String GET_LISTVALUE = "getListValue";
	private final String REMOVE_LISTVALUE = "removeListValue";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(null, ADD_LISTVALUE, new addListValueFunction());
		functionContext.registerFunction(null, SET_LISTVALUE, new SetListValueFunction());
		functionContext.registerFunction(null, ISLISTEMPTY, new IsListEmptyFunction());
		functionContext.registerFunction(null, LIST_CONTAINSVALUE, new ListContainsValueFunction());
		functionContext.registerFunction(null, GET_LISTSIZE, new GetListSizeFunction());
		functionContext.registerFunction(null, GET_LISTVALUE, new GetListValueFunction());
		functionContext.registerFunction(null, REMOVE_LISTVALUE, new RemoveListValueFunction());
	}

	// addListValue( list, value )
	// addListValue( 'variableName', value )
	@SuppressWarnings("unchecked")
	private class addListValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), List.class.getSimpleName());
				checkValueType(obj, List.class);
				List lst = (List) obj;

				lst.add(list.get(1));

				return true;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// setListValue( list, index, value )
	// setListValue( 'variableName', index, value )
	@SuppressWarnings("unchecked")
	private class SetListValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), List.class.getSimpleName());
				checkValueType(obj, List.class);
				List lst = (List) obj;

				lst.set(getIntValue(list.get(1)), list.get(2));

				return null;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// isListEmpty( list )
	// isListEmpty( 'variableName' )
	private class IsListEmptyFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), List.class.getSimpleName());
				checkValueType(obj, List.class);
				List lst = (List) obj;

				return lst.isEmpty();
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// listContainsValue( list, value )
	// listContainsValue( 'variableName', value )
	private class ListContainsValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), List.class.getSimpleName());
				checkValueType(obj, List.class);
				List lst = (List) obj;

				return lst.contains(list.get(1));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// getListSize( list )
	// getListSize( 'variableName' )
	private class GetListSizeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), List.class.getSimpleName());
				checkValueType(obj, List.class);
				List lst = (List) obj;

				return lst.size();
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// getListValue( list, index )
	// getListValue( 'variableName', index )
	private class GetListValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), List.class.getSimpleName());
				checkValueType(obj, List.class);
				List lst = (List) obj;

				return lst.get(getIntValue(list.get(1)));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// removeListValue( list, index )
	// removeListValue( 'variableName', index )
	private class RemoveListValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object obj = getParameterValue(list.get(0), List.class.getSimpleName());
				checkValueType(obj, List.class);
				List lst = (List) obj;

				return lst.remove(getIntValue(list.get(1)));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}
}
