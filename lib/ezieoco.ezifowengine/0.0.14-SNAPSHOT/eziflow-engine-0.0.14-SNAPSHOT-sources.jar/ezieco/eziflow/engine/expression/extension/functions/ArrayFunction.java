package ezieco.eziflow.engine.expression.extension.functions;

import java.lang.reflect.Array;
import java.util.List;

import org.jaxen.FunctionCallException;

import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunction;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;
import ezieco.eziflow.engine.utils.TypeConverterUtil;

@ExtensionHandler
@SuppressWarnings("rawtypes")
public class ArrayFunction implements ExtensionFunctionRegister {

	private static final String SET_ARRAYVALUE = "setArrayValue";
	private static final String GET_ARRAYSIZE = "getArraySize";
	private static final String GET_ARRAYVALUE = "getArrayValue";

	@Override
	public void registerFunction(ExtensionFunctionContext functionContext) {
		functionContext.registerFunction(null, SET_ARRAYVALUE, new SetArrayValueFunction());
		functionContext.registerFunction(null, GET_ARRAYSIZE, new GetArraySizeFunction());
		functionContext.registerFunction(null, GET_ARRAYVALUE, new GetArrayValueFunction());
	}

	// void setArrayValue( array, index, value )
	// void setArrayValue( 'variableName', index, value )
	private class SetArrayValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object array = getParameterValue(list.get(0), Array.class.getSimpleName());
				checkValueType(array, Array.class);

				Object element = TypeConverterUtil.getPrimitiveValueAs(list.get(2),
						array.getClass().getComponentType());
				Array.set(array, getIntValue(list.get(1)), element);

				return true;
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// int getArraySize( array )
	// int getArraySize( 'variableName' )
	private class GetArraySizeFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object array = getParameterValue(list.get(0), Array.class.getSimpleName());
				checkValueType(array, Array.class);

				return Array.getLength(array);
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}

	// ComponentType getArrayValue( array, index )
	// ComponentType getArrayValue( 'variableName', index )
	private class GetArrayValueFunction extends ExtensionFunction {
		public Object call(List list) throws FunctionCallException {
			try {
				Object array = getParameterValue(list.get(0), Array.class.getSimpleName());
				checkValueType(array, Array.class);

				return Array.get(array, getIntValue(list.get(1)));
			} catch (Exception ex) {
				throw new FunctionCallException(ex);
			}
		}
	}
}
