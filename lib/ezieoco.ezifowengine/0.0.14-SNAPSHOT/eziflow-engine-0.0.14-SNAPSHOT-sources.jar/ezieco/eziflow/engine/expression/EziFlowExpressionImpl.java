package ezieco.eziflow.engine.expression;

import java.util.List;

import org.jaxen.FunctionCallException;
import org.jaxen.FunctionContext;
import org.jaxen.XPath;
import org.jaxen.dom.DOMXPath;
import org.jaxen.util.SingletonList;

import ezieco.eziflow.engine.annotation.AnnotationProcessor;
import ezieco.eziflow.engine.annotation.ExtensionHandler;
import ezieco.eziflow.engine.expression.extension.ExtensionFunctionRegister;
import ezieco.eziflow.engine.expression.extension.support.ExtensionFunctionContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EziFlowExpressionImpl implements EziFlowExpression {

	private FunctionContext functionContext = new ExtensionFunctionContext();
	private AnnotationProcessor annotationProcessor = new AnnotationProcessor();

	public EziFlowExpressionImpl() {
		this(true);
	}

	public EziFlowExpressionImpl(boolean createDefaultFunctionSet) {
		if (createDefaultFunctionSet) {

			try {
				List<ExtensionFunctionRegister> list = annotationProcessor.getAnnotatedClassInstances(
						EziFlowExpressionImpl.class.getPackage().getName(), ExtensionHandler.class,
						ExtensionFunctionRegister.class);
				
				log.info("ExtensionFunctionRegister size: {}", list.size());
				
				for(ExtensionFunctionRegister register : list) {
					this.addExtensionFunction(register);
					log.info("ExtensionFunctionRegister: {}", register.getClass().getSimpleName());
				}
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}

//			this.addExtensionFunction(new CommonFunction());
//			this.addExtensionFunction(new ArrayFunction());
//			this.addExtensionFunction(new ConvertFunction());
//			this.addExtensionFunction(new ListFunction());
//			this.addExtensionFunction(new MapFunction());
//			this.addExtensionFunction(new ObjectFunction());
//			this.addExtensionFunction(new StringFunction());
//			this.addExtensionFunction(new XmlFunction());
		}
	}

	@Override
	public void addExtensionFunction(ExtensionFunctionRegister extendedFunction) {
		extendedFunction.registerFunction((ExtensionFunctionContext) this.functionContext);
	}

	@Override
	public Object xpathQuery(String condition) {
		try {
			XPath xpath = new DOMXPath(condition);

			xpath.setFunctionContext(this.functionContext);

			Object object = xpath.selectNodes(null);

			if (object instanceof SingletonList) {
				List<?> list = (List<?>) object;
				if (list.isEmpty()) {
					return null;
				} else {
					return list.get(0);
				}
			} else
				return object;
		} catch (FunctionCallException ex) {
			log.error(ex.getMessage(), ex);
			return null;
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			return null;
		}
	}
}
