package ezieco.eziflow.engine.utils.xml;

import javax.xml.namespace.QName;

import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.utils.EziFlowConst;

public abstract class XmlNodeUtils {

	public static final String XMLNS_NAMESPACE_URI = "http://www.w3.org/2000/xmlns/";

	private XmlNodeUtils() {
	}

	// 개선: node가 Element인 경우 바로 Element의 API를 사용하여 속성 조회
	public static String getAttribute(Node node, String attrName) throws EziFlowException {
		if (node instanceof Element) {
			Element element = (Element) node;
			if (element.hasAttribute(attrName)) {
				return element.getAttribute(attrName);
			}
		} else if (node.getAttributes() != null) {
			Node attr = node.getAttributes().getNamedItem(attrName);
			if (attr != null) {
				return attr.getNodeValue();
			}
		}
		throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.READ_NODE_ERROR)
				.args(attrName, node, "").build());
	}

	public static QName getAttrQName(Node node, String attr) {
		if (node == null || node.getAttributes() == null) {
			throw new EziFlowException("Null node or attributes for attribute: " + attr, node);
		}
		Node attrNode = node.getAttributes().getNamedItem(attr);
		if (attrNode == null) {
			throw new EziFlowException(
					"Can't find attribute " + attr + EziFlowConst.NEWLINE + node + EziFlowConst.NEWLINE, node);
		}
		String val = attrNode.getNodeValue();
		return getQName(val, node);
	}

	public static QName getQName(String prefixPlusName, Node contextNode) {
		int index = prefixPlusName.indexOf(':');
		if (index == -1) {
			// 기본 네임스페이스인 경우 namespaceURI를 빈 문자열로 처리
			return new QName("", prefixPlusName);
		} else {
			String prefix = prefixPlusName.substring(0, index);
			String localPart = prefixPlusName.substring(index + 1);
			String namespaceURI = getNamespaceURIForPrefix(contextNode, prefix);
			return new QName(namespaceURI, localPart, prefix);
		}
	}

	// 개선: 반복문 내에서 예외 발생을 피하고, Element의 hasAttribute를 사용하여 기본 네임스페이스를 확인
	public static String getNamespaceURIForPrefix(Node contextNode, String prefix) {
		Node tempNode;
		switch (contextNode.getNodeType()) {
		case Node.ATTRIBUTE_NODE:
			tempNode = ((Attr) contextNode).getOwnerElement();
			break;
		case Node.ELEMENT_NODE:
			tempNode = contextNode;
			break;
		default:
			tempNode = contextNode.getParentNode();
			break;
		}

		while (tempNode != null && tempNode.getNodeType() == Node.ELEMENT_NODE) {
			Element tempElement = (Element) tempNode;
			String namespaceURI = null;
			if (prefix == null || prefix.isEmpty()) {
				// 기본 네임스페이스: 예외 대신 hasAttribute로 체크
				namespaceURI = tempElement.hasAttribute("xmlns") ? tempElement.getAttribute("xmlns") : null;
			} else {
				namespaceURI = getAttributeByNamespace(tempElement, XMLNS_NAMESPACE_URI, prefix);
			}
			if (namespaceURI != null && !namespaceURI.isEmpty()) {
				return namespaceURI;
			}
			tempNode = tempElement.getParentNode();
		}
		return null;
	}

	public static String getAttributeByNamespace(Element element, String namespaceURI, String localName) {
		Attr attribute = element.getAttributeNodeNS(namespaceURI, localName);
		return attribute == null ? null : attribute.getValue();
	}

	public static String getAttrValueIgnoreExceptionNullReturn(Node node, String attrName) {
		try {
			return getAttribute(node, attrName);
		} catch (Exception e) {
			return null;
		}
	}
}
