package ezieco.eziflow.engine.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BpelFileFinder {

	private static final String DEFAULT_PATTERN = ".bpel";
	private String pattern = DEFAULT_PATTERN;

	public void setFilePattern(String pattern) {
		// 불필요한 '*' 제거
		this.pattern = pattern.replace("*", "");
	}

	public String getFilePattern() {
		return "*" + this.pattern;
	}

	public List<String> getBpelFiles(String root) {
		return getBpelFilesByMaxDepth(root, 1);
	}

	public List<String> getBpelFilesIncludingSubfolders(String root) {
		return getBpelFilesByMaxDepth(root, Integer.MAX_VALUE);
	}

	private List<String> getBpelFilesByMaxDepth(String root, int maxDepth) {
		Path dirPath = Paths.get(root);
		final String fileExtension = this.pattern;
		try (Stream<Path> stream = Files.find(dirPath, maxDepth,
				(path, attr) -> !attr.isDirectory() && path.getFileName().toString().endsWith(fileExtension))) {
			// toAbsolutePath()를 직접 사용하여 불필요한 try-catch 오버헤드 제거
			return stream.map(path -> path.toAbsolutePath().toString()).collect(Collectors.toList());
		} catch (IOException e) {
			log.error("Error finding files in directory {}: {}", root, e.getMessage(), e);
			return Collections.emptyList();
		}
	}
}
