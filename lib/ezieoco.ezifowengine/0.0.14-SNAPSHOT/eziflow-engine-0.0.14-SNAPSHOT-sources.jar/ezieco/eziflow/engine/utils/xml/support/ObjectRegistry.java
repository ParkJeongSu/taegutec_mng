package ezieco.eziflow.engine.utils.xml.support;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ObjectRegistry {
	private final Map<String, Object> reg = new ConcurrentHashMap<>();
	private ObjectRegistry parent;

	public ObjectRegistry() {
	}

	public ObjectRegistry(ObjectRegistry parent) {
		this.parent = parent;
	}

	public void register(String name, Object obj) {
		reg.put(name, obj);
	}

	public void unregister(String name) {
		reg.remove(name);
	}

	public Object lookup(String name) throws IllegalArgumentException {
		Object obj = reg.get(name);

		if (obj == null && parent != null) {
			obj = parent.lookup(name);
			if (obj != null) {
				reg.put(name, obj);
			}
		}

		if (obj == null) {
			throw new IllegalArgumentException("Object '" + name + "' not in registry");
		}

		return obj;
	}
}
