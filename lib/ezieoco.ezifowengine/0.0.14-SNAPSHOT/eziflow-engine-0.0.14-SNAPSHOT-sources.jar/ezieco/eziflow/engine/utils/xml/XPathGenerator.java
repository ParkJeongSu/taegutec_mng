package ezieco.eziflow.engine.utils.xml;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Node;

public abstract class XPathGenerator {

	private XPathGenerator() {
	}

	private static Node findPreviousSiblingOfType(Node node, short nodeType) {
		Node previousNode = node.getPreviousSibling();
		while (previousNode != null) {
			if (previousNode.getNodeType() == nodeType) {
				return previousNode;
			}
			previousNode = previousNode.getPreviousSibling();
		}
		return null;
	}

	private static Node findNextSiblingOfType(Node node, short nodeType) {
		Node nextNode = node.getNextSibling();
		while (nextNode != null) {
			if (nextNode.getNodeType() == nodeType) {
				return nextNode;
			}
			nextNode = nextNode.getNextSibling();
		}
		return null;
	}

	private static String getNodeValueByType(Node node, short nodeType) {
		if (node == null) {
			return ""; // Null safety check
		}

		switch (nodeType) {
		case Node.ELEMENT_NODE:
			return node.getNodeName();
		case Node.TEXT_NODE:
		case Node.PROCESSING_INSTRUCTION_NODE:
			return node.getNodeValue();
		default:
			return "";
		}
	}

	private static short getNodeType(Node node) {
		return (node != null ? node.getNodeType() : -1);
	}

	private static String buildXPath(List<Node> path) {
		StringBuilder xpath = new StringBuilder();
		int length = path.size();

		for (int i = 0; i < length; i++) {
			Node currentNode = path.get(i);
			short nodeType = getNodeType(currentNode);
			String nodeValue = getNodeValueByType(currentNode, nodeType);
			int position = 1;

			Node siblingNode = findPreviousSiblingOfType(currentNode, nodeType);

			while (siblingNode != null) {
				if (nodeType == Node.ELEMENT_NODE && getNodeValueByType(siblingNode, nodeType).equals(nodeValue)) {
					position++;
				} else if (nodeType != Node.ELEMENT_NODE) {
					position++;
				}
				siblingNode = findPreviousSiblingOfType(siblingNode, nodeType);
			}

			boolean hasMatchingSiblings = (position > 1);

			if (!hasMatchingSiblings) {
				siblingNode = findNextSiblingOfType(currentNode, nodeType);
				while (!hasMatchingSiblings && siblingNode != null) {
					if (nodeType == Node.ELEMENT_NODE && getNodeValueByType(siblingNode, nodeType).equals(nodeValue)) {
						hasMatchingSiblings = true;
					} else {
						siblingNode = findNextSiblingOfType(siblingNode, nodeType);
					}
				}
			}

			String step = getXPathStep(nodeType, nodeValue);

			if (step != null && !step.isEmpty()) {
				xpath.append('/').append(step);
			}

			if (hasMatchingSiblings) {
				xpath.append('[').append(position).append(']');
			}
		}

		return xpath.toString();
	}

	private static String getXPathStep(short nodeType, String nodeValue) {
		switch (nodeType) {
		case Node.TEXT_NODE:
			return "text()";
		case Node.PROCESSING_INSTRUCTION_NODE:
			return "processing-instruction()";
		default:
			return nodeValue;
		}
	}

	private static List<Node> buildNodePath(Node node) {
		List<Node> path = new ArrayList<>();

		while (node != null) {
			path.add(0, node);
			node = node.getParentNode();
		}

		return path;
	}

	public static String generateXPath(Node node) throws IllegalArgumentException {
		short nodeType = getNodeType(node);

		switch (nodeType) {
		case Node.ELEMENT_NODE:
		case Node.TEXT_NODE:
		case Node.PROCESSING_INSTRUCTION_NODE:
			return buildXPath(buildNodePath(node));
		case Node.DOCUMENT_NODE:
			return "/";
		default:
			throw new IllegalArgumentException("Only works for element, text, document, and PI nodes.");
		}
	}
}
