package ezieco.eziflow.engine.utils;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class TypeConverterUtil {

	private static final Map<String, Class<?>> TYPE_MAP;
	private static final Map<Class<?>, Class<?>> PRIMITIVE_TO_WRAPPER;
//	private static final Map<Class<?>, Class<?>> WRAPPER_TO_PRIMITIVE;

	static {
		TYPE_MAP = createTypeMap();
		PRIMITIVE_TO_WRAPPER = createPrimitiveToWrapperMap();
//		WRAPPER_TO_PRIMITIVE = createWrapperToPrimitiveMap();
	}

	private static Map<String, Class<?>> createTypeMap() {
		Map<String, Class<?>> tempMap = new HashMap<>();
		tempMap.put("java.lang.string", String.class);
		tempMap.put("java.lang.string[]", String[].class);
		tempMap.put("boolean", boolean.class);
		tempMap.put("boolean[]", boolean[].class);
		tempMap.put("byte", byte.class);
		tempMap.put("byte[]", byte[].class);
		tempMap.put("java.lang.object", Object.class);
		tempMap.put("java.lang.object[]", Object[].class);
		tempMap.put("short", short.class);
		tempMap.put("short[]", short[].class);
		tempMap.put("int", int.class);
		tempMap.put("int[]", int[].class);
		tempMap.put("java.lang.integer[]", Integer[].class);
		tempMap.put("long", long.class);
		tempMap.put("long[]", long[].class);
		tempMap.put("java.lang.long[]", Long[].class);
		tempMap.put("float", float.class);
		tempMap.put("float[]", float[].class);
		tempMap.put("java.lang.float[]", Float[].class);
		tempMap.put("double", double.class);
		tempMap.put("double[]", double[].class);
		tempMap.put("java.lang.double[]", Double[].class);
		tempMap.put("char", char.class);
		tempMap.put("char[]", char[].class);
		tempMap.put("java.lang.character[]", Character[].class);
		return Collections.unmodifiableMap(tempMap);
	}

	private static Map<Class<?>, Class<?>> createPrimitiveToWrapperMap() {
		Map<Class<?>, Class<?>> wrapperMap = new HashMap<>();
		wrapperMap.put(int.class, Integer.class);
		wrapperMap.put(long.class, Long.class);
		wrapperMap.put(double.class, Double.class);
		wrapperMap.put(float.class, Float.class);
		wrapperMap.put(boolean.class, Boolean.class);
		wrapperMap.put(byte.class, Byte.class);
		wrapperMap.put(char.class, Character.class);
		wrapperMap.put(short.class, Short.class);
		return Collections.unmodifiableMap(wrapperMap);
	}

	private static Map<Class<?>, Class<?>> createWrapperToPrimitiveMap() {
		Map<Class<?>, Class<?>> primitiveMap = new HashMap<>();
		PRIMITIVE_TO_WRAPPER.forEach((primitive, wrapper) -> primitiveMap.put(wrapper, primitive));
		return Collections.unmodifiableMap(primitiveMap);
	}

	private static Class<?> getWrapperClass(Class<?> type) {
		return Optional.ofNullable(PRIMITIVE_TO_WRAPPER.get(type)).orElseThrow(
				() -> new IllegalArgumentException("Type " + type.getName() + " is not a recognized primitive type."));
	}

	public static Class<?> resolveTypeFromClassDescriptor(String messageType) {
		Class<?> clazz = TYPE_MAP.get(messageType.toLowerCase());
		if (clazz != null) {
			return clazz;
		}

		String formattedType = messageType.endsWith("[]")
				? "[L" + messageType.substring(0, messageType.length() - 2) + ";"
				: messageType;
		try {
			return Class.forName(formattedType);
		} catch (ClassNotFoundException e) {
			throw new IllegalArgumentException("Type not found: " + messageType, e);
		}
	}

	public static Object getPrimitiveAndStringDefaultValue(Class<?> clazz) {
		if (clazz == String.class)
			return "";
		if (clazz == int.class || clazz == Integer.class)
			return 0;
		if (clazz == long.class || clazz == Long.class)
			return 0L;
		if (clazz == float.class || clazz == Float.class)
			return 0F;
		if (clazz == double.class || clazz == Double.class)
			return 0D;
		if (clazz == boolean.class || clazz == Boolean.class)
			return false;
		if (clazz == short.class || clazz == Short.class)
			return (short) 0;
		if (clazz == char.class || clazz == Character.class)
			return '\u0000';
		if (clazz == byte.class || clazz == Byte.class)
			return (byte) 0;
		return null;
	}

	public static boolean isPrimitiveOrString(Class<?> clazz) {
		return clazz.isPrimitive() || clazz == String.class || PRIMITIVE_TO_WRAPPER.containsKey(clazz)
				|| PRIMITIVE_TO_WRAPPER.containsValue(clazz);
	}

	public static Object getValue(Class<?> clazz, String value) {
		if (value == null)
			return getPrimitiveAndStringDefaultValue(clazz);

		try {
			if (clazz == String.class)
				return value;
			if (clazz == Boolean.class || clazz == boolean.class)
				return Boolean.valueOf(value);
			if (clazz == Byte.class || clazz == byte.class)
				return Byte.valueOf(value);
			if (clazz == Integer.class || clazz == int.class)
				return Integer.valueOf(value);
			if (clazz == Long.class || clazz == long.class)
				return Long.valueOf(value);
			if (clazz == Double.class || clazz == double.class)
				return Double.valueOf(value);
			if (clazz == Float.class || clazz == float.class)
				return Float.valueOf(value);
			if (clazz == Character.class || clazz == char.class)
				return value.charAt(0);
			if (clazz == Short.class || clazz == short.class)
				return Short.valueOf(value);
		} catch (NumberFormatException e) {
			return getPrimitiveAndStringDefaultValue(clazz);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getPrimitiveValueAs(Object value, Class<T> cls) {
		if (value == null) {
			return (T) getPrimitiveAndStringDefaultValue(cls);
		}
		if (cls.isInstance(value)) {
			return (T) value;
		}
		if (value instanceof Number) {
			Number number = (Number) value;
			if (cls == Integer.class || cls == int.class)
				return (T) Integer.valueOf(number.intValue());
			if (cls == Long.class || cls == long.class)
				return (T) Long.valueOf(number.longValue());
			if (cls == Float.class || cls == float.class)
				return (T) Float.valueOf(number.floatValue());
			if (cls == Double.class || cls == double.class)
				return (T) Double.valueOf(number.doubleValue());
			if (cls == Short.class || cls == short.class)
				return (T) Short.valueOf(number.shortValue());
			if (cls == Byte.class || cls == byte.class)
				return (T) Byte.valueOf(number.byteValue());
		}
		return null; // For types not covered by above, return null
	}

	public static boolean isTypeCompatible(Class<?> declaredType, Class<?> valueType) {
		if (declaredType.isPrimitive()) {
			declaredType = getWrapperClass(declaredType);
		}
		if (valueType.isPrimitive()) {
			valueType = getWrapperClass(valueType);
		}
		return declaredType.isAssignableFrom(valueType);
	}
}
