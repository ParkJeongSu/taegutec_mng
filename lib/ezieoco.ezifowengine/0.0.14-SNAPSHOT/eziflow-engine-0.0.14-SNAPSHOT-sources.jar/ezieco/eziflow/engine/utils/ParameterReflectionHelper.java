package ezieco.eziflow.engine.utils;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class ParameterReflectionHelper {

	private ParameterReflectionHelper() {
	}

	public static Class<?> findLastParameterType(Class<?>[] parameterTypes) {
		return (parameterTypes.length > 0) ? parameterTypes[parameterTypes.length - 1] : null;
	}

	public static Object[] getParameters(Class<?>[] declaredParamTypes, Object[] parameters) {
		// 메소드 파라미터를 보관할 초기 리스트 생성
		List<Object> parameterList = new ArrayList<>(declaredParamTypes.length);

		// 가변 인자를 제외한 모든 파라미터 처리
		int regularParamCount = declaredParamTypes.length - 1; // 0 기반 인덱스와 가변 인자를 조정하기 위함
		for (int i = 0; i < regularParamCount; i++) {
			parameterList.add(parameters[i]);
		}

		// 가변 인자 처리
		if (declaredParamTypes.length > 0 && declaredParamTypes[declaredParamTypes.length - 1].isArray()) {
			// 가변 인자 배열의 구성 요소 유형을 결정
			Class<?> varargComponentType = declaredParamTypes[regularParamCount].getComponentType();

			// 가변 인자의 수를 계산
			int varargCount = parameters.length - regularParamCount;

			// 가변 인자 배열 생성
			Object varargArray = Array.newInstance(varargComponentType, varargCount);

			// 가변 인자 배열 채우기
			for (int i = 0; i < varargCount; i++) {
				Array.set(varargArray, i, parameters[regularParamCount + i]);
			}

			// 파라미터 리스트에 가변 인자 배열 추가
			parameterList.add(varargArray);
		} else {
			// 가변 인자가 없지만 파라미터를 추가해야 하는 경우 처리
			if (declaredParamTypes.length == parameters.length) { // 범위 초과를 방지
				parameterList.add(parameters[regularParamCount]);
			}
		}

		return parameterList.toArray();
	}

}
