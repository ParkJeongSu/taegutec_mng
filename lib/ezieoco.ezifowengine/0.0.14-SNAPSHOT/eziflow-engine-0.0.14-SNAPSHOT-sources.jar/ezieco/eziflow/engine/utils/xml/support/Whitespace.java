package ezieco.eziflow.engine.utils.xml.support;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Whitespace {

	public Whitespace(Document doc) {
		removeWhitespace(doc.getDocumentElement());
	}

	public void removeWhitespace(Node node) {
		if (node.getNodeType() == Node.TEXT_NODE) {
			String trimmedText = node.getTextContent().trim();
			if (!node.getTextContent().equals(trimmedText)) {
				node.setTextContent(trimmedText);
			}
		} else {
			NodeList childNodes = node.getChildNodes();
			int length = childNodes.getLength();
			for (int i = 0; i < length; i++) {
				removeWhitespace(childNodes.item(i));
			}
		}
	}
}
