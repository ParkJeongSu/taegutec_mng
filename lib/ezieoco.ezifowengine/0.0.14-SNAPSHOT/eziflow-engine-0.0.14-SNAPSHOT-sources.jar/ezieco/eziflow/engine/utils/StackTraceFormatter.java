package ezieco.eziflow.engine.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;

public class StackTraceFormatter {

	private StackTraceFormatter() {
	}

	public static String getDetailedStackTraceWithComment(Throwable throwable, String errorComment) {
		StringBuilder sb = new StringBuilder(256);
		sb.append(throwable).append(": ").append(errorComment).append(System.lineSeparator());

		Arrays.stream(throwable.getStackTrace())
				.forEach(element -> sb.append("\tat ").append(element).append(System.lineSeparator()));

		return sb.toString();
	}

	public static String getCompleteStackTrace(Throwable throwable) {
		StringWriter sw = new StringWriter();
		try (PrintWriter pw = new PrintWriter(sw)) {
			throwable.printStackTrace(pw);
			return sw.toString();
		}
	}

	public static String getTopStackTraceElements(Throwable throwable, int limit) {
		return Arrays.stream(throwable.getStackTrace()).limit(limit).map(StackTraceElement::toString)
				.reduce((first, second) -> first + System.lineSeparator() + second).orElse("No stack trace available.");
	}
}
