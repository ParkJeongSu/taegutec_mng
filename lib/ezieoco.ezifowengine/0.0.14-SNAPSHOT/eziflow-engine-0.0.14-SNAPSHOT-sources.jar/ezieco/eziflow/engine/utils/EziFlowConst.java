package ezieco.eziflow.engine.utils;

public class EziFlowConst {

	private EziFlowConst() {
	}

	public static final String NEWLINE = System.lineSeparator();

	// TODO 회사 이름을 빼고 변경해야 한다.
	public static final String DEFAULT_TARGETNAMESPACE = "http://bpel.aim.co.kr/bpelj/";
	// TODO 회사 이름을 빼고 변경해야 한다.
	public static final String DEFAULT_EXTENSION = ".bpel";

	public static final String TARGET_NAMESPACE = "targetNamespace";
	public static final String NAME = "name";
	public static final String PREFIX_BEAN = "bean:";

	public static final String PARTNER_LINK = "partnerLink";
	public static final String PARTNER_LINK_TYPE = "partnerLinkType";
	public static final String MESSAGE_TYPE = "messageType";
	public static final String EXPRESSION = "expression";

	public static final String CORRELATION = "correlation";
	public static final String VARIABLE = "variable";
	public static final String FAULT = "fault";
	public static final String FAULT_NAME = "faultName";
	public static final String INPUT = "input";
	public static final String OUTPUT = "output";
	public static final String CONSTANT = "constant";
	public static final String TYPE = "type";
	public static final String TIMEOUT = "timeout";
	public static final String IGNORE_TIMEOUT = "ignoreTimeout";
	public static final String OPERATION = "operation";
	public static final String CONDITION = "condition";

	public static final String COLLECTION = "collection";
	public static final String ELEMENT = "element";
	public static final String INDEX = "index";
	public static final String KEY = "key";

//	public static final String CONTINUE_AFTER_HANDLINGFAULT = "continueAfterHandlingFault";
	public static final String IGNORE_THROW = "ignoreThrow";
	public static final String INVOKE_FORK = "fork";

	public static final String TRUE = "true";

	public static final String FUNCTION = "function";
	public static final String VALUE = "value";
}
