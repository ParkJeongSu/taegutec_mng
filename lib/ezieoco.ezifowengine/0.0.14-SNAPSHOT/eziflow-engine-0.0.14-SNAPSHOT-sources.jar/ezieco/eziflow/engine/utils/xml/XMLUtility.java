package ezieco.eziflow.engine.utils.xml;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import ezieco.eziflow.engine.utils.xml.support.ObjectRegistry;
import ezieco.eziflow.engine.utils.xml.support.Whitespace;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class XMLUtility {

	private static final String XML_DECL_DEFAULT = "UTF-8";
	private static final String XML_DECL_END = "\"?>";
	private static final String NS_URI_XMLNS = "http://www.w3.org/2000/xmlns/";
	private static final String XML_DECL_START = "<?xml version=\"1.0\" encoding=\"";
	private static final String NS_URI_XML = "http://www.w3.org/XML/1998/namespace";

	// 두 가지 모드에 대해 별도의 DocumentBuilderFactory를 생성하여 재사용
	private static final DocumentBuilderFactory namespaceAwareFactory;
	private static final DocumentBuilderFactory nonNamespaceAwareFactory;

	// xmlEncodingMap은 초기화 후 변경되지 않으므로 불변 Map으로 관리
	private final Map<String, String> xmlEncodingMap;

	static {
		// 네임스페이스 인식 DocumentBuilderFactory
		namespaceAwareFactory = DocumentBuilderFactory.newInstance();
		namespaceAwareFactory.setIgnoringElementContentWhitespace(true);
		namespaceAwareFactory.setValidating(false);
		namespaceAwareFactory.setNamespaceAware(true);

		// 네임스페이스 미인식 DocumentBuilderFactory
		nonNamespaceAwareFactory = DocumentBuilderFactory.newInstance();
		nonNamespaceAwareFactory.setIgnoringElementContentWhitespace(true);
		nonNamespaceAwareFactory.setValidating(false);
		nonNamespaceAwareFactory.setNamespaceAware(false);
	}

	private XMLUtility() {
		xmlEncodingMap = initializeEncodingMap();
	}

	private static class SingletonHelper {
		private static final XMLUtility INSTANCE = new XMLUtility();
	}

	public static XMLUtility getInstance() {
		return SingletonHelper.INSTANCE;
	}

	public String documentToString(Document document) throws TransformerException {
		StringWriter writer = new StringWriter();
		Result result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer serializer = tf.newTransformer();
		serializer.transform(new DOMSource(document), result);
		return writer.toString();
	}

	public void saveDocument(String filename, Document doc) throws TransformerException, IOException {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer serializer = tf.newTransformer();
		new Whitespace(doc);
		serializer.transform(new DOMSource(doc), new StreamResult(new FileOutputStream(filename)));
	}

	public Element getRootElement(Document doc) {
		return doc.getDocumentElement();
	}

	public List<Node> getChildElementsByTagName(Node ele, String childEleName) {
		NodeList nl = ele.getChildNodes();
		List<Node> childEles = new ArrayList<>();
		for (int i = 0; i < nl.getLength(); i++) {
			Node node = nl.item(i);
			if (node instanceof Element && nodeNameEquals(node, childEleName)) {
				childEles.add(node);
			}
		}
		return childEles;
	}

	public String getTextValue(Node valueEle) {
		StringBuilder value = new StringBuilder();
		NodeList nl = valueEle.getChildNodes();
		for (int i = 0; i < nl.getLength(); i++) {
			Node item = nl.item(i);
			if ((item instanceof CharacterData && !(item instanceof Comment)) || item instanceof EntityReference) {
				value.append(item.getNodeValue());
			}
		}
		return value.toString();
	}

	public boolean nodeNameEquals(Node node, String desiredName) {
		return desiredName.equals(node.getNodeName()) || desiredName.equals(node.getLocalName());
	}

	public String nodeToString(Node node) {
		StringWriter sw = new StringWriter();
		serializeAsXML(node, sw);
		return sw.toString();
	}

	public void serializeElementAsDocument(Element el, Writer writer) {
		PrintWriter pw = new PrintWriter(writer);
		String javaEncoding = (writer instanceof OutputStreamWriter) ? ((OutputStreamWriter) writer).getEncoding()
				: null;
		String xmlEncoding = java2XMLEncoding(javaEncoding);
		if (xmlEncoding != null) {
			pw.println(XML_DECL_START + xmlEncoding + XML_DECL_END);
		} else {
			pw.println("<?xml version=\"1.0\"?>");
		}
		serializeAsXML(el, writer);
	}

	public void serializeAsXML(Node node, Writer writer) {
		ObjectRegistry namespaceStack = new ObjectRegistry();
		namespaceStack.register("xml", NS_URI_XML);
		PrintWriter pw = new PrintWriter(writer);
		String javaEncoding = (writer instanceof OutputStreamWriter) ? ((OutputStreamWriter) writer).getEncoding()
				: null;
		printNode(node, namespaceStack, pw, java2XMLEncoding(javaEncoding));
	}

	public String normalize(String cdata) {
		StringBuilder sb = new StringBuilder();
		int len = (cdata != null) ? cdata.length() : 0;
		for (int i = 0; i < len; i++) {
			char ch = cdata.charAt(i);
			switch (ch) {
			case '<':
				sb.append("&lt;");
				break;
			case '>':
				sb.append("&gt;");
				break;
			case '&':
				sb.append("&amp;");
				break;
			case '"':
				sb.append("&quot;");
				break;
			case '\n':
				if (i > 0 && sb.charAt(sb.length() - 1) != '\r') {
					sb.append(System.lineSeparator());
				} else {
					sb.append('\n');
				}
				break;
			default:
				sb.append(ch);
				break;
			}
		}
		return sb.toString();
	}

	private void printNode(Node node, ObjectRegistry namespaceStack, PrintWriter out, String xmlEncoding) {
		if (node == null)
			return;
		boolean hasChildren = false;
		switch (node.getNodeType()) {
		case Node.DOCUMENT_NODE:
			printDocumentNode(node, namespaceStack, out, xmlEncoding);
			break;
		case Node.ELEMENT_NODE:
			hasChildren = printElementNode(node, namespaceStack, out, xmlEncoding);
			break;
		case Node.ENTITY_REFERENCE_NODE:
			out.print('&');
			out.print(node.getNodeName());
			out.print(';');
			break;
		case Node.CDATA_SECTION_NODE:
			out.print("<![CDATA[");
			out.print(node.getNodeValue());
			out.print("]]>");
			break;
		case Node.TEXT_NODE:
			out.print(normalize(node.getNodeValue()));
			break;
		case Node.COMMENT_NODE:
			out.print("<!--");
			out.print(node.getNodeValue());
			out.print("-->");
			break;
		case Node.PROCESSING_INSTRUCTION_NODE:
			out.print("<?");
			out.print(node.getNodeName());
			if (node.getNodeValue() != null && node.getNodeValue().length() > 0) {
				out.print(' ');
				out.print(node.getNodeValue());
			}
			out.println("?>");
			break;
		}
		if (node.getNodeType() == Node.ELEMENT_NODE && hasChildren) {
			out.print("</");
			out.print(node.getNodeName());
			out.print('>');
		}
	}

	private void printDocumentNode(Node node, ObjectRegistry namespaceStack, PrintWriter out, String xmlEncoding) {
		if (xmlEncoding != null) {
			out.println(XML_DECL_START + xmlEncoding + XML_DECL_END);
		} else {
			out.println("<?xml version=\"1.0\"?>");
		}
		NodeList children = node.getChildNodes();
		if (children != null) {
			int numChildren = children.getLength();
			for (int i = 0; i < numChildren; i++) {
				printNode(children.item(i), namespaceStack, out, xmlEncoding);
			}
		}
	}

	private boolean printElementNode(Node node, ObjectRegistry namespaceStack, PrintWriter out, String xmlEncoding) {
		namespaceStack = new ObjectRegistry(namespaceStack);
		out.print('<' + node.getNodeName());
		handleNamespace(node, namespaceStack, out);
		NamedNodeMap attrs = node.getAttributes();
		if (attrs != null) {
			int len = attrs.getLength();
			for (int i = 0; i < len; i++) {
				Attr attr = (Attr) attrs.item(i);
				out.print(' ' + attr.getNodeName() + "=\"" + normalize(attr.getValue()) + '\"');
				handleNamespace(attr, namespaceStack, out);
			}
		}
		NodeList children = node.getChildNodes();
		boolean hasChildren = children != null && children.getLength() > 0;
		if (hasChildren) {
			out.print('>');
			for (int i = 0; i < children.getLength(); i++) {
				printNode(children.item(i), namespaceStack, out, xmlEncoding);
			}
		} else {
			out.print("/>");
		}
		return hasChildren;
	}

	private void handleNamespace(Node node, ObjectRegistry namespaceStack, PrintWriter out) {
		String elPrefix = node.getPrefix();
		String elNamespaceURI = node.getNamespaceURI();
		if (elPrefix != null && elNamespaceURI != null) {
			boolean prefixIsDeclared = namespaceStack.lookup(elPrefix) != null
					&& elNamespaceURI.equals(namespaceStack.lookup(elPrefix));
			if (!prefixIsDeclared) {
				printNamespaceDecl(node, namespaceStack, out);
			}
		}
	}

	private void printNamespaceDecl(Node node, ObjectRegistry namespaceStack, PrintWriter out) {
		if (node.getNodeType() == Node.ATTRIBUTE_NODE) {
			printNamespaceDecl(((Attr) node).getOwnerElement(), node, namespaceStack, out);
		} else if (node.getNodeType() == Node.ELEMENT_NODE) {
			printNamespaceDecl((Element) node, node, namespaceStack, out);
		}
	}

	private void printNamespaceDecl(Element owner, Node node, ObjectRegistry namespaceStack, PrintWriter out) {
		String namespaceURI = node.getNamespaceURI();
		String prefix = node.getPrefix();
		if (!(NS_URI_XMLNS.equals(namespaceURI) && "xmlns".equals(prefix))) {
			if (getAttributeNS(owner, NS_URI_XMLNS, prefix) == null) {
				out.print(" xmlns:" + prefix + "=\"" + namespaceURI + '\"');
			}
		} else {
			prefix = node.getLocalName();
			namespaceURI = node.getNodeValue();
		}
		namespaceStack.register(prefix, namespaceURI);
	}

	public String getAttributeNS(Element el, String namespaceURI, String localPart) {
		Attr attr = el.getAttributeNodeNS(namespaceURI, localPart);
		return attr != null ? attr.getValue() : null;
	}

	public String java2XMLEncoding(String javaEnc) {
		return xmlEncodingMap.getOrDefault(javaEnc, XML_DECL_DEFAULT);
	}

	public Node setCData(Document doc, Node node, String cdata) {
		CDATASection cdataSection = doc.createCDATASection(cdata);
		return node.appendChild(cdataSection);
	}

	public Node appendChildElement(Document doc, Node parentNode, String childTag, String childValue) {
		Element childElement = doc.createElement(childTag);
		childElement.setTextContent(childValue);
		return parentNode.appendChild(childElement);
	}

	public Node appendChildElement(Document doc, Node parentNode, String childTag) {
		Element childElement = doc.createElement(childTag);
		return parentNode.appendChild(childElement);
	}

	public Node appendChildCDATAElement(Document doc, Node parentNode, String childTag, String cdata) {
		Node childNode = appendChildElement(doc, parentNode, childTag);
		CDATASection cdataSection = doc.createCDATASection(cdata);
		return childNode.appendChild(cdataSection);
	}

	public Node getXPathNode(Object any, String xpath) throws XPathExpressionException {
		return (Node) XPathFactory.newInstance().newXPath().compile(xpath).evaluate(any, XPathConstants.NODE);
	}

	public String getNodeText(Object any, String xpath) throws XPathExpressionException {
		Node element = (Node) XPathFactory.newInstance().newXPath().compile(xpath).evaluate(any, XPathConstants.NODE);
		return element != null ? element.getNodeValue() : "";
	}

	public List<?> getXPathList(Object any, String xpath) throws XPathExpressionException {
		return (List<?>) XPathFactory.newInstance().newXPath().compile(xpath).evaluate(any, XPathConstants.NODESET);
	}

	public String xsltTransform(String xsl, Document before) throws TransformerException {
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Source xslSource = new StreamSource(new ByteArrayInputStream(xsl.getBytes()));
		Transformer transformer = transformerFactory.newTransformer(xslSource);
		DOMSource source = new DOMSource(before);
		StringWriter stringWriter = new StringWriter();
		StreamResult xmlOutput = new StreamResult(stringWriter);
		transformer.transform(source, xmlOutput);
		return xmlOutput.getWriter().toString();
	}

	public Document createDocument(boolean namespaceAware) {
		try {
			DocumentBuilder builder = namespaceAware ? namespaceAwareFactory.newDocumentBuilder()
					: nonNamespaceAwareFactory.newDocumentBuilder();
			return builder.newDocument();
		} catch (ParserConfigurationException e) {
			log.error("Error creating document: " + e.getMessage(), e);
			return null;
		}
	}

	public Document loadText(String text, boolean namespaceAware)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilder builder = namespaceAware ? namespaceAwareFactory.newDocumentBuilder()
				: nonNamespaceAwareFactory.newDocumentBuilder();
		return builder.parse(new InputSource(new StringReader(text)));
	}

	public Document loadFile(String filename, boolean namespaceAware)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilder builder = namespaceAware ? namespaceAwareFactory.newDocumentBuilder()
				: nonNamespaceAwareFactory.newDocumentBuilder();
		return builder.parse(filename);
	}

	public Document cloneDocument(Document original) {
		try {
			DocumentBuilder builder = namespaceAwareFactory.newDocumentBuilder();
			Document copiedDocument = builder.newDocument();
			Node copiedRoot = copiedDocument.importNode(original.getDocumentElement(), true);
			copiedDocument.appendChild(copiedRoot);
			return copiedDocument;
		} catch (ParserConfigurationException e) {
			log.error("Error cloning document: " + e.getMessage(), e);
			return null;
		}
	}

	private Map<String, String> initializeEncodingMap() {
		Map<String, String> map = new HashMap<>();
		map.put(System.getProperty("file.encoding"), XML_DECL_DEFAULT);
		map.put("UTF8", XML_DECL_DEFAULT);
		map.put("UTF-16", "UTF-16");
		map.put("UnicodeBig", "UTF-16");
		map.put("UnicodeLittle", "UTF-16");
		map.put("ASCII", "US-ASCII");
		map.put("ISO8859_1", "ISO-8859-1");
		map.put("ISO8859_2", "ISO-8859-2");
		map.put("ISO8859_3", "ISO-8859-3");
		map.put("ISO8859_4", "ISO-8859-4");
		map.put("ISO8859_5", "ISO-8859-5");
		map.put("ISO8859_6", "ISO-8859-6");
		map.put("ISO8859_7", "ISO-8859-7");
		map.put("ISO8859_8", "ISO-8859-8");
		map.put("ISO8859_9", "ISO-8859-9");
		map.put("ISO8859_13", "ISO-8859-13");
		map.put("ISO8859_15_FDIS", "ISO-8859-15");
		map.put("GBK", "GBK");
		map.put("Big5", "Big5");
		return Collections.unmodifiableMap(map);
	}
}
