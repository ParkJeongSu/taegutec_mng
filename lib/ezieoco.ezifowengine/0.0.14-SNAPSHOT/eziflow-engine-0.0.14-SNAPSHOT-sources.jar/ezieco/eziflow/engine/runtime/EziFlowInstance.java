package ezieco.eziflow.engine.runtime;

import java.util.concurrent.ExecutionException;

/**
 * 사용자에게 전달되는 오브젝트
 * 
 * @author cglee
 *
 */
public interface EziFlowInstance<V> {

	String getName();

	boolean isCancelled();

	boolean isDone();

	boolean cancel(boolean mayInterruptIfRunning);

	V get() throws InterruptedException, ExecutionException;

//	V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException;
}
