package ezieco.eziflow.engine.runtime.impl;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.runtime.EziFlowInstance;

public class EziFlowInstanceimpl<V> implements EziFlowInstance<V> {

	private final Action action;
	private final Future<V> future;

	public EziFlowInstanceimpl(Action action, Future<V> future) {
		this.action = action;
		this.future = future;
	}

	@Override
	public String getName() {
		return this.action.getName();
	}

	@Override
	public boolean isCancelled() {
		return this.future.isCancelled();
	}

	@Override
	public boolean isDone() {
		return this.future.isDone();
	}

	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		boolean result = this.future.cancel(mayInterruptIfRunning);
		if (result) {
			this.action.getExecuteAction().getFlowRuntimeContext().setTerminate(true);
		}

		return result;
	}

	public V get() throws InterruptedException, ExecutionException {
		return this.future.get();
	}
}
