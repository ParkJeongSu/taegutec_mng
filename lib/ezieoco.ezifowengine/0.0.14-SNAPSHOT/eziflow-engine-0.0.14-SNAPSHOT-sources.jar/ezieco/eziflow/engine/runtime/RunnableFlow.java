package ezieco.eziflow.engine.runtime;

public interface RunnableFlow<V> extends EziFlowInstance<V> {
	void run();
}
