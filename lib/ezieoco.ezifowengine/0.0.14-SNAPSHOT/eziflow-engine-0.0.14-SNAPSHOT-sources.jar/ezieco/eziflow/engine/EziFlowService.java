package ezieco.eziflow.engine;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import ezieco.eziflow.engine.event.external.EventSubscriber;
import ezieco.eziflow.engine.impl.data.ExecutionParams;
import ezieco.eziflow.engine.runtime.EziFlowInstance;

/**
 * 사용자들이 해당 인스턴스를 이용해 workflow 엔진을 조작합니다.
 */
public interface EziFlowService {

	void registerSubscriber(EventSubscriber eventSubscriber);

	EziFlowInstance<?> execute(String qname, Object... arguments) throws InterruptedException, ExecutionException;

	EziFlowInstance<?> executeAsync(String qname, Object... arguments);

	EziFlowInstance<?> execute(ExecutionParams params) throws InterruptedException, ExecutionException;

	EziFlowInstance<?> executeAsync(ExecutionParams params);

	void awake(Object corId, Object... args);

	void shutdown();

	boolean hasCorrelationId(String id);

	List<Runnable> shutdownNow();

	List<Runnable> shutdown(long timeout, TimeUnit unit);
}
