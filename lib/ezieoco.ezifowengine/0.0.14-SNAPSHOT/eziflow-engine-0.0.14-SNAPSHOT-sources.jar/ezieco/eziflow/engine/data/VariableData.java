package ezieco.eziflow.engine.data;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;

import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.data.support.VarDataItem;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.utils.TypeConverterUtil;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class VariableData {

	private final EziFlowRuntimeContext flowRuntimeContext;

	@Getter
	private final Map<String, VarDataItem> variables = new ConcurrentHashMap<>();

	public void registerVariable(String variableName, Class<?> clazz, Object value, String expression) {
		validateVariableName(variableName);
		checkTypeCompatibility(variableName, clazz, value);
		variables.put(variableName, VarDataItem.builder().varName(variableName).clazz(clazz).dataObject(value)
				.expression(expression).build());
	}

	public VarDataItem getVariable(String variableName) {
		validateVariableName(variableName);
		return findVariableOrThrow(variableName);
	}

	public Object getValue(String variableName) {
		validateVariableName(variableName);
		return findVariableOrThrow(variableName).getDataObject();
	}

	public void setValue(String variableName, Object newValue) {
		validateVariableName(variableName);
		VarDataItem varDataItem = findVariableOrThrow(variableName);
		checkTypeCompatibility(variableName, varDataItem.getClazz(), newValue);
		varDataItem.setDataObject(newValue);
	}

	public void setValues(List<InputData> variableNames, Object[] values) {
		if (variableNames.size() != values.length) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.INVALID_ARGUMENT)
					.args(variableNames, values.length).build());
		}

		IntStream.range(0, variableNames.size()).forEach(i -> setValue(variableNames.get(i).getInput(), values[i]));
	}

	private void validateVariableName(String variableName) {
		if (StringUtils.isEmpty(variableName)) {
			throw new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.EMPTY_VARIABLENAME).build());
		}
	}

	private VarDataItem findVariableOrThrow(String variableName) {
		VarDataItem varDataItem = variables.get(variableName);
		if (varDataItem == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.VARIABLE_NEED_SET)
					.args(variableName, flowRuntimeContext.getExecuteAction().getName()).build());
		}
		return varDataItem;
	}

	private void checkTypeCompatibility(String variableName, Class<?> declaredType, Object value) {
		if (value != null && !TypeConverterUtil.isTypeCompatible(declaredType, value.getClass())) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.INVALID_VARIABLETYPE)
					.args(value.getClass(), variableName, declaredType).build());
		}
	}
}
