package ezieco.eziflow.engine.data;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.impl.FaultHandler;
import lombok.Data;

@Data
public class FaultData {
	private FaultHandler faultHandler;
	private Action faultAction;
	private String faultName;
	private Throwable throwable;
}

