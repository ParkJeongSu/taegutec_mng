package ezieco.eziflow.engine.data;

import org.apache.commons.lang3.StringUtils;

import ezieco.eziflow.engine.utils.TypeConverterUtil;
import lombok.Data;

@Data
public class InputData {

	private boolean isVariable = false;
	private String input;
	private Class<? extends Object> type;

	public InputData(String input, String type, boolean isVariable) {
		this.input = input;

		if ((isVariable && StringUtils.isNotEmpty(type)) || !isVariable)
			this.type = TypeConverterUtil.resolveTypeFromClassDescriptor(type);

		this.isVariable = isVariable;
	}
}
