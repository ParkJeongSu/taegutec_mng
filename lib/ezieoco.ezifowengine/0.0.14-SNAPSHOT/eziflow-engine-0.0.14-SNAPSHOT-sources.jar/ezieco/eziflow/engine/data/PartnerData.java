package ezieco.eziflow.engine.data;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.namespace.QName;

import ezieco.eziflow.engine.core.EziFlowAppContext;
import ezieco.eziflow.engine.data.support.PartnerDataItem;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;

public class PartnerData {

	private final EziFlowAppContext flowAppContext;
	private Map<String, PartnerDataItem> partnerDataItems = new ConcurrentHashMap<>();

	public PartnerData(EziFlowAppContext flowAppContext) {
		this.flowAppContext = flowAppContext;
	}

	public void registerPartnerData(String partnerName, String partnerValue, QName qName) {
		partnerDataItems.put(partnerName,
				PartnerDataItem.builder().partnerValue(partnerValue).partnerQName(qName).build());
	}

	public boolean isBean(String partnerName) {
		PartnerDataItem partnerDataItem = partnerDataItems.get(partnerName);
		if (partnerDataItem == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NULL_POINTER_ERROR)
					.args(partnerName).build());
		}
		return partnerDataItem.isBean();
	}

	public Object getBean(String partnerName) {
		PartnerDataItem partnerDataItem = partnerDataItems.get(partnerName);
		if (partnerDataItem == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NULL_POINTER_ERROR)
					.args(partnerName).build());
		}
		return partnerDataItem.getDataObject();
	}

	public String getWFNamespace(String partnerName) {
		PartnerDataItem partnerDataItem = partnerDataItems.get(partnerName);
		if (partnerDataItem == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NULL_POINTER_ERROR)
					.args(partnerName).build());
		}
		return partnerDataItem.getWorkflowNamespace();
	}

	public void initializeBeansAndSetReferenceWF() {
		partnerDataItems.values().forEach(partnerDataItem -> {
			if (partnerDataItem.isBean()) {
				partnerDataItem.setDataObject(flowAppContext.getBean(partnerDataItem.getPartnerQName().getLocalPart()));
			} else {
				partnerDataItem.setDataObject(null);
			}
		});
	}
}
