package ezieco.eziflow.engine.data.support;

import javax.xml.namespace.QName;

import ezieco.eziflow.engine.utils.EziFlowConst;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PartnerDataItem {
	private QName partnerQName;
	private String partnerValue;
	private Object dataObject;

	public boolean isBean() {
		return partnerValue != null && partnerValue.startsWith(EziFlowConst.PREFIX_BEAN);
	}

	public String getWorkflowNamespace() {
		if (partnerValue == null || !partnerValue.contains(":")) {
			throw new IllegalArgumentException("Invalid partner value format.");
		}
		String service = partnerValue.substring(partnerValue.indexOf(":") + 1);
		return String.format("%s%s/", partnerQName.getNamespaceURI(), service);
	}
}
