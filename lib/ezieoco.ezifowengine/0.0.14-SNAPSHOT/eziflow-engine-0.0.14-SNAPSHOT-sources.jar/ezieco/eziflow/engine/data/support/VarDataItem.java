package ezieco.eziflow.engine.data.support;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class VarDataItem {
	private Class<? extends Object> clazz;
	private Object dataObject;
	private String varName;
	private String expression;
}
