package ezieco.eziflow.engine.data;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;

public class InputDataCollection {
	private final List<InputData> inputs = new CopyOnWriteArrayList<>();

	public int size() {
		return this.inputs.size();
	}

	public List<InputData> getInputs() {
		return Collections.unmodifiableList(inputs);
	}

	public InputData getInput(int index) {
		return this.inputs.get(index);
	}

	public void addInputs(Node node) {
		String variableName = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.VARIABLE);

		InputData inputData = null;

		if (StringUtils.isNotEmpty(variableName)) {
			String superClass = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.TYPE);
			inputData = new InputData(variableName, superClass, true);
		} else {
			String constant = XmlNodeUtils.getAttribute(node, EziFlowConst.CONSTANT);
			String constantType = this.getAttrValueWithNullException(node, EziFlowConst.TYPE);
			inputData = new InputData(constant, constantType, false);
		}

		if (inputs.contains(inputData)) {
			throw new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.DUPLICATE_INPUT).args(variableName).build());
		}

		inputs.add(inputData);
	}

	private String getAttrValueWithNullException(Node node, String attrName) {
		String attrValue = XmlNodeUtils.getAttribute(node, attrName);
		if (StringUtils.isEmpty(attrValue)) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.READ_NODE_ERROR)
					.args(attrName, node, StringUtils.EMPTY).build(), node);
		}

		return attrValue;
	}
}
