package ezieco.eziflow.engine.data;

import java.time.LocalDateTime;

import lombok.Getter;

public class CorrelationRecord {

	@Getter
	private final Object[] awakeArgs;
	@Getter
	private final LocalDateTime creationTime;

	public CorrelationRecord(Object... awakeArgs) {
		this.awakeArgs = awakeArgs;
		this.creationTime = LocalDateTime.now();
	}
}
