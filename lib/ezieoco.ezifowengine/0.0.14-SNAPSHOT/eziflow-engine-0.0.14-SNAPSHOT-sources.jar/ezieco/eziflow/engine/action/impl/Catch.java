package ezieco.eziflow.engine.action.impl;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.fault.Faultable;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;

public class Catch extends AbstractAction implements Faultable {

	private Action faultAction;

	public Catch(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.CATCH_ERROR, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		if (node.getNodeName().equals(ActionEnum.CATCH_ERROR.getName())) {
			String faultName = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.FAULT_NAME);
			if (faultName == null) {
				throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.READ_NODE_ERROR)
						.args(EziFlowConst.FAULT_NAME, node, "").build());
			}

			super.setFaultName(faultName);
		}

		super.read(node);

		return this;
	}

	@Override
	protected void work() {
		super.execute();
	}

	@Override
	public Action getFaultAction() {
		return this.faultAction;
	}

	@Override
	public void setFaultAction(Action action) {
		this.faultAction = action;
	}
}
