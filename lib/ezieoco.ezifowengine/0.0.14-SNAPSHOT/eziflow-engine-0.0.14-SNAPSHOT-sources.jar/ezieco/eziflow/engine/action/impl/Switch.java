package ezieco.eziflow.engine.action.impl;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;

public class Switch extends AbstractAction {

	private Otherwise otherwise = null;
	private List<Case> caseList = new ArrayList<Case>();

	public Switch(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.SWITCH_STATE, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
//		List<Action> actionList = new ArrayList<Action>();
//
//		NodeList nlArgs = node.getChildNodes();
//		IntStream.range(0, nlArgs.getLength()).mapToObj(nlArgs::item)
//				.filter(childNode -> childNode.getNodeType() == Node.ELEMENT_NODE).map(childNode -> {
//					Action activity = ActionBuilder.createAction(childNode, flowRuntimeContext);
//					return activity != null ? activity.init(childNode) : null;
//				}).filter(Objects::nonNull).forEach(actionList::add);

		super.read(node);
		List<Action> actionList = super.getActionList();
		for (Action action : actionList) {
			if (action instanceof Otherwise) {
				otherwise = (Otherwise) action;
			} else if (action instanceof Case) {
				this.caseList.add((Case) action);
			}
		}

		return this;
	}

	@Override
	protected void work() {
		super.currentThread = Thread.currentThread();

		for (Case action : this.caseList) {
			if (action.getConditionResult()) {
				action.run();
				return;
			}
		}

		if (otherwise == null) {
			return;
		} else {
			otherwise.run();
		}
	}

}
