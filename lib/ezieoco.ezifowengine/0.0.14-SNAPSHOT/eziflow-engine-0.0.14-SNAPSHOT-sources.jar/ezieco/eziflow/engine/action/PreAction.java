package ezieco.eziflow.engine.action;

@FunctionalInterface
public interface PreAction {
	void execute();
}
