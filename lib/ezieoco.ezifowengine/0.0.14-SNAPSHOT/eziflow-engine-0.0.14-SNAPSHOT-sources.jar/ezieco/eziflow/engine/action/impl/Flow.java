package ezieco.eziflow.engine.action.impl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.concurrent.ManagedThreadPool;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;
import ezieco.eziflow.engine.event.internal.data.EziFlowInternalEvent;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Flow extends AbstractAction {

	private static final String TYPE_END = "END";
	private static final String TYPE_EXCEPTION = "EXCEPTION";

	private static final int FLOW_TIMEOUT = 60 * 60 * 1000;
	private static final String FLOW_TIMEOUT_MESSAGE = String.format("Flow Timeout.(%sms)", FLOW_TIMEOUT);

	private Map<Sequence, Boolean> sequenceMap = new ConcurrentHashMap<>();
	private boolean isFlowEnd = false;
	private final ManagedThreadPool threadPoolManager;

	@Getter
	private boolean terminate = false;

	public Flow(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.FLOW, flowRuntimeContext, mediator);
		this.threadPoolManager = SingletonManager.getInstance().getSingletonInstance(ManagedThreadPool.class).get();
//		this.threadPoolManager.init();
	}

	@Override
	public Action init(Node node) {
//		List<Action> actionList = new ArrayList<Action>();
//
//		NodeList nlArgs = node.getChildNodes();
//		IntStream.range(0, nlArgs.getLength()).mapToObj(nlArgs::item)
//				.filter(childNode -> childNode.getNodeType() == Node.ELEMENT_NODE).map(childNode -> {
//					Action activity = ActionBuilder.createAction(childNode, flowRuntimeContext);
//					return activity != null ? activity.init(childNode) : null;
//				}).filter(Objects::nonNull).forEach(actionList::add);

		super.read(node);
		List<Action> actionList = super.getActionList();
		for (Action childAction : actionList) {
			if (childAction instanceof Sequence) {
				Sequence seq = (Sequence) childAction;
				if (this.sequenceMap.containsKey(seq)) {
					continue;
				}
				seq.setConcurrent(true);
				this.sequenceMap.put(seq, false);
			}
		}

//		super.eventBridge.overrideEndEvent((a) -> this.onActionEnd(a));
//		super.eventBridge.overrideExceptionEvent((a, e) -> this.onActionException(a, e));

		super.eventBridge.overrideFlowEvent(EventType.AFTER_ACTION, this::handleAfterExecuteEvent);
		super.eventBridge.overrideFlowEvent(EventType.ACTION_FAILED, this::handleExceptionEvent);

		return this;
	}

	@Override
	protected void work() {
		super.currentThread = Thread.currentThread();
		for (Sequence sequence : this.sequenceMap.keySet()) {
			if (sequence.isConcurrent()) {
				// TODO. AbstractAction이 Runnable이어야 하는데..
//				this.threadPoolManager.startPool(sequence);
//				sequence.run(); // 추후 위와 같이 threadPool 사용.
//				아래와 같이 수정
				this.threadPoolManager.submit(sequence);
			} else {
				sequence.run();
			}
		}

		try {
			// TODO. flowTimeout은 기존 BpelProcessManager에 선언되어 있었음.
			Thread.sleep(FLOW_TIMEOUT);
		} catch (InterruptedException e) {
//			super.mediator.interruptEventOccured(this);
			super.mediator.eventOccurred(EziFlowInternalEvent.newBuilder(EventType.ACTION_INTERRUPTED, this).build());
		}

		if (!this.isAllSequenceEnd()) {
			log.error(FLOW_TIMEOUT_MESSAGE);

//			super.mediator.exceptionEventOccured(this, new FlowException(FLOW_TIMEOUT_MESSAGE));
			super.mediator.eventOccurred(EziFlowInternalEvent.newBuilder(EventType.ACTION_TIMEOUT, this).build());
			for (Sequence sequence : this.sequenceMap.keySet()) {
				sequence.getCurrentThread().interrupt();
			}
		}
	}

	private void accuredFlowAction(Action action, String actionType) {
		try {
			if (action.equals(this)) {
				if (StringUtils.equalsIgnoreCase(actionType, TYPE_END)) {
					this.isFlowEnd = true;
					this.sequenceMap.clear();
				} else if (StringUtils.equalsIgnoreCase(actionType, TYPE_EXCEPTION)) {
					this.terminate = true;
					this.setTerminateAllSequence(true);
				}

				this.terminate = true;
			} else if (action instanceof Sequence) {
				Sequence seq = (Sequence) action;
				if (!this.sequenceMap.containsKey(seq)) {
					return;
				}

				if (StringUtils.equalsIgnoreCase(actionType, TYPE_END)) {
					seq.getCurrentThread().interrupt();
				} else if (StringUtils.equalsIgnoreCase(actionType, TYPE_EXCEPTION)) {
					this.terminate = true;
					this.setTerminateAllSequence(true);
				}

				this.sequenceMap.replace(seq, true);
				if (this.isAllSequenceEnd()) {
					if (!this.isFlowEnd) {
						super.currentThread.interrupt();
					}
				}
			}
		} catch (Exception ex) {
			super.mediator.eventOccurred(
					EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(ex).build());
		}

	}

	private boolean isAllSequenceEnd() {
		for (boolean isEnd : this.sequenceMap.values()) {
			if (!isEnd) {
				return false;
			}
		}
		return true;
	}

	private void setTerminateAllSequence(boolean terminate) {
		for (Sequence seq : this.sequenceMap.keySet()) {
			super.flowRuntimeContext.setTerminate(seq.getCurrentThread(), terminate);
		}
	}

	// end 이벤트를 재정
	private void handleAfterExecuteEvent(EziFlowEvent flowEvent) {
		this.accuredFlowAction(flowEvent.getAction(), TYPE_END);
	}

	// Exception 이벤트를 재정
	private void handleExceptionEvent(EziFlowEvent flowEvent) {
		this.accuredFlowAction(flowEvent.getAction(), TYPE_EXCEPTION);
	}
}
