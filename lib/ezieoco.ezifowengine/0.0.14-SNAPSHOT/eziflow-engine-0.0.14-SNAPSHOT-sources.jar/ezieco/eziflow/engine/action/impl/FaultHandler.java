package ezieco.eziflow.engine.action.impl;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.data.FaultData;
import ezieco.eziflow.engine.event.internal.Mediator;
import lombok.Getter;
import lombok.Setter;

public class FaultHandler extends AbstractAction {

	private boolean first = true;
	private boolean faultHandled = false;
	@Getter
	private boolean exceptionInFaultHandler = false;
	private boolean continueAfterHandlingFault = false;

	private CatchAll catchAll = null;
	private List<Catch> catchList = new ArrayList<>();

	private Queue<FaultData> faultQueue = new LinkedList<>();

	@Setter
	private Throwable throwable;

	public FaultHandler(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.FAULTHANDLERS, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		super.read(node);
		List<Action> actionList = super.getActionList();
		for (Action action : actionList) {
			if (action instanceof Catch) {
				this.catchList.add((Catch) action);
			} else if (action instanceof CatchAll) {
				this.catchAll = (CatchAll) action;
			}
		}

		return this;
	}

	@Override
	protected void work() {
		if (this.faultQueue.isEmpty()) {
			return;
		}

//			this.faultHandled = false;
//			this.exceptionInFaultHandler = true;
//			this.continueAfterHandlingFault = true;
//			this.setThrowable(e);

		/*
		 * TODO. while을 돌면서 queue에 있는 모든 faultData를 처리해야 하나? exception이 여러개 발생해도 최초 발생한
		 * exception처리 후 terminate됨. 다음 faultData까지 처리할 필요가 없음. (terminate되니까.)
		 */
		FaultData faultData = this.faultQueue.poll();
		for (Catch catchAction : this.catchList) {
			if (StringUtils.equalsIgnoreCase(catchAction.getFaultName(), faultData.getFaultName())) {
				catchAction.setFaultAction(faultData.getFaultAction());
				catchAction.run();
				return;
			}
		}

		if (this.catchAll != null) {
			this.catchAll.run();
		}
	}

	public void setFaultData(Action action, Exception e) {
		FaultData faultData = new FaultData();
		faultData.setFaultHandler(this);
		faultData.setFaultAction(action);
		faultData.setFaultName(action.getFaultName());
		faultData.setThrowable(e);

		this.faultQueue.add(faultData);
	}
}
