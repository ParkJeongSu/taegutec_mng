package ezieco.eziflow.engine.action;

import ezieco.eziflow.engine.event.external.data.dto.ActionDTO;

public interface ActionDTOProvider {
	ActionDTO getDTO();
}
