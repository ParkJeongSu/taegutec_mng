package ezieco.eziflow.engine.action;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ezieco.eziflow.engine.action.impl.Catch;
import ezieco.eziflow.engine.action.impl.CatchAll;
import ezieco.eziflow.engine.action.impl.ExecuteAction;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.internal.EziFlowBridgeListener;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;
import ezieco.eziflow.engine.event.internal.data.EziFlowInternalEvent;
import ezieco.eziflow.engine.event.internal.impl.EventBridgeImpl;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractAction implements Action {

	private static final AtomicLong uniqueId = new AtomicLong(1);
	private static final AtomicLong uniqueProcId = new AtomicLong(1);

	@Getter
	private long id;

	@Getter
	@Setter
	private boolean exceptionOccurred = false;

	@Getter
	@Setter
	private boolean concurrent = false;

	private int sequence = -1;

	@Getter
	private String name;

	@Setter
	private String procId;
	private String actionName;

	@Getter
	@Setter
	private Action parent;

	@Getter
	protected LocalDateTime startTime;

	@Getter
	protected LocalDateTime endTime;

	@Getter
	protected Thread currentThread;

	@Getter
	@Setter
	private String faultName;

	private final ActionEnum actionType;

	@Getter
	private final List<Action> actionList = new CopyOnWriteArrayList<>();
	protected final EziFlowRuntimeContext flowRuntimeContext;
	protected final Mediator mediator;
	protected final EziFlowBridgeListener<EziFlowEvent> eventBridge;

	public boolean isTerminate(Action action) {
		return this.flowRuntimeContext.isTerminate(action);
	}

	public String getProcId() {
		return this.procId == null ? System.currentTimeMillis() + "." + uniqueProcId.getAndIncrement() : this.procId;
	}

	public ExecuteAction getExecuteAction() {
		return this.flowRuntimeContext.getExecuteAction();
	}

	@Override
	public ActionEnum getActionType() {
		return this.actionType;
	}

	protected AbstractAction(ActionEnum actionType, EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		this.id = uniqueId.getAndIncrement();
		this.actionType = actionType;
		this.flowRuntimeContext = flowRuntimeContext;
		this.mediator = mediator;
		// Node 마다 EventBridgeImpl 를 만들어 준다.
		this.eventBridge = new EventBridgeImpl(this.actionType.toString());
		this.mediator.register(this.eventBridge);
	}

	@Override
	public void start() {
		this.startTime = LocalDateTime.now();
	}

	@Override
	public void end() {
		this.endTime = LocalDateTime.now();
	}

	public void setNodeName(String nodeName, Node node) {
		this.actionName = nodeName;
		this.name = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.NAME);
	}

	public void run() {
		if (log.isDebugEnabled()) {
			log.debug("run " + this);
		}

		Thread.currentThread().setName("THREAD-ID=" + Thread.currentThread().getId());

		try {
			if (this.flowRuntimeContext.isTerminate(this)) {
				return;
			}

			this.mediator.eventOccurred(EziFlowInternalEvent.newBuilder(EventType.BEFORE_ACTION, this).build());
			work();
			this.mediator.eventOccurred(EziFlowInternalEvent.newBuilder(EventType.AFTER_ACTION, this).build());
		} catch (Exception e) {
			this.mediator.eventOccurred(
					EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(e).build());
		}
	}

	// TODO
	protected Action read(Node node) {
		try {
			NodeList childNodeList = node.getChildNodes();
			int length = childNodeList.getLength(); // NodeList 길이를 미리 구함

			for (int i = 0; i < length; i++) {
				Node childNode = childNodeList.item(i);

				// ELEMENT_NODE가 아니면 다음 반복으로 넘어감
				if (childNode.getNodeType() != Node.ELEMENT_NODE) {
					continue;
				}

				Action childAction = ActionBuilder.createAction(childNode, flowRuntimeContext, mediator, this);
				if (childAction != null) {
					// 초기화 결과가 null이 아니면 actionList에 추가
					if (childAction.init(childNode) != null) {
						actionList.add(childAction);
					}
				}
			}
			return this;
		} catch (Exception e) {
			// 예외 발생 시 이벤트 발생 및 언레지스터 처리
			this.mediator.eventOccurred(EziFlowInternalEvent
					.newBuilder(EventType.ACTION_FAILED, this).setException(new EziFlowException(ErrorMessageInfo
							.builder().errorCodeProvider(ErrorCode.READ_NODE_ERROR).args("", "", e).build(), e, node))
					.build());
			this.mediator.unregister(this.eventBridge);
			return null;
		}
	}

	protected String getInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append("process:").append(this.flowRuntimeContext.getExecuteAction()).append(" procid:").append(getProcId())
				.append(" activity:").append(this.actionName).append(" name:").append(this.name).append(" no:")
				.append(this.sequence);
		return sb.toString();
	}

	// Activityu run()
	protected void execute() {
//		Thread.currentThread().setName("THREAD-ID=" + Thread.currentThread().getId());
		if (this.concurrent) {
			this.flowRuntimeContext.setCurrentRuntimeContext();
		}

		this.currentThread = Thread.currentThread();

		try {
			for (Action childAction : this.actionList) {
//				childAction.setParent(this);
//				this.setChild(childAction);

				if (this instanceof Catch || this instanceof CatchAll) {
//					childAction.setFaultAction(this.faultAction);
				}

				childAction.run();
			}
		} catch (Exception e) {
//			this.mediator.exceptionEventOccured(this, e);
			this.mediator.eventOccurred(
					EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(e).build());
		} finally {
			if (this.concurrent) {
				this.flowRuntimeContext.removetRuntimeContext();
			}
		}
	}

//	@Override
//	public void addListener(FlowListener listener) {
//		this.mediator.register(listener);
//	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("{");
		sb.append("\"executeAction\": \"").append(this.flowRuntimeContext.getExecuteAction()).append("\", ");
		sb.append("\"actionName\": \"").append(this.actionName).append("\", ");
		sb.append("\"id\": \"").append(this.id).append("\"}");
		return sb.toString();
	}

	protected abstract void work();
}
