package ezieco.eziflow.engine.action.impl;

import java.util.List;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InvokeWorkflow extends AbstractAction {

	@Getter
	private FaultHandler faultHandler = null;

	public InvokeWorkflow(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.INVOKE_WORKFLOW, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		super.read(node);
		List<Action> actionList = this.getActionList();
		for (Action action : actionList) {
			if (action instanceof FaultHandler) {
				this.faultHandler = (FaultHandler) action;
			}
		}

		return this;
	}

	@Override
	protected void work() {
		if (log.isDebugEnabled()) {
			log.debug("InvokeWorkflow Start.");
		}
		this.flowRuntimeContext.setCurrentRuntimeContext();
		super.execute();
	}

	public void setTerminate(boolean terminate) {
		super.flowRuntimeContext.setTerminate(terminate);
	}

	public void setInputs(Object... args) {
		super.flowRuntimeContext.setRequests(args);
	}

	public Object getOutput() {
		return super.flowRuntimeContext.getResponse();
	}

	public Mediator getMediator() {
		return super.mediator;
	}
}
