package ezieco.eziflow.engine.action.impl;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;

public class Terminate extends AbstractAction {
	private final String OPTION_ALL = "all";
	private final String OPTION_THIS = "this";

	private String terminateOption;

	public Terminate(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.TERMINATE, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		String option = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.TYPE);

		if (option.equalsIgnoreCase(this.OPTION_ALL)) {
			this.terminateOption = this.OPTION_ALL;
		} else {
			this.terminateOption = this.OPTION_THIS;
		}
		return this;
	}

	@Override
	protected void work() {
		super.currentThread = Thread.currentThread();
		this.flowRuntimeContext.setTerminate(true);

		if (StringUtils.equalsIgnoreCase(this.terminateOption, this.OPTION_ALL)) {
			this.setTerminateAll(this.flowRuntimeContext.getExecuteAction().getSuperAction());
		}
	}

	private void setTerminateAll(ExecuteAction superAction) {
		if (superAction == null) {
			return;
		} else {
			superAction.getFlowRuntimeContext().setTerminate(true);
			this.setTerminateAll(superAction.getSuperAction());
		}
	}

}
