package ezieco.eziflow.engine.action.impl;

import java.util.Optional;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.expression.EziFlowExpression;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.Getter;
import lombok.Setter;

public class Case extends AbstractAction {

	private final EziFlowExpression flowExpression;

	@Getter
	@Setter
	private String condition = "";

	public Case(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.CASE_OPTION, flowRuntimeContext, mediator);
		Optional<EziFlowExpression> optionalExpression = SingletonManager.getInstance()
				.getSingletonInstance(EziFlowExpression.class);
		if (optionalExpression.isPresent()) {
			this.flowExpression = optionalExpression.get();
		} else {
			throw new IllegalStateException("EziFlowExpression singleton instance is not available.");
		}
	}

	@Override
	public Action init(Node node) {
		if (node.getNodeName().equals(ActionEnum.CASE_OPTION.getName())) {
			this.condition = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.CONDITION);
			if (this.condition == null) {
				throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.READ_NODE_ERROR)
						.args(EziFlowConst.CONDITION, node, "").build());
			}
		}

		super.read(node);

		return this;
	}

	@Override
	protected void work() {
		super.execute();
	}

	protected boolean getConditionResult() {
		Object object = this.flowExpression.xpathQuery(this.condition);
		return object != null && ((Boolean) object).booleanValue();
	}
}
