package ezieco.eziflow.engine.action.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.xml.namespace.QName;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionDTOProvider;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.concurrent.ManagedThreadPool;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.data.InputData;
import ezieco.eziflow.engine.data.InputDataCollection;
import ezieco.eziflow.engine.data.PartnerData;
import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.external.data.dto.ActionDTO;
import ezieco.eziflow.engine.event.external.data.dto.impl.InvokeActionDTO;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.event.internal.data.EziFlowInternalEvent;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.expression.EziFlowExpression;
import ezieco.eziflow.engine.repository.EziFlowSpecRepo;
import ezieco.eziflow.engine.repository.spec.BpelSpec;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.ParameterReflectionHelper;
import ezieco.eziflow.engine.utils.StackTraceFormatter;
import ezieco.eziflow.engine.utils.TypeConverterUtil;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Invoke extends AbstractAction implements ActionDTOProvider {

	private boolean fork = false;
	private boolean ignoreThrow = false;

	private String pname;
	private String operation;
	private String condition;
	private String output;

	private QName bpelQName;
	private Object partner;
	private InputDataCollection inpuDataCollection = new InputDataCollection();

	private Object[] inputValues = new Object[] {};

	private final EziFlowExpression flowExpression;

	private boolean isWFPartner() {
		return this.partner == null;
	}

	public Invoke(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.INVOKE, flowRuntimeContext, mediator);

		this.flowExpression = SingletonManager.getInstance().getSingletonInstance(EziFlowExpression.class).get();
	}

	@Override
	public Action init(Node node) {
		this.pname = XmlNodeUtils.getAttribute(node, EziFlowConst.PARTNER_LINK);
		this.operation = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.OPERATION);
		readIgnoreThrow(node);
		readFaultInfo(node);
		readForkMode(node);

		NodeList nlArgs = node.getChildNodes();

		for (int i = 0; i < nlArgs.getLength(); i++) {
			Node nodei = nlArgs.item(i);

			if (nodei.getNodeType() != Node.ELEMENT_NODE)
				continue;

			if (nodei.getNodeName().equals(EziFlowConst.INPUT)) {
				this.inpuDataCollection.addInputs(nodei);
			} else if (nodei.getNodeName().equals(EziFlowConst.FAULT)) {
				readFaultInfo(nodei);
			} else if (nodei.getNodeName().equals(EziFlowConst.OUTPUT)) {
				this.output = XmlNodeUtils.getAttribute(nodei, EziFlowConst.VARIABLE);
			} else if (nodei.getNodeName().equals(EziFlowConst.CORRELATION)) {
				this.condition = XmlNodeUtils.getAttribute(node, EziFlowConst.CONDITION);
			}
		}

		return this;
	}

	private void readIgnoreThrow(Node node) {
		String ignore = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.IGNORE_THROW);
		if (ignore == null) {
			return;
		}

		if (ignore.equalsIgnoreCase(EziFlowConst.TRUE) == false) {
			return;
		}

		this.ignoreThrow = true;
	}

	private void readForkMode(Node node) {
		String ignore = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.INVOKE_FORK);
		if (ignore == null) {
			return;
		}

		if (ignore.equalsIgnoreCase(EziFlowConst.TRUE) == false) {
			return;
		}

		super.setConcurrent(true);
		this.fork = true;
	}

	private void readFaultInfo(Node node) {
		super.setFaultName(XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.FAULT_NAME));
	}

	@Override
	protected void work() {
		this.partner = getPartnerWForBean();

		inputVariablesSettingInForkCloneOrNotForkRef();

		if (super.isConcurrent()) {
			SingletonManager.getInstance().getSingletonInstance(ManagedThreadPool.class).get().submit(this::doWork);
		} else {
			this.doWork();
		}
	}

	private void doWork() {
		Thread.currentThread().setName("THREAD-ID=" + Thread.currentThread().getId());
		if (super.isConcurrent()) {
			this.flowRuntimeContext.setCurrentRuntimeContext();
		}

		super.currentThread = Thread.currentThread();
		this.flowRuntimeContext.setRunningAction(this);

		if (this.isWFPartner()) {
			try {
				// mjkim89. 주석 처리.
//				ExecuteAction action = createExecuteAction();
//				Object out = invokeWFPartner(action);

				// mjkim89. invokeWF를 실행할 때 새로운 executeAction이 아니라 action으로 수행.
				Object out = this.doInvokeWorkflow();

				if (!this.isConcurrent()) {
					this.flowRuntimeContext.setCurrentRuntimeContext();
				}

				if (output != null) {
					super.flowRuntimeContext.getVariableData().setValue(output, out);
				}

			} catch (Exception ex) {
				EziFlowException exception = null;

				if (ex instanceof EziFlowException) {
					exception = (EziFlowException) ex;
				} else {
					exception = new EziFlowException(ErrorMessageInfo.builder()
							.errorCodeProvider(ErrorCode.INVALID_INVOKE).args(ex, this.getInfo()).build(), ex);
				}

//				super.mediator.exceptionEventOccured(this, exception);
				super.mediator.eventOccurred(
						EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(exception).build());
				return;
			}
		} else {
			doInvoke();
		}

		executeCorrelation();

		if (super.isConcurrent() || !super.isExceptionOccurred()) {
			this.onEnd(this);
		}

		if (super.isConcurrent()) {
			this.flowRuntimeContext.removetRuntimeContext();
		}
	}

	private void onEnd(Action action) {
		if (super.isConcurrent() && (this.isWFPartner())) {
//			action.setMetConcurrent(true);
		}

//		TODO 로그가 여러번 찍힌다. 
//		비동기 작업에서 end 처리 시점
//		super.getMediator().endEventOccured(this);
	}

	private void onException(Action action, Exception e) {
		if (this.ignoreThrow) {
//			this.setFaultHandled(true);
		}

		try {
			if (this.equals(action)) {
//				if (this.faultVariable) {
//					this.flowRuntimeContext.getVariableData().setValue(faultVariable, e);
//				}
			} else {

			}

//			super.mediator.exceptionEventOccured(this, e);
			super.mediator.eventOccurred(
					EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(e).build());
		} catch (Exception ex) {
//			super.mediator.exceptionEventOccured(this, ex);
			super.mediator.eventOccurred(
					EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(ex).build());
		}
	}

	private void executeCorrelation() {
		if (StringUtils.isEmpty(this.condition)) {
			return;
		}

		// TODO ???
		this.flowExpression.xpathQuery(this.condition);
	}

	// mjkim89. invokeWF를 실행할 때 새로운 executeAction이 아니라 action으로 수행.
	private Object doInvokeWorkflow() {
		EziFlowSpecRepo flowSpecRepo = SingletonManager.getInstance().getSingletonInstance(EziFlowSpecRepo.class).get();
		BpelSpec bpelSpecInstance = flowSpecRepo.newFlowSpec(this.bpelQName);
		if (bpelSpecInstance == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.QNAME_FIND_ERROR)
					.args(this.bpelQName).build());
		}

		EziFlowRuntimeContext context = new EziFlowRuntimeContext();

		// ExecuteAction 넣어준다.
		context.setExecuteAction(this.flowRuntimeContext.getExecuteAction());

		InvokeWorkflow invokeWF = new InvokeWorkflow(context, this.mediator);
		invokeWF.setParent(this);

		invokeWF.init(bpelSpecInstance.getDocument().getDocumentElement());

		// TODO fork 기능에 대해서 논의 필요
		// method 단위로 비동기 처리했을때 관리할 수 있을까?
		if (this.fork) {
			invokeWF.setInputs(this.inputValues);
			invokeWF.run();
		} else {
			invokeWF.setInputs(this.inputValues);
			invokeWF.run();
		}

		return invokeWF.getOutput();
	}

	private void doInvoke() {
		try {
			Object out = invokeBean();

			if (output != null) {
				super.flowRuntimeContext.getVariableData().setValue(output, out);
			}

		} catch (Exception ex) {
			if (ex.getCause() instanceof Error) {
				log.error("<<<" + ex.getCause() + ">>>  -> " + this.getInfo());
			}

			EziFlowException exception = null;

			if (ex instanceof EziFlowException) {
				exception = (EziFlowException) ex;
			} else {
				exception = new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.INVALID_INVOKE)
						.args(ex, this.getInfo()).build(), ex);
			}

			onException(this, exception);
		}
	}

	private Object invokeBean() {
		try {
			Class<?>[] classes = this.inpuDataCollection.getInputs().stream().map(inputData -> {
				if (inputData.isVariable() && inputData.getType() == null) {
					return super.flowRuntimeContext.getVariableData().getVariable(String.valueOf(inputData.getInput()))
							.getClazz();
				} else {
					return inputData.getType();
				}
			}).toArray(Class<?>[]::new);

			return reflection(classes);

		} catch (InvocationTargetException ex) {
			throw new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.REFLECTION_INVOKE_ERROR)
							.args(this.partner.getClass().getName() + "." + this.operation,
									this.flowRuntimeContext.getExecuteAction(), this.getInfo())
							.build(),
					ex.getTargetException());

		} catch (NoSuchMethodException ex) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NO_SUCH_METHOD)
					.args(this.partner.getClass().getName() + "." + this.operation,
							this.flowRuntimeContext.getExecuteAction(), this.getInfo())
					.build(), ex);

		} catch (Exception ex) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.INVALID_INVOKE)
					.args(ex, super.getInfo()).build());
		}
	}

	private Object reflection(Class<?>[] parameterTypes) throws ClassNotFoundException, NoSuchMethodException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException, SecurityException {

		try {
			Method[] methods = this.partner.getClass().getMethods();

			for (Method method : methods) {
				if (method.getName().equals(this.operation)) {
					Class<?>[] methodParameterTypes = method.getParameterTypes();

					if (areParameterTypesCompatible(methodParameterTypes, parameterTypes)) {
						return method.invoke(this.partner, this.inputValues);
					}
				}
			}
			throw new NoSuchMethodException();
		} catch (NoSuchMethodException ex) {
			return invokeVarArgMethod(parameterTypes, ex);
		}
	}

	private boolean areParameterTypesCompatible(Class<?>[] methodParameterTypes, Class<?>[] parameterTypes) {
		if (methodParameterTypes.length != parameterTypes.length) {
			return false; // 길이가 다르면 바로 불일치로 처리
		}

		for (int i = 0; i < methodParameterTypes.length; i++) {
			if (!methodParameterTypes[i].isAssignableFrom(parameterTypes[i])) {
				return false; // parameterTypes[i]가 methodParameterTypes[i]의 서브클래스가 아니면 불일치
			}
		}

		return true; // 모든 타입이 호환됨
	}

	private Object invokeVarArgMethod(Class<? extends Object>[] parameterTypes, NoSuchMethodException ex)
			throws NoSuchMethodException {
		List<Method> methodList = getMethodCandidates(this.partner.getClass(), this.operation, parameterTypes);

		return methodList.stream().map(method -> {
			try {
				Object[] params = ParameterReflectionHelper.getParameters(method.getParameterTypes(), this.inputValues);
				Object result = method.invoke(this.partner, params);
				if (method.getReturnType().equals(void.class)) {
					return "Void method executed successfully";
				}
				return result;
			} catch (Exception e) {
				return null;
			}
		}).filter(Objects::nonNull).findFirst().orElseThrow(() -> ex);
	}

	private List<Method> getMethodCandidates(Class<? extends Object> beanClass, String operationName,
			Class<? extends Object>[] parameterTypes) {
		List<Method> candidates = new ArrayList<>();
		Method[] methods = beanClass.getDeclaredMethods();
		Class<? extends Object> lastParamType = ParameterReflectionHelper.findLastParameterType(parameterTypes);

		for (Method method : methods) {
			if (method.getName().equals(operationName)) {
				Class<? extends Object>[] methodParamTypes = method.getParameterTypes();
				Class<? extends Object> methodLastParamType = ParameterReflectionHelper
						.findLastParameterType(methodParamTypes);

				if (methodLastParamType != null && methodLastParamType.isArray() && lastParamType != null
						&& methodLastParamType.getComponentType().isAssignableFrom(lastParamType)) {
					candidates.add(method);
				}
			}
		}
		return candidates;
	}

	private void inputVariablesSettingInForkCloneOrNotForkRef() {
		List<InputData> inputs = this.inpuDataCollection.getInputs();
		int size = inputs.size();
		Object[] objects = new Object[size];

		for (int i = 0; i < size; i++) {
			InputData inputData = inputs.get(i);
			objects[i] = inputData.isVariable()
					? cloneOrPointer(this.flowRuntimeContext.getVariableData().getValue(inputData.getInput()))
					: TypeConverterUtil.getValue(inputData.getType(), inputData.getInput());
		}

		this.inputValues = objects;
	}

	private Object cloneOrPointer(Object object) {
		try {
			if (object == null) {
				return null;
			}

			if (this.fork == false) {
				return object;
			}

			if (object instanceof Cloneable) {
				return object.getClass().getMethod("clone", new Class[] {}).invoke(object, new Object[] {});
			}

			return object;
		} catch (Exception e) {
			log.warn(StackTraceFormatter.getCompleteStackTrace(e));
			return object;
		}
	}

	private Object getPartnerWForBean() {
		PartnerData partnerData = this.flowRuntimeContext.getPartnerData();
		if (partnerData.isBean(pname)) {
			return partnerData.getBean(pname);
		}

		this.bpelQName = makeWFQNameFromOperation(pname, partnerData);
		return null;
	}

	private QName makeWFQNameFromOperation(String pname, PartnerData pdata) {
		if (StringUtils.isBlank(this.operation)) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.INVALID_INVOKE_OPERATION)
					.args(this.operation).build());
		}

		return new QName(pdata.getWFNamespace(pname), this.operation);
	}

	@Override
	public ActionDTO getDTO() {
		return new InvokeActionDTO(this.getName(), this.pname, this.operation);
	}
}
