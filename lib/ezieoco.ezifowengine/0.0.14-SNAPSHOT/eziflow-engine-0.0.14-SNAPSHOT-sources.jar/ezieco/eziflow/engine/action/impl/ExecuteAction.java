package ezieco.eziflow.engine.action.impl;

import java.util.List;
import java.util.Optional;

import javax.xml.namespace.QName;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.external.EventPublisher;
import ezieco.eziflow.engine.event.external.data.EziFlowActionEventLog;
import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;
import ezieco.eziflow.engine.event.internal.data.EziFlowInternalEvent;
import ezieco.eziflow.engine.event.internal.impl.EventMediator;
import ezieco.eziflow.engine.management.MetricManager;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExecuteAction extends AbstractAction {

	private final QName qname;

	@Getter
	private FaultHandler faultHandler = null;

	@Getter
	@Setter
	private ExecuteAction superAction;

	private EventPublisher eventPublisher;

//	private List<Action> activitiesHistory = new CopyOnWriteArrayList<>();

	private MetricManager metricManager;

	private Exception exception;

//	public List<Action> getActivitiesHistory() {
//		return Collections.unmodifiableList(this.activitiesHistory);
//	}

	public ExecuteAction(QName qname, EziFlowRuntimeContext flowRuntimeContext, EventPublisher eventPublisher) {
		super(ActionEnum.EXECUTE_TASK, flowRuntimeContext, new EventMediator());
		this.flowRuntimeContext.setExecuteAction(this);
		this.qname = qname;
		this.eventPublisher = eventPublisher;
		Optional<MetricManager> optionalMetric = SingletonManager.getInstance()
				.getSingletonInstance(MetricManager.class);
		if (optionalMetric.isPresent()) {
			this.metricManager = optionalMetric.get();
		} else {
			if (log.isDebugEnabled()) {
				log.info("MetricManager singleton instance is not available.");
			}
		}
	}

	public void setReq(Object... args) {
		this.flowRuntimeContext.setRequests(args);
	}

	public void setDefaultCorrelationId(Object defaultCorrelationId) {
		this.flowRuntimeContext.setDefaultCorrelationId(defaultCorrelationId);
	}

	public Object getReplyMessage() {
		return this.flowRuntimeContext.getResponse();
	}

	@Override
	public Action init(Node node) {

		this.eventBridge.overrideFlowEvent(EventType.BEFORE_ACTION, this::handleBeforeActionEvent);
		this.eventBridge.overrideFlowEvent(EventType.AFTER_ACTION, this::handleAfterActionEvent);
		this.eventBridge.overrideFlowEvent(EventType.ACTION_INTERRUPTED, this::handleInterruptEvent);
		this.eventBridge.overrideFlowEvent(EventType.ACTION_TIMEOUT, this::handleTimeoutEvent);
		this.eventBridge.overrideFlowEvent(EventType.ACTION_FAILED, this::handleExceptionEvent);

		if (this.read(node) == null) {
			return null;
		}

		List<Action> actionList = this.getActionList();
		for (Action action : actionList) {
			if (action instanceof FaultHandler) {
				this.faultHandler = (FaultHandler) action;
//				break; // TODO. fault handler를 여러개 사용할까?
			}
		}

		return this;
	}

	// TODO toString 왜 다르게 했을까?
	@Override
	public String getName() {
		return this.midAfterApache(this.qname.toString(), "}");
	}

	// TODO
	@Override
	public String toString() {
		return "{ \"qname\": \"" + this.qname.toString() + "\", \"id\": \"" + getId() + "\" }";
	}

	public EziFlowRuntimeContext getFlowRuntimeContext() {
		return super.flowRuntimeContext;
	}

	@Override
	public void run() {
		if (this.metricManager != null) {
			metricManager.processBpel(getName(), super::run);
			if (log.isDebugEnabled()) {
				log.debug(metricManager.getMetricsInfo(getName()));
			}
		} else {
			super.run();
		}
	}

	@Override
	protected void work() {
		this.flowRuntimeContext.setCurrentRuntimeContext();

//		this.onActionStart(FlowInternalEvent.newBuilder(EventType.START, this).build());
		this.execute();
//		this.onActionStart(FlowInternalEvent.newBuilder(EventType.END, this).build());
	}

	private void handleBeforeActionEvent(EziFlowEvent flowEvent) {
		if (log.isDebugEnabled()) {
			log.debug("start Bpel: [{}]", flowEvent.getAction());
		}

		flowEvent.getAction().start();

		super.flowRuntimeContext.setRunningAction(flowEvent.getAction());

		// 이벤트를 구독하는 서비스들에게 이벤트를 전달한다.
		if (this.eventPublisher == null) {
			return;
		}

		this.eventPublisher.eventOccured(
				EziFlowActionEventLog.builder(this.getName(), EventType.BEFORE_ACTION, flowEvent.getAction()).build());
	}

	private void handleAfterActionEvent(EziFlowEvent flowEvent) {
		if (log.isDebugEnabled()) {
			log.debug("End Bpel: [{}]", flowEvent.getAction());
		}

		flowEvent.getAction().end();

		// 이벤트를 구독하는 서비스들에게 이벤트를 전달한다.
		if (this.eventPublisher == null) {
			return;
		}

		if (flowEvent.getAction().getActionType() == ActionEnum.EXECUTE_TASK) {
			this.eventPublisher.eventOccured(
					EziFlowActionEventLog.builder(this.getName(), EventType.AFTER_ACTION, flowEvent.getAction())
							.setException(exception).build());
		} else {
			this.eventPublisher.eventOccured(EziFlowActionEventLog
					.builder(this.getName(), EventType.AFTER_ACTION, flowEvent.getAction()).build());
		}
	}

	private void handleExceptionEvent(EziFlowEvent flowEvent) {
		Action action = flowEvent.getAction();
		exception = flowEvent.getException();
		boolean deleveryEvent = true;

		try {
			// fault handler에서 발생한 exception인 경우.
			if (action instanceof FaultHandler || action instanceof Catch || action instanceof CatchAll) {
				log.error(exception.getMessage(), exception);
				this.getFlowRuntimeContext().setTerminate(true);
				return;
			}

			// fault handler에 속한 action에서 발생한 exception인 경우.
			if (this.isActionInFaultHandler(action)) {
				log.error(exception.getMessage(), exception);
				this.getFlowRuntimeContext().setTerminate(true);
				return;
			}

			// TODO. invokeWF를 executeAction으로 생성한다면 삭제.
			// invokeWF에 속한 action에서 발생한 exception인 경우.
			InvokeWorkflow invokeWF = this.checkActionInInvokeWorkFlow(action);
			if (invokeWF != null) {
				// invokeWF에 faultHandler이 있으면 해당 faultHandler로 exception처리.
				if (invokeWF.getFaultHandler() != null) {
					invokeWF.getFaultHandler().setFaultData(action, exception);
					invokeWF.getFaultHandler().run();
				} else {
					// faultHandler가 없으면 부모(executeAction)의 faultHandler로 처리.
					/*
					 * legacy: invokeWF에도 invoke와 동일하게 faultHandler설정할 수 있음. invokeWF로 호출한 bpel에
					 * faultHandler가 없고 exception발생 시 처리하려는 목적 같음. 하지만 실제로 동작 시켜보면 invokeWF에 설정한
					 * faultHandler와 상관없이 catchAll로 처리함.
					 * 
					 * eziFlow: invokeWF에도 faultName설정 가능하기 때문에 invokeWF의 부모인 invoke action으로
					 * exception발생. 그래야 설정되어 있는 faultName을 가져와 faultHandler에서 비교할 수 있다.
					 */
					//
//					invokeWF.getMediator().exceptionEventOccured(invokeWF.getParent(), e);
					super.mediator.eventOccurred(EziFlowInternalEvent
							.newBuilder(EventType.ACTION_FAILED, invokeWF.getParent()).setException(exception).build());
					deleveryEvent = false; // 부모에서 처리.
				}

				invokeWF.setTerminate(true); // exception발생했으니 terminate.
				return;
			}

			// faultHandler가 없는 경우.
			if (this.faultHandler == null) {

				// TODO. invokeWF를 action으로 생성한다면 삭제.
				// invokeWF내부의 action인지 확인. (invokeWF가 executeAction으로 실행되는 경우.)
//				if (action.getExecuteAction().getSuperAction() != null) {
//					// executeAction의 parent가 invoke라면 invokeWF로 판단.
//					Action parent = action.getExecuteAction().getParent();
//					if (parent != null && parent instanceof Invoke) {
//						action.getExecuteAction().getFlowRuntimeContext().setTerminate(true);
//
//						// parent의 faultHandler로 처리 하기 위해 exception발생.
//						action.getExecuteAction().getMediator().exceptionEventOccured(parent,
//								e);
//						
//						deleveryEvent = false; // 부모에서 처리.
//						return;
//					}
//				}

				log.error(exception.getMessage(), exception);
			} else {
				this.faultHandler.setFaultData(action, exception);
				this.faultHandler.run();
			}

			this.getFlowRuntimeContext().setTerminate(true); // exception발생했으니 terminate.

			// 2023.12.05. 해당 executeAction에서 발생한 exception만 받을 수 있기 때문에 비교 불필요.
//			if (action.getExecuteAction().equals(this)) {
//			}
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			this.getFlowRuntimeContext().setTerminate(true);
		} finally {
			if (this.metricManager != null) {
				this.metricManager.incrementErrorMetrics(this.getName());
			}

			if (deleveryEvent && this.eventPublisher != null) {
				// 이벤트를 구독하는 서비스들에게 이벤트를 전달한다.
				this.eventPublisher.eventOccured(EziFlowActionEventLog
						.builder(this.getName(), EventType.ACTION_FAILED, action).setException(exception).build());
			}

		}
	}

	private void handleTimeoutEvent(EziFlowEvent flowEvent) {
		log.debug("Timeout Bpel: [{}]", flowEvent.getAction());

		if (this.metricManager != null) {
			this.metricManager.incrementErrorMetrics(this.getName());
		}

		if (this.eventPublisher == null) {
			return;
		}

		// 이벤트를 구독하는 서비스들에게 이벤트를 전달한다.
		this.eventPublisher.eventOccured(
				EziFlowActionEventLog.builder(this.getName(), EventType.ACTION_TIMEOUT, flowEvent.getAction()).build());
	}

	private void handleInterruptEvent(EziFlowEvent flowEvent) {
		if (log.isDebugEnabled()) {
			log.debug("Interrupt Bpel: [{}]", flowEvent.getAction());
		}

		if (this.metricManager != null) {
			this.metricManager.incrementErrorMetrics(this.getName());
		}

		if (this.eventPublisher == null) {
			return;
		}

		// 이벤트를 구독하는 서비스들에게 이벤트를 전달한다.
		this.eventPublisher.eventOccured(EziFlowActionEventLog
				.builder(this.getName(), EventType.ACTION_INTERRUPTED, flowEvent.getAction()).build());
	}

	private String midAfterApache(String original, String start) {
		return StringUtils.substringAfter(original, start);
	}

	private boolean isActionInFaultHandler(Action action) {
		Action parent = action.getParent();
		while (parent != null) {
			if (parent instanceof FaultHandler) {
				return true;
			}

			parent = parent.getParent();
		}

		return false;
	}

	private InvokeWorkflow checkActionInInvokeWorkFlow(Action action) {
		Action parent = action.getParent();
		while (parent != null) {
			if (parent instanceof InvokeWorkflow) {
				return (InvokeWorkflow) parent;
			}

			parent = parent.getParent();
		}

		return null;
	}
}
