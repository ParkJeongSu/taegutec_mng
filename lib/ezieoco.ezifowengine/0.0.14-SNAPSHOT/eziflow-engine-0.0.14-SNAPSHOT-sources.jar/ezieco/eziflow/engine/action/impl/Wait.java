package ezieco.eziflow.engine.action.impl;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.event.internal.data.EziFlowInternalEvent;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.Getter;

public class Wait extends AbstractAction {

	@Getter
	private String timeoutString = "";

	public Wait(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.WAIT, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		this.timeoutString = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.TIMEOUT);
		return this;
	}

	@Override
	protected void work() {
		super.currentThread = Thread.currentThread();
		try {
			long timeOut = 0;
			if (StringUtils.isNotEmpty(this.timeoutString)) {
				if (StringUtils.isNumeric(this.timeoutString)) {
					timeOut = NumberUtils.toLong(this.timeoutString);
				} else {
					timeOut = (long) super.flowRuntimeContext.getVariableData().getValue(this.timeoutString);
				}
			}

			Thread.sleep(timeOut);
		} catch (InterruptedException e) {
			super.mediator.eventOccurred(EziFlowInternalEvent.newBuilder(EventType.ACTION_INTERRUPTED, this).build());
			return;
		}
	}

}
