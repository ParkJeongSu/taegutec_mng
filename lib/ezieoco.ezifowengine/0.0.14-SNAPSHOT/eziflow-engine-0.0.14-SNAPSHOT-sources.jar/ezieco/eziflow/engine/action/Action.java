package ezieco.eziflow.engine.action;

import java.time.LocalDateTime;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.impl.ExecuteAction;

public interface Action {

	String getName();

	ActionEnum getActionType();

	LocalDateTime getStartTime();

	LocalDateTime getEndTime();

	void start();

	void end();

	// Xml 파일에서 Action 으로 변경한다.
	Action init(Node node);

	Action getParent();

	void setParent(Action action);

	boolean isTerminate(Action action);

	void run();

	// catch의 faultName과 action에 설정된 faultName을 비교하기 위해 추가.
	String getFaultName();

	// exception발생 시 발생한 ExecuteAction구분 및 ExecuteAction의 Mediator를 가져오기 위해 추가.
	ExecuteAction getExecuteAction();
}
