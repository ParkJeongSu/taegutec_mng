package ezieco.eziflow.engine.action.impl;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Sequence extends AbstractAction {

	public Sequence(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.SEQUENCE, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		return this.read(node);
	}

	@Override
	protected void work() {
		if (log.isDebugEnabled()) {
			log.debug("work " + this);
		}

		super.execute();
	}
}
