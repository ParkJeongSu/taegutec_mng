package ezieco.eziflow.engine.action;

@FunctionalInterface
public interface PostAction {
	void execute();
}
