package ezieco.eziflow.engine.action.impl;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;

public class Otherwise extends AbstractAction {

	public Otherwise(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.OTHERWISE_OPTION, flowRuntimeContext, mediator);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Action init(Node node) {
		// TODO Auto-generated method stub
		super.read(node);
		return this;
	}

	@Override
	protected void work() {
		// TODO Auto-generated method stub
		super.execute();
	}

}
