package ezieco.eziflow.engine.action.impl;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;

public class Reply extends AbstractAction {

	private String variable;

	public Reply(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.REPLY, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		this.variable = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.VARIABLE);
		return this;
	}

	@Override
	protected void work() {
		super.currentThread = Thread.currentThread();
		if (super.isConcurrent()) {
			super.flowRuntimeContext.removetRuntimeContext();
		}

		Object rep = super.flowRuntimeContext.getVariableData().getValue(variable);
		super.flowRuntimeContext.setResponse(rep);
	}

}
