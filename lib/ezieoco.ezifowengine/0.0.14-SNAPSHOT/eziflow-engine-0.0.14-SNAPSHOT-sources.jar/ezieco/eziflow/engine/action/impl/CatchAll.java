package ezieco.eziflow.engine.action.impl;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;

/**
 * Fault 처리 정책 필요 TODO
 * 
 * @author cglee
 *
 */
public class CatchAll extends AbstractAction {

	public CatchAll(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.CATCHALL, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		return super.read(node);
	}

	@Override
	protected void work() {
		super.execute();
	}

}
