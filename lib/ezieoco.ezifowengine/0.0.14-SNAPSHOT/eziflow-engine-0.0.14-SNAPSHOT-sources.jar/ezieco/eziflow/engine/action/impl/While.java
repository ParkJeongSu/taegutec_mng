package ezieco.eziflow.engine.action.impl;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.expression.EziFlowExpression;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.Getter;

public class While extends AbstractAction {

	private final EziFlowExpression flowExpression;

	private boolean conditionResult = false;

	@Getter
	private String condition;
	@Getter
	private String collection;
	private String element;
	private String index;
	private String key;

	@Getter
	private int currentLoopCount = 0;

	public While(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.WHILE_LOOP, flowRuntimeContext, mediator);

		this.flowExpression = SingletonManager.getInstance().getSingletonInstance(EziFlowExpression.class).get();
	}

	@Override
	public Action init(Node node) {
		this.readCondition(node);
		this.readCollection(node);
		super.read(node);

		this.currentLoopCount = 0;
		return this;
	}

	private void readCondition(Node node) {
		this.condition = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.CONDITION);
	}

	private void readCollection(Node node) {
		this.collection = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.COLLECTION);
		this.element = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.ELEMENT);
		this.index = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.INDEX);
		this.key = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.KEY);
	}

	@Override
	protected void work() {
		super.currentThread = Thread.currentThread();
		if (StringUtils.isEmpty(this.condition)) {
			this.doWhileWithCollection();
		} else {
			this.doWhileWithCondition();
		}
	}

	private void doWhileWithCollection() {
		Object collectionValue = super.flowRuntimeContext.getVariableData().getValue(this.collection);
		if (collectionValue.getClass().isArray()) {
			int count = Array.getLength(collectionValue);

			for (int i = 0; i < count; i++) {
				if (super.flowRuntimeContext.isTerminate(this)) {
					break;
				}

				this.currentLoopCount++;

				super.flowRuntimeContext.getVariableData().setValue(this.index, i);
				super.flowRuntimeContext.getVariableData().setValue(this.element, Array.get(collectionValue, i));

				super.execute();
			}
		} else if (collectionValue instanceof List) {
			List<?> list = (List<?>) collectionValue;
			int count = list.size();

			for (int i = 0; i < count; i++) {
				if (super.flowRuntimeContext.isTerminate(this)) {
					break;
				}

				this.currentLoopCount++;

				super.flowRuntimeContext.getVariableData().setValue(this.element, list.get(i));

				super.execute();
			}
		} else if (collectionValue instanceof Map) {
			Map<?, ?> map = (Map<?, ?>) collectionValue;

			for (Entry<?, ?> entry : map.entrySet()) {
				if (super.flowRuntimeContext.isTerminate(this)) {
					break;
				}

				this.currentLoopCount++;

				super.flowRuntimeContext.getVariableData().setValue(this.key, entry.getKey());
				super.flowRuntimeContext.getVariableData().setValue(this.element, entry.getValue());

				super.execute();
			}
		} else {
			// TODO.
		}
	}

	private void doWhileWithCondition() {
		Object obj = null;
		while (!super.flowRuntimeContext.isTerminate(this)) {
			obj = this.flowExpression.xpathQuery(this.condition);
			this.conditionResult = ((Boolean) obj).booleanValue();

			this.currentLoopCount++;
			if (this.conditionResult) {
				super.execute();
			} else {
				break;
			}
		}
	}
}
