package ezieco.eziflow.engine.action.impl;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.expression.EziFlowExpression;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;

public class Expression extends AbstractAction {

	private List<String> conditionList = new CopyOnWriteArrayList<>();
	private final EziFlowExpression flowExpression;

	public Expression(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.EXPRESSION, flowRuntimeContext, mediator);
		this.flowExpression = SingletonManager.getInstance().getSingletonInstance(EziFlowExpression.class).get();
	}

	@Override
	public Action init(Node node) {
		NodeList nodeList = node.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node nodei = nodeList.item(i);
			if (nodei.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}

			if (nodei.getNodeName().equals(EziFlowConst.FUNCTION)) {
				String condition = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(nodei, EziFlowConst.VALUE);
				if (StringUtils.isNotEmpty(condition)) {
					this.conditionList.add(condition);
				}
			}
		}
		return this;
	}

	@Override
	protected void work() {
		this.currentThread = Thread.currentThread();
		for (String condition : this.conditionList) {
			this.flowExpression.xpathQuery(condition);
		}
	}

	public List<String> getFunctionList() {
		return this.conditionList;
	}
}
