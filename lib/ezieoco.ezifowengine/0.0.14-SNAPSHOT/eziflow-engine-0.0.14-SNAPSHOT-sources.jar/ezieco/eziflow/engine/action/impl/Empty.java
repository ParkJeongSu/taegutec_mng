package ezieco.eziflow.engine.action.impl;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;

public class Empty extends AbstractAction {

	public Empty(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.EMPTY_TASK, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		return this.read(node);
	}

	@Override
	protected void work() {
		this.execute();
	}

}
