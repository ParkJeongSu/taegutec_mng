package ezieco.eziflow.engine.action.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.data.InputData;
import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.event.internal.data.EziFlowInternalEvent;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.TypeConverterUtil;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;

public class Throw extends AbstractAction {

	private String faultName; // exception name
	private String faultVariable; // custom exception
	transient private List<InputData> inputDataList = new CopyOnWriteArrayList<InputData>();

	public Throw(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.THROW_EXCEPTION, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		this.faultName = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.FAULT_NAME);
		this.faultVariable = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.VARIABLE);

		this.addInputArgument(node);

		return this;
	}

	private void addInputArgument(Node node) {
		NodeList list = node.getChildNodes();

		for (int i = 0; i < list.getLength(); i++) {
			Node nodei = list.item(i);

			if (nodei.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}

			if (nodei.getNodeName().equals(EziFlowConst.INPUT)) {
				InputData inputData = null;

				String variableName = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(nodei, EziFlowConst.VARIABLE);
				if (StringUtils.isNotEmpty(variableName)) {
					String variableType = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(nodei, EziFlowConst.TYPE);

					inputData = new InputData(variableName, variableType, true);
				} else {
					String constant = XmlNodeUtils.getAttribute(nodei, EziFlowConst.CONSTANT);
					String constantType = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(nodei, EziFlowConst.TYPE);
					if (constantType == null) {
						throw new EziFlowException(
								ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.READ_NODE_ERROR)
										.args(EziFlowConst.TYPE, nodei, "").build());
					}

					inputData = new InputData(constant, constantType, false);
				}

				if (inputDataList.contains(inputData)) {
					throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.DUPLICATE_INPUT)
							.args(variableName).build());
				}

				inputDataList.add(inputData);
			}
		}
	}

	private void onException(Action action, Exception e) {
		try {
//			super.mediator.exceptionEventOccured(this, e);
			super.mediator.eventOccurred(
					EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(e).build());
		} catch (Exception ex) {
//			super.mediator.exceptionEventOccured(this, ex);
			super.mediator.eventOccurred(
					EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this).setException(ex).build());
		}
	}

	@Override
	protected void work() {
		try {
			super.currentThread = Thread.currentThread();

			if (StringUtils.isEmpty(this.faultName)) {
				return;
			}

			if (StringUtils.isEmpty(this.faultVariable)) {
				this.onException(this, new EziFlowException("Execute Throw Action. FaultVariable is Empty."));
				return;
			}

			Exception exception = (Exception) this.createFaultInstance();
			this.onException(this, exception);

		} catch (Exception ex) {
			this.onException(this, ex);
		}
	}

	private Object createFaultInstance() throws Exception {
		Class<? extends Object> faultClass = super.flowRuntimeContext.getVariableData().getVariable(this.faultVariable)
				.getClazz();

		int inputCount = this.inputDataList.size();
		Class<? extends Object>[] parameterTypes = new Class<?>[inputCount];
		Object[] initargs = new Object[inputCount];

		try {
			for (int i = 0; i < inputCount; i++) {
				InputData data = this.inputDataList.get(i);
				if (data.isVariable()) {
					initargs[i] = super.flowRuntimeContext.getVariableData().getValue(data.getInput());
					if (data.getType() == null) {
						parameterTypes[i] = super.flowRuntimeContext.getVariableData().getVariable(data.getInput())
								.getClazz();
					} else {
						parameterTypes[i] = data.getType();
					}
				} else {
					parameterTypes[i] = data.getType();
					initargs[i] = TypeConverterUtil.getValue(data.getClass(), data.getInput());
				}
			}

			Constructor<? extends Object> constructor = faultClass.getConstructor(parameterTypes);

			return constructor.newInstance(initargs);
		} catch (Exception ex) {
			return this.getFaultInstance(faultClass, initargs, ex);
		}
	}

	private Object getFaultInstance(Class<? extends Object> faultClass, Object[] initargs, Exception ex)
			throws Exception {
		Constructor<?>[] constructors = faultClass.getConstructors();

		for (Constructor<? extends Object> constructor : constructors) {
			Class<? extends Object>[] parameterTypes = constructor.getParameterTypes();
			if (parameterTypes.length != initargs.length) {
				continue;
			}

			boolean found = true;
			for (int i = 0; i < parameterTypes.length; i++) {
				if (parameterTypes[i].isInstance(initargs[i]) == false) {
					found = false;
					break;
				}
			}

			if (found) {
				try {
					return constructor.newInstance(initargs);
				} catch (InvocationTargetException e) {
					throw e;
				}
			}
		}

		throw ex;
	}

}
