package ezieco.eziflow.engine.action.impl;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.TypeConverterUtil;
import ezieco.eziflow.engine.utils.xml.XMLUtility;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Variables extends AbstractAction {

	public Variables(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.VARIABLES, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		NodeList variables = node.getChildNodes();

		for (int i = 0; i < variables.getLength(); i++) {
			Node itemNode = variables.item(i);
			if (itemNode.getNodeType() != Node.ELEMENT_NODE)
				continue;

			String varName = XmlNodeUtils.getAttribute(itemNode, EziFlowConst.NAME);
			String messageType = XmlNodeUtils.getAttribute(itemNode, EziFlowConst.MESSAGE_TYPE);
			String expression = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(itemNode, EziFlowConst.EXPRESSION);
			Class<? extends Object> clazz = TypeConverterUtil.resolveTypeFromClassDescriptor(messageType);

			Object object = getValueFromNode(itemNode, varName, clazz);
			this.flowRuntimeContext.getVariableData().registerVariable(varName, clazz, object, expression);
		}

		return this;
	}

	public void work() {
		if (log.isDebugEnabled())
			log.debug("work " + this);
	}

	private Object getValueFromNode(Node node, String vname, Class<? extends Object> clazz) {
		if (!TypeConverterUtil.isPrimitiveOrString(clazz))
			return null;

		String value = getTextValue(node);

		if (value != null && !clazz.equals(String.class))
			value = value.trim();

		return TypeConverterUtil.getValue(clazz, value);
	}

	private String getTextValue(Node node) {
		if (!node.hasChildNodes())
			return null;
		return XMLUtility.getInstance().getTextValue(node);
	}
}
