package ezieco.eziflow.engine.action;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.action.impl.Case;
import ezieco.eziflow.engine.action.impl.Catch;
import ezieco.eziflow.engine.action.impl.CatchAll;
import ezieco.eziflow.engine.action.impl.Expression;
import ezieco.eziflow.engine.action.impl.FaultHandler;
import ezieco.eziflow.engine.action.impl.Flow;
import ezieco.eziflow.engine.action.impl.Invoke;
import ezieco.eziflow.engine.action.impl.Otherwise;
import ezieco.eziflow.engine.action.impl.PartnerLinks;
import ezieco.eziflow.engine.action.impl.Receive;
import ezieco.eziflow.engine.action.impl.Reply;
import ezieco.eziflow.engine.action.impl.Sequence;
import ezieco.eziflow.engine.action.impl.Switch;
import ezieco.eziflow.engine.action.impl.Terminate;
import ezieco.eziflow.engine.action.impl.Throw;
import ezieco.eziflow.engine.action.impl.Variables;
import ezieco.eziflow.engine.action.impl.Wait;
import ezieco.eziflow.engine.action.impl.While;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.event.internal.Mediator;

public abstract class ActionBuilder {
	private static final Map<String, ActionCreator> actionMap;

	static {
		Map<String, ActionCreator> map = new HashMap<>();
		map.put(ActionEnum.PARTNER_LINKS.getName(), PartnerLinks::new);
		map.put(ActionEnum.VARIABLES.getName(), Variables::new);
		map.put(ActionEnum.SEQUENCE.getName(), Sequence::new);
		map.put(ActionEnum.RECEIVE.getName(), Receive::new);
		map.put(ActionEnum.INVOKE.getName(), Invoke::new);
		map.put(ActionEnum.SWITCH_STATE.getName(), Switch::new);
		map.put(ActionEnum.CASE_OPTION.getName(), Case::new);
		map.put(ActionEnum.OTHERWISE_OPTION.getName(), Otherwise::new);
		map.put(ActionEnum.WHILE_LOOP.getName(), While::new);
		map.put(ActionEnum.REPLY.getName(), Reply::new);
		map.put(ActionEnum.WAIT.getName(), Wait::new);
		map.put(ActionEnum.TERMINATE.getName(), Terminate::new);
		map.put(ActionEnum.THROW_EXCEPTION.getName(), Throw::new);
		map.put(ActionEnum.FLOW.getName(), Flow::new);
		map.put(ActionEnum.FAULTHANDLERS.getName(), FaultHandler::new);
		map.put(ActionEnum.CATCH_ERROR.getName(), Catch::new);
		map.put(ActionEnum.CATCHALL.getName(), CatchAll::new);
		map.put(ActionEnum.EXPRESSION.getName(), Expression::new);

		actionMap = Collections.unmodifiableMap(map);
	}

	public static AbstractAction createAction(Node node, EziFlowRuntimeContext flowRuntimeContext, Mediator mediator,
			AbstractAction parentAction) {

		String nodeName = node.getNodeName();
		ActionCreator actionCreator = actionMap.get(nodeName);

		if (actionCreator == null) {
			return null;
		}

		AbstractAction childAction = actionCreator.create(flowRuntimeContext, mediator);
		childAction.setNodeName(nodeName, node);
		childAction.setParent(parentAction);

		return childAction;
	}

	@FunctionalInterface
	public interface ActionCreator {
		AbstractAction create(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator);
	}
}
