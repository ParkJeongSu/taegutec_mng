package ezieco.eziflow.engine.action;

//TODO 이름을 ActionType으로 변경 예정
public enum ActionEnum {
	PARTNER_LINKS("partnerLinks"),
	VARIABLES("variables"),
	SEQUENCE("sequence"),
	RECEIVE("receive"),
	INVOKE("invoke"),
	INVOKE_WORKFLOW("invokeWorkflow"),	
	SWITCH_STATE("switch"),
	CASE_OPTION("case"),
	OTHERWISE_OPTION("otherwise"),
	WHILE_LOOP("while"),
	REPLY("reply"),
	WAIT("wait"),
	TERMINATE("terminate"),
	THROW_EXCEPTION("throw"),
	FLOW("flow"),
	FAULTHANDLERS("faultHandlers"),
	CATCH_ERROR("catch"),
	CATCHALL("catchAll"),
	EXPRESSION("expression"),
	EMPTY_TASK("empty"),
	EXECUTE_TASK("execute");

	private String name;

	ActionEnum(String name) {
		this.name = name;
	}
	
    public String getName() {
        return this.name;
    }
}
