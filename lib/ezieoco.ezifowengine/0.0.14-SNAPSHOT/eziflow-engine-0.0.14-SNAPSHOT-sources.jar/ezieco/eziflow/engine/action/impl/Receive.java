package ezieco.eziflow.engine.action.impl;

import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.concurrent.ManagedThreadPool;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.data.CorrelationRecord;
import ezieco.eziflow.engine.data.InputDataCollection;
import ezieco.eziflow.engine.data.support.VarDataItem;
import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.event.internal.data.EziFlowInternalEvent;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.expression.EziFlowExpression;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Receive extends AbstractAction {

	private boolean ignoreTimeout = false;

	private boolean timeoutOccured = false;

	private int timeout;

	@Getter
	private String timeoutString = "";

	@Getter
	private String correlationVariableName = "";

	private String outputVariableName = "";

	private final InputDataCollection inputDataCollection = new InputDataCollection();

	private final ManagedThreadPool threadPoolManager;

	private final EziFlowExpression flowExpression;

	private final ReentrantLock lock = new ReentrantLock();
	private final Condition condition = lock.newCondition();
	private volatile boolean signaled = false;

	public Receive(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.RECEIVE, flowRuntimeContext, mediator);

		this.threadPoolManager = SingletonManager.getInstance().getSingletonInstance(ManagedThreadPool.class).get();
		this.timeout = this.threadPoolManager.getReceiveTimeout();

		this.flowExpression = SingletonManager.getInstance().getSingletonInstance(EziFlowExpression.class).get();
	}

	public void awaken(Object... objects) {
		super.flowRuntimeContext.setRequests(objects);

		lock.lock();
		try {
			signaled = true;
			condition.signal();
		} finally {
			lock.unlock();
		}
	}

	@Override
	public Action init(Node node) {
		parseTimeoutSettings(node);
		parseConfigurationElements(node);
		return this;
	}

	private void parseTimeoutSettings(Node node) {
		this.timeoutString = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node, EziFlowConst.TIMEOUT);
		String ignoreTimeoutValue = XmlNodeUtils.getAttrValueIgnoreExceptionNullReturn(node,
				EziFlowConst.IGNORE_TIMEOUT);

		if (ignoreTimeoutValue != null) {
			try {
				this.ignoreTimeout = Boolean.parseBoolean(ignoreTimeoutValue);
			} catch (NumberFormatException ex) {
				log.warn("Invalid boolean value for attribute '{}': {}", EziFlowConst.IGNORE_TIMEOUT,
						ignoreTimeoutValue, ex);
				this.ignoreTimeout = false;
			}
		}
	}

	private void parseConfigurationElements(Node node) {
		NodeList nodeList = node.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node childNode = nodeList.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				processElement(childNode);
			}
		}
	}

	private void processElement(Node node) {
		String nodeName = node.getNodeName();
		switch (nodeName) {
		case EziFlowConst.CORRELATION:
			this.correlationVariableName = XmlNodeUtils.getAttribute(node, EziFlowConst.VARIABLE);
			break;
		case EziFlowConst.INPUT:
			this.inputDataCollection.addInputs(node);
			break;
		case EziFlowConst.OUTPUT:
			this.outputVariableName = XmlNodeUtils.getAttribute(node, EziFlowConst.VARIABLE);
			break;
		default:
			// Optionally handle unknown node types if necessary
			break;
		}
	}

	@Override
	protected void work() {
		if (super.isConcurrent()) {
			this.flowRuntimeContext.setCurrentRuntimeContext();
		}

		super.currentThread = Thread.currentThread();

		try {
			if (super.flowRuntimeContext.isReceived()) {
				waitMethod();
			}

			if(!this.timeoutOccured) {
				processReceive();
			}
		} finally {
			super.flowRuntimeContext.setReceived(true);
			if (super.isConcurrent()) {
				this.flowRuntimeContext.removetRuntimeContext();
			}
		}
	}

	private void processReceive() {
		setVariables();
		evaluateVariableExpression();
	}

	private void evaluateVariableExpression() {
		for (Entry<String, VarDataItem> entry : this.flowRuntimeContext.getVariableData().getVariables().entrySet()) {
			VarDataItem item = entry.getValue();
			String expr = item.getExpression();

			if (StringUtils.isNotEmpty(expr)) {
				try {
					Object result = this.flowExpression.xpathQuery(expr);
					this.flowRuntimeContext.getVariableData().setValue(entry.getKey(), result);
				} catch (Exception e) {
					log.error("Error evaluating expression '{}' for variable '{}': {}", expr, entry.getKey(),
							e.getMessage(), e);
				}
			}
		}
	}

	private void waitMethod() {
		signaled = false;

		if (checkReservedCorrelationsNoWait()) {
			// 예약된 상관관계로 즉시 처리된 경우 타임아웃은 발생하지 않음 -> output=false 기록
			setOutput();
			return;
		}

		this.timeoutOccured = awaitWithTimeout();
		// 대기 결과에 따라 output 변수(true/false) 설정
		setOutput();

		if (timeoutOccured) {
			log.warn("Timeout occurred for Receive action: {} with correlation: {}", 
					super.getName(), getCorrelationId());
			
			super.mediator.eventOccurred(EziFlowInternalEvent.newBuilder(EventType.ACTION_TIMEOUT, this).build());

			if (this.ignoreTimeout) {
				log.info("Timeout ignored for Receive action: {} due to ignoreTimeout=true", super.getName());
				return;
			}

			log.error("Throwing timeout exception for Receive action: {} with correlation: {}", 
					super.getName(), getCorrelationId());
			EziFlowException timeoutException = new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.RECEIVE_TIMEOUT)
							.args(this.correlationVariableName, super.getName()).build());
			super.mediator.eventOccurred(EziFlowInternalEvent.newBuilder(EventType.ACTION_FAILED, this)
					.setException(timeoutException).build());
			throw timeoutException;
		}
	}

	private void setOutput() {
		if (StringUtils.isNotEmpty(this.outputVariableName)) {
			try {
				this.flowRuntimeContext.getVariableData().setValue(this.outputVariableName, this.timeoutOccured);
			} catch (Exception e) {
				log.warn("Failed to set output variable '{}' with value {}: {}", this.outputVariableName,
						this.timeoutOccured, e.getMessage(), e);
			}
		}
	}

	private boolean checkReservedCorrelationsNoWait() {
		Object correlationIdToCheck = getCorrelationId();
		if (correlationIdToCheck == null) {
			return false;
		}

		CorrelationRecord data = this.threadPoolManager.removeReservedCorrelations(correlationIdToCheck);
		if (data == null) {
			return false;
		}

		this.flowRuntimeContext.setRequests(data.getAwakeArgs());
		return true;
	}

	private void setVariables() {
		if (this.flowRuntimeContext.isTerminate(this)) {
			return;
		}
		this.flowRuntimeContext.getVariableData().setValues(this.inputDataCollection.getInputs(),
				this.flowRuntimeContext.getRequests());
	}

	private boolean awaitWithTimeout() {
		Object correlationIdForSleep = getCorrelationId();
		if (correlationIdForSleep == null) {
			throw new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.INVALID_CORRELATION_ID).build());
		}

		this.threadPoolManager.setCorrelations(correlationIdForSleep, this);

		lock.lock();
		try {
			// Spurious wakeup 처리를 위한 루프와 시간 추적
			long timeoutMs = getTimeout();
			long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs);

			while (!signaled) {
				long remainingNanos = deadline - System.nanoTime();
				if (remainingNanos <= 0) {
					// 타임아웃 발생
					log.warn("Timeout reached for Receive action: {} with correlation: {}", 
							super.getName(), correlationIdForSleep);
					return true;
				}

				try {
					boolean awakenedBySignal = condition.await(remainingNanos, TimeUnit.NANOSECONDS);
					if (!awakenedBySignal) {
						// 타임아웃으로 깨어남
						return true;
					}
					// signal로 깨어남 - while 조건에서 signaled 재확인 (spurious wakeup 처리)
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
					log.debug("Wait interrupted for Receive action: {} with correlation: {}", 
							super.getName(), correlationIdForSleep);
					return true;
				}
			}
			// signaled가 true가 되어 루프 탈출 - 정상적인 signal 수신
			return false;
		} finally {
			lock.unlock();
			this.threadPoolManager.removeCorrelations(correlationIdForSleep);
		}
	}

	private Object getCorrelationId() {
		if (StringUtils.isEmpty(getCorrelationVariableName())) {
			return this.flowRuntimeContext.getDefaultCorrelationId();
		} else {
			return this.flowRuntimeContext.getVariableData().getValue(getCorrelationVariableName());
		}
	}

	private int getTimeout() {
		if (StringUtils.isEmpty(this.timeoutString)) {
			return this.timeout;
		}

		try {
			if (StringUtils.isNumeric(this.timeoutString)) {
				this.timeout = Integer.parseInt(this.timeoutString);
			} else {
				Object timeoutValue = this.flowRuntimeContext.getVariableData().getValue(this.timeoutString);
				if (timeoutValue instanceof Number) {
					this.timeout = ((Number) timeoutValue).intValue();
				} else {
					log.warn("Timeout value from variable '{}' is not a number: {}", this.timeoutString, timeoutValue);
					// Consider a default timeout or throwing an exception
				}
			}
		} catch (Exception e) {
			log.warn("Error parsing timeout value '{}': {}", this.timeoutString, e.getMessage(), e);
			// Consider a default timeout or throwing an exception
		}
		return this.timeout;
	}
}