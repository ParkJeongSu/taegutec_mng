package ezieco.eziflow.engine.action.impl;

import java.util.stream.IntStream;

import javax.xml.namespace.QName;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ezieco.eziflow.engine.action.AbstractAction;
import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.core.EziFlowAppContext;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.data.PartnerData;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;

public class PartnerLinks extends AbstractAction {

	public PartnerLinks(EziFlowRuntimeContext flowRuntimeContext, Mediator mediator) {
		super(ActionEnum.PARTNER_LINKS, flowRuntimeContext, mediator);
	}

	@Override
	public Action init(Node node) {
		NodeList nodes = node.getChildNodes();

		// TODO 메소드 이름을 변경할 부분이 있으면 변경하자.
//		this.flowRuntimeContext.setPartnerData(new PartnerData(this.flowRuntimeContext.getFlowAppContext()));
		this.flowRuntimeContext
				.setPartnerData(new PartnerData(SingletonManager.getInstance().getSingletonInstance(EziFlowAppContext.class).get()));

//		Stream type의 문법이 보기 불편할수 있어서
//		for (int i = 0; i < nodes.getLength(); i++)
//		{
//			Node nodei = nodes.item(i);
//			if (nodei.getNodeType() != Node.ELEMENT_NODE) continue;
//
//			String pname = NodeUtils.getAttribute(nodei, FlowConst.NAME);
//
//			String pltValue = NodeUtils.getAttribute(nodei, FlowConst.PARTNER_LINK_TYPE);
//			QName pltQName = NodeUtils.getAttrQName(nodei, FlowConst.PARTNER_LINK_TYPE);
//
//			this.flowRuntimeContext.getPartnerData().registerPartnerData(pname, pltValue, pltQName);
//		}

		IntStream.range(0, nodes.getLength()).mapToObj(nodes::item)
				.filter(nodei -> nodei.getNodeType() == Node.ELEMENT_NODE).forEach(nodei -> {
					String pname = XmlNodeUtils.getAttribute(nodei, EziFlowConst.NAME);
					String pltValue = XmlNodeUtils.getAttribute(nodei, EziFlowConst.PARTNER_LINK_TYPE);
					QName pltQName = XmlNodeUtils.getAttrQName(nodei, EziFlowConst.PARTNER_LINK_TYPE);

					this.flowRuntimeContext.getPartnerData().registerPartnerData(pname, pltValue, pltQName);
				});

		return this;
	}

	protected void work() {
		this.flowRuntimeContext.getPartnerData().initializeBeansAndSetReferenceWF();
	}
}
