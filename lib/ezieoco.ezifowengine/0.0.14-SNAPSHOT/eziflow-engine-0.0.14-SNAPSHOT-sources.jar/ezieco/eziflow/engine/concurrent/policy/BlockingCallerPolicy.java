package ezieco.eziflow.engine.concurrent.policy;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BlockingCallerPolicy implements RejectedExecutionHandler {

	private final ReentrantLock lock = new ReentrantLock();
	private final Condition spaceAvailable = lock.newCondition();

	@Override
	public void rejectedExecution(Runnable runnable, ThreadPoolExecutor executor) {
		lock.lock();
		try {
			log.warn(String.format(
					"{\"message\": \"Active thread count has reached maxPoolSize. Waiting for a thread to become available in the pool.\", "
							+ "\"activeSize\": %d, \"maxPoolSize\": %d, \"queueSize\": %d}",
					executor.getActiveCount(), executor.getMaximumPoolSize(), executor.getQueue().size()));

			while (executor.getMaximumPoolSize() == executor.getActiveCount()) {
				spaceAvailable.await();
			}

			executor.execute(runnable);
			log.info("Asynchronous operations have resumed. [activeSize={}, maxPoolSize={}, queueSize={}]",
					executor.getActiveCount(), executor.getMaximumPoolSize(), executor.getQueue().size());
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
			log.error("Thread was interrupted while waiting for a space in the pool", ex);
		} finally {
			lock.unlock();
		}
	}

	public void signalThreadCompletion() {
		lock.lock();
		try {
			spaceAvailable.signal();
		} finally {
			lock.unlock();
		}
	}
}
