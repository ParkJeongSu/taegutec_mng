package ezieco.eziflow.engine.concurrent;

public interface ThreadEventListener {
    void beforeExecute(Thread t, Runnable r);
    void afterExecute(Runnable r, Throwable t);
}
