package ezieco.eziflow.engine.concurrent.eventloop.data;

public interface SerializedJob {
	void execute();
}
