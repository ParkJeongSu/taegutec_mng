package ezieco.eziflow.engine.concurrent.eventloop.data;

import ezieco.eziflow.engine.concurrent.eventloop.FlowEventLoop;

public interface FlowEventLoopWrapper {
	FlowEventLoop getEventLoop();

	long getLastAccessTime();

	void updateLastAccessTime();
}