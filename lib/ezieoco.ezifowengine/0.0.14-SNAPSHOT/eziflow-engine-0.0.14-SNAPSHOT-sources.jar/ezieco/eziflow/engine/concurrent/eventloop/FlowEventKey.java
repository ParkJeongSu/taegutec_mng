package ezieco.eziflow.engine.concurrent.eventloop;

public interface FlowEventKey {
	@Override
	boolean equals(Object obj);

	@Override
	int hashCode();
}
