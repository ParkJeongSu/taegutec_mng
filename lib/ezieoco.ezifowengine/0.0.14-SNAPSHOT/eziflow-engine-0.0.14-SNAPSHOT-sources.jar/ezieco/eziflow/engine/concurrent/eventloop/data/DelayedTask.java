package ezieco.eziflow.engine.concurrent.eventloop.data;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

import lombok.Getter;

public class DelayedTask<T> implements Delayed {

	@Getter
	private final T data;
	private final long createTime;
	private final long expirationTime;

	public DelayedTask(T data, long delayInMilliseconds) {
		this.data = data;
		this.createTime = System.currentTimeMillis();
		this.expirationTime = this.createTime + delayInMilliseconds;
	}

	@Override
	public int compareTo(Delayed o) {
		if (o instanceof DelayedTask) {
			return Long.compare(this.expirationTime, ((DelayedTask<?>) o).expirationTime);
		}
		throw new IllegalArgumentException("Parameter must be a DelayedTask");
	}

	@Override
	public long getDelay(TimeUnit unit) {
		long now = System.currentTimeMillis();
		if (createTime > now) {
			return -1;
		}

		long diff = expirationTime - now;
		return unit.convert(diff, TimeUnit.MILLISECONDS);
	}

}
