package ezieco.eziflow.engine.concurrent.eventloop.impl;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.ScheduledExecutorService;

import ezieco.eziflow.engine.concurrent.eventloop.FlowEventLoop;
import ezieco.eziflow.engine.concurrent.eventloop.data.DelayedTask;
import ezieco.eziflow.engine.concurrent.eventloop.data.SerializedJob;
import ezieco.eziflow.engine.concurrent.eventloop.data.impl.SerializedJobImpl;
import ezieco.eziflow.engine.concurrent.eventloop.worker.ScheduleWorker;

public class FlowEventLoopImpl implements FlowEventLoop {
	private final DelayQueue<DelayedTask<SerializedJob>> taskQueue = new DelayQueue<>();
	private final ScheduleWorker scheduleWorker;

	public FlowEventLoopImpl(ScheduledExecutorService scheduledExecutorService) {
		scheduleWorker = new ScheduleWorker(scheduledExecutorService, taskQueue);
	}

	@Override
	public void start() {
		scheduleWorker.start();
	}

	@Override
	public void stop() {
		scheduleWorker.stop();
	}

	@Override
	public void submit(Runnable task, long delayInMillis) {
		SerializedJob job = new SerializedJobImpl(task);
		DelayedTask<SerializedJob> delayedTask = new DelayedTask<>(job, delayInMillis);
		taskQueue.put(delayedTask);
	}
}
