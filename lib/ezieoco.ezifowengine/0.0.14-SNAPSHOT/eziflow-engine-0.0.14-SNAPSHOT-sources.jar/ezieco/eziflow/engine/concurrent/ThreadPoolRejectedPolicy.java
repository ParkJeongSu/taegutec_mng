package ezieco.eziflow.engine.concurrent;

public enum ThreadPoolRejectedPolicy {
    EZI_FLOW_DEFAULT_POLICY,
    CALLER_WAITS_POLICY,
    ABORT_POLICY,
    CALLER_RUNS_POLICY,
    DISCARD_POLICY,
    DISCARD_OLDEST_POLICY;
}
