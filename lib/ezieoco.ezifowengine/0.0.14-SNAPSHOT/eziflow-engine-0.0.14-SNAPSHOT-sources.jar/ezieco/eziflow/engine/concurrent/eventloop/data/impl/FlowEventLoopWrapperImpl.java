package ezieco.eziflow.engine.concurrent.eventloop.data.impl;

import ezieco.eziflow.engine.concurrent.eventloop.FlowEventLoop;
import ezieco.eziflow.engine.concurrent.eventloop.data.FlowEventLoopWrapper;

public class FlowEventLoopWrapperImpl implements FlowEventLoopWrapper {
	private final FlowEventLoop eventLoop;
	private volatile long lastAccessTime;

	public FlowEventLoopWrapperImpl(FlowEventLoop eventLoop) {
		this.eventLoop = eventLoop;
		updateLastAccessTime();
	}

	@Override
	public FlowEventLoop getEventLoop() {
		return eventLoop;
	}

	@Override
	public long getLastAccessTime() {
		return lastAccessTime;
	}

	@Override
	public void updateLastAccessTime() {
		lastAccessTime = System.nanoTime(); // 유지
	}
}
