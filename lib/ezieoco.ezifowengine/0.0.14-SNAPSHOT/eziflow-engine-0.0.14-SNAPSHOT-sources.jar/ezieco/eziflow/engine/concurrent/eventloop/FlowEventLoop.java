package ezieco.eziflow.engine.concurrent.eventloop;

public interface FlowEventLoop {
	void start();

	void stop();

	void submit(Runnable task, long delayInMillis);
}
