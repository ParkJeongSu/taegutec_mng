package ezieco.eziflow.engine.concurrent.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.action.PostAction;
import ezieco.eziflow.engine.action.PreAction;
import ezieco.eziflow.engine.action.impl.ExecuteAction;
import ezieco.eziflow.engine.action.impl.Receive;
import ezieco.eziflow.engine.concurrent.CorrelationCleanupTask;
import ezieco.eziflow.engine.concurrent.ExecutorProvider;
import ezieco.eziflow.engine.concurrent.ManagedThreadPool;
import ezieco.eziflow.engine.concurrent.policy.BlockingCallerPolicy;
import ezieco.eziflow.engine.concurrent.support.EziFlowThreadPoolExecutor;
import ezieco.eziflow.engine.config.EziFlowProperties;
import ezieco.eziflow.engine.config.EziFlowProperties.ThreadProperties;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.data.CorrelationRecord;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EziFlowThreadPoolManagerImpl implements ManagedThreadPool, ExecutorProvider {

	private final ThreadProperties threadProperties;
	private final Map<Object, Action> correlations = new ConcurrentHashMap<>();
	private final Map<Object, CorrelationRecord> reservedCorrelations = new ConcurrentHashMap<>();
	private CorrelationCleanupTask cleanupTask;

	@Getter
	@Setter
	private int receiveTimeout = 5000;

	private ThreadPoolExecutor threadPoolExecutor = null;

	public EziFlowThreadPoolManagerImpl(EziFlowProperties flowProperties) {
		this.threadProperties = flowProperties.getThreadProperties();
	}

	public void init() {
		RejectedExecutionHandler rejectedExecutionHandler = SingletonManager.getInstance()
				.getSingletonInstance(RejectedExecutionHandler.class).get();

		this.threadPoolExecutor = new EziFlowThreadPoolExecutor(this.threadProperties.getCorePoolSize(),
				this.threadProperties.getMaxPoolSize(), this.threadProperties.getKeepAliveTime(), TimeUnit.MILLISECONDS,
				createQueue(), rejectedExecutionHandler, this);

		this.cleanupTask = new CorrelationCleanupTask(this.threadProperties.getCorrelationDataRetentionPeriod(),
				this.threadProperties.getCorrelationCleanupInterval(), reservedCorrelations);
		this.cleanupTask.startCleanupTask();

		StringBuilder summaryInfo = new StringBuilder();
		summaryInfo.append("{").append("\"Eziflow ThreadPool\": {").append("\"Core\": ")
				.append(threadProperties.getCorePoolSize()).append(", ").append("\"Max\": ")
				.append(threadProperties.getMaxPoolSize()).append(", ").append("\"QueueSize\": ")
				.append(threadProperties.getQueueSize()).append(", ").append("\"KeepAlive\": ")
				.append(threadProperties.getKeepAliveTime()).append(", ").append("\"CorrelationDataRetentionPeriod\": ")
				.append(threadProperties.getCorrelationDataRetentionPeriod()).append(", ")
				.append("\"CorrelationCleanupInterval\": ").append(threadProperties.getCorrelationCleanupInterval())
				.append("}").append("}");

		log.info(summaryInfo.toString());
	}

//	public void execute(Runnable command) {
//		if (this.threadPool == null) {
//			throw new FlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NullPointer_Error)
//					.args("threadPool").build());
//		}
//
//		this.threadPool.execute(command);
//	}

	// TODO
	// 지금은 List<Action> 히스토리를 반환한다.
	// 다음에는 return object 만들 예정
	public Future<?> submit(Action action) {
		if (this.threadPoolExecutor == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NULL_POINTER_ERROR)
					.args("threadPool").build());
		}

		return this.threadPoolExecutor.submit(() -> {

			// Pre Action
			try {
				Arrays.stream(action.getExecuteAction().getFlowRuntimeContext().getPreActions())
						.forEach(PreAction::execute);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}

			try {
				action.run();

				if (action.getActionType() == ActionEnum.EXECUTE_TASK) {
					return ((ExecuteAction) action).getActionList();
				}
				return null;
			} finally {
				// Post Action - 항상 실행 (cleanup 용도)
				try {
					Arrays.stream(action.getExecuteAction().getFlowRuntimeContext().getPostActions())
							.forEach(PostAction::execute);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}
			}
		});
	}

	public Future<?> submit(Runnable task) {
		if (this.threadPoolExecutor == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NULL_POINTER_ERROR)
					.args("threadPool").build());
		}

		return this.threadPoolExecutor.submit(task);
	}

	public boolean awake(Object correlationId, Object... args) {
		if (!this.correlations.containsKey(correlationId)) {
			this.reservedCorrelations.put(correlationId, new CorrelationRecord(args));
			return false;
		}

		try {
			Receive receive = (Receive) correlations.remove(correlationId);
			receive.awaken(args);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}

		return true;
	}

	public void setCorrelations(Object correlationId, Action action) {
		this.correlations.put(correlationId, action);
	}

	public Action removeCorrelations(Object correlationId) {
		return this.correlations.remove(correlationId);
	}

	public CorrelationRecord removeReservedCorrelations(Object correlationId) {
		return this.reservedCorrelations.remove(correlationId);
	}

	private BlockingQueue<Runnable> createQueue() {
		if (this.threadProperties.getQueueSize() > 0)
			return new ArrayBlockingQueue<>(this.threadProperties.getQueueSize());
		else
			return new SynchronousQueue<>();
	}

	@Override
	public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
		return this.threadPoolExecutor.awaitTermination(timeout, unit);
	}

	@Override
	public List<Runnable> shutdownNow() {
		return this.threadPoolExecutor.shutdownNow();
	}

	@Override
	public boolean hasCorrelationId(String coldId) {
		return this.correlations.containsKey(coldId);
	}

	@Override
	public void shutdown() {
		this.threadPoolExecutor.shutdown();
	}

	@Override
	public List<Runnable> shutdown(long timeout, TimeUnit unit) {
		this.threadPoolExecutor.shutdown();
		try {
			if (this.threadPoolExecutor.awaitTermination(timeout, unit)) {
				return this.threadPoolExecutor.shutdownNow();
			}

			cleanupTask.stopCleanupTask();
		} catch (InterruptedException e) {
			log.error(e.getMessage(), e);
			return this.threadPoolExecutor.shutdownNow();
		}

		return new ArrayList<>();
	}

	@Override
	public void beforeExecute(Thread t, Runnable r) {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterExecute(Runnable r, Throwable t) {
		RejectedExecutionHandler rejectedExecutionHandler = SingletonManager.getInstance()
				.getSingletonInstance(RejectedExecutionHandler.class).get();

		if (rejectedExecutionHandler == null) {
			log.error("Cannot found RejectedExecutionHandler.class");
			return;
		}

		if (rejectedExecutionHandler instanceof BlockingCallerPolicy) {
			((BlockingCallerPolicy) rejectedExecutionHandler).signalThreadCompletion();
		}
	}

	@Override
	public ExecutorService getExecutorService() {
		return this.threadPoolExecutor;
	}
}
