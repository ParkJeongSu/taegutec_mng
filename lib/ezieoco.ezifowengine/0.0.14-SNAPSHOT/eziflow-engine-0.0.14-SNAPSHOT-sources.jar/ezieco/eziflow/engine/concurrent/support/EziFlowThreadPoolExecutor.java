package ezieco.eziflow.engine.concurrent.support;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import ezieco.eziflow.engine.concurrent.ThreadEventListener;

public class EziFlowThreadPoolExecutor extends ThreadPoolExecutor {

	private final ThreadEventListener listener; // 이벤트 리스너, 변경 불가

	public EziFlowThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
			BlockingQueue<Runnable> workQueue, ThreadEventListener listener) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
		this.listener = listener;
	}

	public EziFlowThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
			BlockingQueue<Runnable> workQueue, RejectedExecutionHandler handler, ThreadEventListener listener) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, handler);
		this.listener = listener;
	}

	// 스레드 실행 전 호출
	@Override
	protected void beforeExecute(Thread t, Runnable r) {
		super.beforeExecute(t, r);
		if (listener != null) {
			listener.beforeExecute(t, r);
		}
	}

	// 스레드 실행 후 호출
	@Override
	protected void afterExecute(Runnable r, Throwable t) {
		super.afterExecute(r, t);
		if (listener != null) {
			listener.afterExecute(r, t);
		}
	}
}
