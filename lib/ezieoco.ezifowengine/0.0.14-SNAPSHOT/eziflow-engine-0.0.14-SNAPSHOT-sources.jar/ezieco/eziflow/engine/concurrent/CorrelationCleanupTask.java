package ezieco.eziflow.engine.concurrent;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import ezieco.eziflow.engine.data.CorrelationRecord;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class CorrelationCleanupTask {

	private final int correlationDataRetentionPeriod;
	private final int correlationCleanupInterval;
	private final Map<Object, CorrelationRecord> correlationDataMap;
	private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

	// Start the cleanup process with a scheduled thread
	public void startCleanupTask() {
		scheduler.scheduleAtFixedRate(this::run, 0, correlationCleanupInterval, TimeUnit.MILLISECONDS);
	}

	// Stop the cleanup process
	public void stopCleanupTask() {
		if (!scheduler.isShutdown()) {
			scheduler.shutdownNow();
		}
	}

	private void run() {
		try {
			List<Object> expiredDataKeys = getExpiredDataKeys();

			if (!expiredDataKeys.isEmpty()) {
				removeExpiredCorrelations(expiredDataKeys);
			} else {
				logNoCleanupRequired();
			}
		} catch (Exception ex) {
			log.error("An error occurred during the cleanup process: {}", ex.getMessage(), ex);
		}
	}

	private List<Object> getExpiredDataKeys() {
		LocalDateTime now = LocalDateTime.now();

		return correlationDataMap.entrySet().stream()
				.filter(entry -> isExpired(entry.getValue().getCreationTime(), now)).map(Entry::getKey)
				.collect(Collectors.toList());
	}

	private boolean isExpired(LocalDateTime creationTime, LocalDateTime now) {
		return now.compareTo(creationTime) > correlationDataRetentionPeriod;
	}

	private void removeExpiredCorrelations(List<Object> expiredDataKeys) {
		expiredDataKeys.forEach(correlationDataMap::remove);

		String expiredKeys = String.join(", ", expiredDataKeys.toString());
		log.warn("Expired correlation data has been removed: {}.", expiredKeys);
	}

	private void logNoCleanupRequired() {
		if (log.isDebugEnabled()) {
			log.debug("No expired correlation data to remove.");
		}
	}
}
