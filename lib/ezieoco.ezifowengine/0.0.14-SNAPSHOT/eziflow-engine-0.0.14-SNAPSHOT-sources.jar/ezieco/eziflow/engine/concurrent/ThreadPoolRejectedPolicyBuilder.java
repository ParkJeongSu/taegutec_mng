package ezieco.eziflow.engine.concurrent;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy;
import java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy;
import java.util.concurrent.ThreadPoolExecutor.DiscardPolicy;

import ezieco.eziflow.engine.concurrent.policy.BlockingCallerPolicy;
import ezieco.eziflow.engine.concurrent.policy.CallerWaitsPolicy;
import ezieco.eziflow.engine.config.EziFlowProperties.ThreadProperties;

public abstract class ThreadPoolRejectedPolicyBuilder {

	private ThreadPoolRejectedPolicyBuilder() {
	}

	public static RejectedExecutionHandler create(ThreadPoolRejectedPolicy policy, ThreadProperties threadProperties) {
		switch (policy) {
		case ABORT_POLICY:
			return new AbortPolicy();
		case CALLER_RUNS_POLICY:
			return new CallerRunsPolicy();
		case DISCARD_POLICY:
			return new DiscardPolicy();
		case DISCARD_OLDEST_POLICY:
			return new DiscardOldestPolicy();
		case CALLER_WAITS_POLICY:
			return new CallerWaitsPolicy();
		default:
			return new BlockingCallerPolicy();
		}
	}

}
