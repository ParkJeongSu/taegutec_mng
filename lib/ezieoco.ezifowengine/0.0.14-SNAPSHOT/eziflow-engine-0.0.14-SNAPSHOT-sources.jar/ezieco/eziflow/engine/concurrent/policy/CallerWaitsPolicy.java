package ezieco.eziflow.engine.concurrent.policy;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CallerWaitsPolicy implements RejectedExecutionHandler {

	@Override
	public void rejectedExecution(Runnable runnable, ThreadPoolExecutor executor) {
		log.warn(
				"Active thread count has reached maxPoolSize [activeSize={}, maxPoolSize={}, queueSize={}]. Wait for a thread available in the pool.",
				executor.getActiveCount(), executor.getMaximumPoolSize(), executor.getQueue().size());

		while (executor.getMaximumPoolSize() <= executor.getActiveCount()) {
			try {
				TimeUnit.MILLISECONDS.sleep(100);
			} catch (InterruptedException e) {
				log.error(e.getMessage(), e);
			}
		}

		executor.execute(runnable);
		log.warn("Asynchronous operations have resumed. [activieSize={}, maxPoolSize={}, queueSize={}]",
				executor.getActiveCount(), executor.getMaximumPoolSize(), executor.getQueue().size());
	}
}
