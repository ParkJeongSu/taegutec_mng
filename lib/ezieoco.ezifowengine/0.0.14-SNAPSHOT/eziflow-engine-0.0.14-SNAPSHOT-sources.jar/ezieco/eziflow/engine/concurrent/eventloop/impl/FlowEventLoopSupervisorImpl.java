package ezieco.eziflow.engine.concurrent.eventloop.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import ezieco.eziflow.engine.concurrent.eventloop.FlowEventKey;
import ezieco.eziflow.engine.concurrent.eventloop.FlowEventLoop;
import ezieco.eziflow.engine.concurrent.eventloop.FlowEventLoopSupervisor;
import ezieco.eziflow.engine.concurrent.eventloop.data.FlowEventLoopWrapper;
import ezieco.eziflow.engine.concurrent.eventloop.data.impl.FlowEventLoopWrapperImpl;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FlowEventLoopSupervisorImpl implements FlowEventLoopSupervisor {

	private static final long MAX_INACTIVE_TIME = TimeUnit.MINUTES.toNanos(30); // 30 minutes

	private final Map<FlowEventKey, FlowEventLoopWrapper> eventLoopMap;
	private final ScheduledExecutorService scheduledExecutorService;

	public FlowEventLoopSupervisorImpl(int corePoolSize) {
		this.eventLoopMap = new ConcurrentHashMap<>();
		this.scheduledExecutorService = Executors.newScheduledThreadPool(corePoolSize);
		startInactiveEventLoopCleaner();
	}

	@Override
	public FlowEventLoop retrieveEventLoop(FlowEventKey key) {
		return eventLoopMap.compute(key, (k, wrapper) -> {
			if (wrapper == null) {
				FlowEventLoop newLoop = new FlowEventLoopImpl(scheduledExecutorService);
				newLoop.start();
				return new FlowEventLoopWrapperImpl(newLoop);
			} else {
				wrapper.updateLastAccessTime();
				return wrapper;
			}
		}).getEventLoop();
	}

	@Override
	public void terminateAllEventLoops() {
		eventLoopMap.values().forEach(wrapper -> wrapper.getEventLoop().stop());
		eventLoopMap.clear();
		shutdownExecutorService();
	}

	private void startInactiveEventLoopCleaner() {
		scheduledExecutorService.scheduleAtFixedRate(() -> {
			long currentTime = System.nanoTime();
			eventLoopMap.entrySet().removeIf(entry -> {
				FlowEventLoopWrapper wrapper = entry.getValue();
				if (currentTime - wrapper.getLastAccessTime() > MAX_INACTIVE_TIME) {
					wrapper.getEventLoop().stop();
					return true;
				}
				return false;
			});
		}, 1, 1, TimeUnit.MINUTES); // Check every minute
	}

	private void shutdownExecutorService() {
		scheduledExecutorService.shutdown();
		try {
			if (!scheduledExecutorService.awaitTermination(60, TimeUnit.SECONDS)) {
				scheduledExecutorService.shutdownNow();
				if (!scheduledExecutorService.awaitTermination(60, TimeUnit.SECONDS)) {
					log.debug("ScheduledExecutorService did not terminate");
				}
			}
		} catch (InterruptedException ie) {
			Thread.currentThread().interrupt();
			scheduledExecutorService.shutdownNow();
		}
	}
}
