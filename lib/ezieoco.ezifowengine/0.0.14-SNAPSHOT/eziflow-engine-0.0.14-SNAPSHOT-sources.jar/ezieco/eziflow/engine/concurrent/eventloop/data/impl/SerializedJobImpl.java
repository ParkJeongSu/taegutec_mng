package ezieco.eziflow.engine.concurrent.eventloop.data.impl;

import ezieco.eziflow.engine.concurrent.eventloop.data.SerializedJob;

public class SerializedJobImpl implements SerializedJob {

	private final Runnable runnable;

	public SerializedJobImpl(Runnable runnable) {
		this.runnable = runnable;
	}

	@Override
	public void execute() {
		this.runnable.run();
	}
}
