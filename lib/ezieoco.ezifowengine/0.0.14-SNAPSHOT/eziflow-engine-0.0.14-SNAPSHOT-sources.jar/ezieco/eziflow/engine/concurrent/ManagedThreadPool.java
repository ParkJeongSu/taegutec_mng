package ezieco.eziflow.engine.concurrent;

import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.data.CorrelationRecord;

public interface ManagedThreadPool extends ThreadEventListener {

	int getReceiveTimeout();

	void setReceiveTimeout(int receiveTimeout);

	void init();

//	void execute(Runnable command);

	Future<?> submit(Action action);

	Future<?> submit(Runnable task);

	boolean awake(Object correlationId, Object... args);

	void setCorrelations(Object correlationId, Action action);

	Action removeCorrelations(Object correlationId);

	CorrelationRecord removeReservedCorrelations(Object correlationId);

	boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException;

	void shutdown();

	List<Runnable> shutdownNow();

	List<Runnable> shutdown(long timeout, TimeUnit unit);

	boolean hasCorrelationId(String correlationId);
}
