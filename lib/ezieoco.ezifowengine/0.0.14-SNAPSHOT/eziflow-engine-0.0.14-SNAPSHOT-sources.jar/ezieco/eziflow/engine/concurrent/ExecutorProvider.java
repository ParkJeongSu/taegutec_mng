package ezieco.eziflow.engine.concurrent;

import java.util.concurrent.ExecutorService;

public interface ExecutorProvider {
	ExecutorService getExecutorService();
}
