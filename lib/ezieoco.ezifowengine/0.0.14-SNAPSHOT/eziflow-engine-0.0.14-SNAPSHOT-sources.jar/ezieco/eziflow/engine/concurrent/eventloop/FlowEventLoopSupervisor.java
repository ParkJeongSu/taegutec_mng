package ezieco.eziflow.engine.concurrent.eventloop;

public interface FlowEventLoopSupervisor {
	FlowEventLoop retrieveEventLoop(FlowEventKey key);

	void terminateAllEventLoops();
}
