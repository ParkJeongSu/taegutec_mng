package ezieco.eziflow.engine.concurrent.eventloop.worker;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import ezieco.eziflow.engine.concurrent.eventloop.data.DelayedTask;
import ezieco.eziflow.engine.concurrent.eventloop.data.SerializedJob;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ScheduleWorker {
	private static final long DEFAULT_INTERVAL_NANO = 100_000_000;
	private final ScheduledExecutorService loopExecutor;
	private final DelayQueue<DelayedTask<SerializedJob>> taskQueue;

	public ScheduleWorker(ScheduledExecutorService loopExecutor, DelayQueue<DelayedTask<SerializedJob>> taskQueue) {
		this.loopExecutor = loopExecutor;
		this.taskQueue = taskQueue;
	}

	public void start() {
		loopExecutor.schedule(this::scheduledRun, DEFAULT_INTERVAL_NANO, TimeUnit.NANOSECONDS);
	}

	private void scheduledRun() {
		long startTime = System.nanoTime();
		processTasks();
		reschedule(startTime);
	}

	private void reschedule(long startTime) {
		long taskDuration = System.nanoTime() - startTime;
		long delay = Math.max(DEFAULT_INTERVAL_NANO - taskDuration, 0);
		loopExecutor.schedule(this::scheduledRun, delay, TimeUnit.NANOSECONDS);
	}

	public void stop() {
		loopExecutor.shutdown();
		try {
			if (!loopExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
				loopExecutor.shutdownNow();
			}
		} catch (InterruptedException e) {
			loopExecutor.shutdownNow();
			Thread.currentThread().interrupt();
		}
	}

	private void processTasks() {
		List<SerializedJob> jobs = new ArrayList<>();
		DelayedTask<SerializedJob> delayedTask;
		while ((delayedTask = taskQueue.poll()) != null) {
			jobs.add(delayedTask.getData());
		}

		for (SerializedJob job : jobs) {
			try {
				job.execute();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
	}
}
