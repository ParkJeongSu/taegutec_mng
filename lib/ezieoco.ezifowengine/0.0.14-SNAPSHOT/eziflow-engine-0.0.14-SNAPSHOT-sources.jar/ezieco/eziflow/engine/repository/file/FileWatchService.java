package ezieco.eziflow.engine.repository.file;

public interface FileWatchService {
	void start();

	void stop();
	
	void restart();
}
