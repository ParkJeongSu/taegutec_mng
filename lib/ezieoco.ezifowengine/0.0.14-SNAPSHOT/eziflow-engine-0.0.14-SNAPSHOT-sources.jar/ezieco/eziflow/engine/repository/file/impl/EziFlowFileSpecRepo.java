package ezieco.eziflow.engine.repository.file.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.xml.namespace.QName;

import org.w3c.dom.Document;

import ezieco.eziflow.engine.config.EziFlowProperties.BPELProperties;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.repository.AbstractEziFlowSpecRepo;
import ezieco.eziflow.engine.repository.file.FileWatchListener;
import ezieco.eziflow.engine.repository.file.FileWatchService;
import ezieco.eziflow.engine.repository.file.WatchFolderOption;
import ezieco.eziflow.engine.utils.BpelFileFinder;
import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.StackTraceFormatter;
import ezieco.eziflow.engine.utils.xml.XMLUtility;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EziFlowFileSpecRepo extends AbstractEziFlowSpecRepo implements FileWatchListener {

	private final Map<String, Long> flowSpecFileInfoMapList = new ConcurrentHashMap<>();

	@Setter
	private String filePattern = "*.bpel";

	@Getter
	private final String[] flowSpecFolders;
	private final BPELProperties bpelProperties;

	private FileWatchService fileWatcher = null;

	private boolean disableFileWatcher = false;

	// resume 후 사용자가 read를 호출해야 한다.
	private boolean holdFileWatchAction = false;

	public EziFlowFileSpecRepo(BPELProperties properties) {
		this.bpelProperties = properties;
		this.flowSpecFolders = this.bpelProperties.getBpelFolders();
	}

	/**
	 * BPELProperties와 fileWatchService 비활성화 옵션을 받는 생성자
	 */
	public EziFlowFileSpecRepo(BPELProperties properties, boolean disableFileWatchService) {
		this.bpelProperties = properties;
		this.flowSpecFolders = properties.getBpelFolders();
		this.disableFileWatcher = disableFileWatchService;
	}

	/**
	 * BPELProperties와 custom FileWatchService를 받는 생성자
	 */
	public EziFlowFileSpecRepo(BPELProperties properties, FileWatchService fileWatchService) {
		this.bpelProperties = properties;
		this.flowSpecFolders = properties.getBpelFolders();
		this.fileWatcher = fileWatchService;
	}

	public void read() {
		addBpelProcesses(getDocumentsFromFolders(this.flowSpecFolders));
	}

	@Override
	public void init() {
		if (this.flowSpecFolders == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NULL_POINTER_ERROR)
					.args("flowSpecFolders").build());
		}

		this.read();

		if (!this.disableFileWatcher) {
			if (this.fileWatcher == null) {
				// Properties에서 선택할 수 있게 변경
				this.fileWatcher = new FileWatcher(this, this.flowSpecFolders, this.bpelProperties.getOption());
			}
			this.fileWatcher.start();
			log.info("Start FileWatchService.");
		} else {
			log.info("FileWatchService Disabled.");
		}
	}

	public void reload() {
		if (this.flowSpecFolders == null) {
			throw new EziFlowException(ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.NULL_POINTER_ERROR)
					.args("flowSpecFolders").build());
		}

		this.read();

		if (this.fileWatcher != null) {
			this.fileWatcher.restart();
		}
	}

	public void pauseFileWatchAction() {
		this.holdFileWatchAction = true;
		log.info("FileWatchService Paused.");
	}

	public void resumeFileWatchAction() {
		this.holdFileWatchAction = false;
		log.info("FileWatchService Resumed.");
	}

	@Override
	public void onFileCreate(final File file) {
		processFileEvent(file);
	}

	@Override
	public void onFileChange(final File file) {
		processFileEvent(file);
	}

	private void processFileEvent(final File file) {
		if (holdFileWatchAction) {
			return;
		}
		try {
			// 심볼릭 링크 해소가 필요 없다면 getAbsolutePath()를 사용하여 비용 절감
			addBpelProcess(getDocumentFromBpelFile(file.getAbsolutePath()));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public void onFileDelete(final File file) {
		if (holdFileWatchAction) {
			return;
		}
		try {
			this.deleteBpelProcess(new QName(EziFlowConst.DEFAULT_TARGETNAMESPACE, file.getName()));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public void onFileOverflow(final File file) {
		// TODO Auto-generated method stub
	}

	private Document[] getDocumentsFromFolders(String[] bpelFolders) {
		BpelFileFinder loader = new BpelFileFinder();
		loader.setFilePattern(this.filePattern);

		// 동시 수정이 필요하지 않으므로 ArrayList 사용
		List<String> bpelFiles = new ArrayList<>();

		// 폴더 옵션은 반복문 밖에서 한 번만 가져옴
		WatchFolderOption folderOption = this.bpelProperties.getOption();

		for (String bpelFolder : bpelFolders) {
			List<String> list;
			if (folderOption == WatchFolderOption.INCLUDE_SUB_FOLDER) {
				list = loader.getBpelFilesIncludingSubfolders(bpelFolder);
			} else {
				list = loader.getBpelFiles(bpelFolder);
			}
			bpelFiles.addAll(list);
			list.forEach(this::addBpelFileInfo);
		}

		// 병렬 스트림 대신 순차 스트림으로 XML 파싱 처리
		List<Document> documents = bpelFiles.stream().map(this::getDocumentFromBpelFile).filter(Objects::nonNull)
				.collect(Collectors.toList());

		return documents.toArray(new Document[0]);
	}

	private void addBpelFileInfo(String bpelFile) {
		File file = new File(bpelFile);
		String path = file.getAbsolutePath();
		flowSpecFileInfoMapList.compute(path, (key, value) -> {
			if (value == null || file.lastModified() > value) {
				return file.lastModified();
			}
			return value;
		});
	}

	private Document getDocumentFromBpelFile(String fileName) {
		try {
			return XMLUtility.getInstance().loadFile(fileName, true);
		} catch (Exception e) {
			log.error(StackTraceFormatter.getCompleteStackTrace(e));
			return null;
		}
	}
}
