package ezieco.eziflow.engine.repository.file;

// 감지할 폴더 범위 옵션. 검토 후 제거 혹은 변경 필요.
public enum WatchFolderOption {
	EXCLUDE_SUB_FOLDER, 
	INCLUDE_SUB_FOLDER
}
