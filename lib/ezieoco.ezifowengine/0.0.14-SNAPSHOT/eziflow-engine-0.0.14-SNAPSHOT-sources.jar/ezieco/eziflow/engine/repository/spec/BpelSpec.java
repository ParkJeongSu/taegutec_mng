package ezieco.eziflow.engine.repository.spec;

import javax.xml.namespace.QName;

import org.w3c.dom.Document;

public interface BpelSpec {
	QName getQname();

	Document getDocument();

	BpelSpec deepCopy();
}
