package ezieco.eziflow.engine.repository.file;

import java.io.File;

public interface FileWatchListener {
	public void onFileCreate(final File file);
	public void onFileChange(final File file);
	public void onFileDelete(final File file);
	public void onFileOverflow(final File file);
}
