package ezieco.eziflow.engine.repository.file.impl;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import ezieco.eziflow.engine.repository.file.FileWatchListener;
import ezieco.eziflow.engine.repository.file.FileWatchService;
import ezieco.eziflow.engine.repository.file.WatchFolderOption;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FileWatcher implements FileWatchService {
	
	// TODO. file pattern을 가져와서 pattern에 맞는 파일의 변화만 listener로 알려줘야 할까?
//	private String filePattern;

	private WatchFolderOption watchOption = WatchFolderOption.EXCLUDE_SUB_FOLDER;

	private Thread watchThread;

	private FileWatchListener fileWatchListener = null;
	private WatchService watchService = null;

	private Path[] watchFilePaths;

	public FileWatcher(FileWatchListener fileWatchListener, String[] paths) {
		this.fileWatchListener = fileWatchListener;
		this.watchFilePaths = Stream.of(paths).map(Paths::get).toArray(Path[]::new);
	}

	public FileWatcher(FileWatchListener fileWatchListener, String[] paths, WatchFolderOption watchOption) {
		this.fileWatchListener = fileWatchListener;
		this.watchFilePaths = Stream.of(paths).map(Paths::get).toArray(Path[]::new);

		this.watchOption = watchOption;
	}

	public void start() {
		try {
			this.watchThread = new Thread(new FileWatchStarter());
			this.watchThread.setName("FileWatchStarter");
			this.watchThread.setDaemon(true);
			this.watchThread.start();
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
	}

	public void stop() {
		try {
			this.watchService = null;
			this.watchThread.interrupt();
			this.watchThread = null;
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
	}

	public void restart() {
		this.stop();
		this.start();
	}

	class FileWatchStarter implements Runnable {

		private Map<String, WatchKey> watchKeyMap = new ConcurrentHashMap<>();
		private List<String> directoryList = new ArrayList<>();

		final SimpleFileVisitor<Path> fileVisitor = new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult preVisitDirectory(Path path, BasicFileAttributes attrs) throws IOException {
				String absolutePath = path.toAbsolutePath().toString();
				if (watchKeyMap.containsKey(absolutePath)) {
					// 이미 등록되어 있는 경로는 넘어간다.
					return FileVisitResult.CONTINUE;
				}

				WatchKey key = path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE,
						StandardWatchEventKinds.ENTRY_DELETE, StandardWatchEventKinds.ENTRY_MODIFY,
						StandardWatchEventKinds.OVERFLOW);

				watchKeyMap.put(absolutePath, key);
				directoryList.add(absolutePath);

				return FileVisitResult.CONTINUE;
			}
		};

		private void registerPath(Path[] paths) throws IOException {
			if (watchOption.equals(WatchFolderOption.INCLUDE_SUB_FOLDER)) {
				// 하위 폴더까지 감지할 수 있도록 fileVisitor호출.
				for (Path path : paths) {
					Files.walkFileTree(path, this.fileVisitor);
				}
			} else {
				// 해당 폴더만 감지. (하위 폴더의 변경 사항까지 감지 하지 않음.)
				for (Path path : paths) {
					String absolutePath = path.toAbsolutePath().toString();
					if (this.watchKeyMap.containsKey(absolutePath)) {
						return;
					}

					WatchKey key = path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE,
							StandardWatchEventKinds.ENTRY_DELETE, StandardWatchEventKinds.ENTRY_MODIFY,
							StandardWatchEventKinds.OVERFLOW);

					this.watchKeyMap.put(absolutePath, key);
					this.directoryList.add(absolutePath);
				}
			}
		}

		// watchService에서 key를 해제하고 map에서 삭제.
		// 폴더가 삭제된 경우.(key만 가용할 수 있음.)
		// 폴더 이름이 변경된 경우.(이전 이름의 경로로 delete event발생 후 변경된 이름의 경로로 create event 발생.)
		private void removePath(Path path, WatchKey key) {
			try {
				String removePath = "";
				// path가 없는 경우. key로 찾아본다.
				if (path == null) {
					for (String tempPath : this.watchKeyMap.keySet()) {
						WatchKey tempKey = this.watchKeyMap.get(tempPath);
						if (tempKey.equals(key)) {
							removePath = tempPath;
							break;
						}
					}
				} else {
					String absolutePath = path.toAbsolutePath().toString();
					if (this.watchKeyMap.containsKey(absolutePath)) {
						removePath = absolutePath;
					}
				}

				if (StringUtils.isNotEmpty(removePath)) {
					this.watchKeyMap.get(removePath).cancel(); // watchService에서 key 해제.
					this.watchKeyMap.remove(removePath); // map에서 삭제.
					this.directoryList.remove(removePath);
				}
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
		}

		@Override
		public void run() {
			try {
				if (watchService != null) {
					return;
				}

				watchService = FileSystems.getDefault().newWatchService();
				this.registerPath(watchFilePaths);

				/*
				 * event 발생 종류. ex) 파일 생성 시 1. 파일에 대해 create event. 2. 파일에 대해 modify event. 3.
				 * 파일 경로에 대해 modify event.
				 * 
				 * 파일 수정 시 1. 파일의 내용에 대해 modify event. 2. 파일의 수정 시간에 대해 modify event.
				 * 
				 * 파일 삭제 시 1. 파일에 대해 delete event. 2. 파일 경로에 대해 modify event.
				 * 
				 * 
				 * lastModified시간을 비교해서 2번째 발생한 event에 대해서는 skip하도록 구현함. - 2개 event의
				 * lastModified의 값은 동일하기 때문. - 파일 생성 시 발생하는 create와 modify event의
				 * lastModified시간이 다른 경우 있음.
				 * 
				 * sub폴더가 생성된 경우 sub폴더 내 파일의 변화는 폴더의 변화로 감지함. - sub폴더의 변경은 감지할 수 있지만 sub폴더 내 변경된
				 * 파일을 특정할 수 없음. - create event의 path가 directory인 경우 directory path에 watch
				 * service를 등록하면 sub폴더 내 파일 변화 감지 가능.
				 */
				String previousKind = "";
				Path previousFilePath = null;
				long previousLastModifiedTime = -1;

				WatchKey key;
				while (!Thread.currentThread().isInterrupted()) {
					if (watchService == null) {
						break;
					}

					try {
						key = watchService.take();
					} catch (InterruptedException ex) {
						break;
					}

					try {
						if (!this.watchKeyMap.containsValue(key)) {
							continue;
						}

						for (WatchEvent<?> event : key.pollEvents()) {
							Kind<?> kind = event.kind();
							Path dir = (Path) key.watchable();
							Path filePath = dir.resolve((Path) event.context());

							// 중복 event방지
							/*
							 * TODO. 유효한 event는 최대 2개 정도인듯.
							 * 
							 * 삭제 - Delete 생성 - Create -> Modify(불필요) 복사 - Create -> Modify(불필요) 수정 - Modify
							 * -> Modify(불필요) 이름변경 - Delete -> Create -> Modify(불필요)
							 */
							long lastModifiedTime = filePath.toFile().lastModified();
							// 이전 정보와 비교.
							if (kind.name().equalsIgnoreCase(previousKind) && filePath.compareTo(previousFilePath) == 0
									&& lastModifiedTime == previousLastModifiedTime) {
								continue; // 이전과 동일하면 넘어간다.
							} else {
								// 새로운 정보 저장.
								previousKind = kind.name();
								previousFilePath = filePath;
								previousLastModifiedTime = lastModifiedTime;
							}
							//

							if (kind.equals(StandardWatchEventKinds.ENTRY_CREATE)) {
								if (filePath.toFile().isDirectory()) {
									// option에 따라 동작.
									if (watchOption.equals(WatchFolderOption.INCLUDE_SUB_FOLDER)) {
										// monitoring할 수 있도록 watch service에 path 등록.
										this.registerPath(new Path[] { filePath });
									} else {
										log.info(
												"If you want to monitor subdirectories as well, you need to change the WatchFolderOption to IncludeSubFolder.");

										// directory list에만 추가.
										this.directoryList.add(filePath.toAbsolutePath().toString());
									}

									log.info(String.format("Directory Created. Path=%s",
											filePath.toAbsolutePath().toString()));
								} else {
									fileWatchListener.onFileCreate(filePath.toFile());
								}
							} else if (kind.equals(StandardWatchEventKinds.ENTRY_DELETE)) {
								// 폴더 이름이 변경된 경우 변경 전 path는 directory로 인식하지 못함.
								// watchKeyMap 또는 directoryList에 절대 경로로 등록되어 있는 path인지 확인 후 삭제 진행.
								if (this.directoryList.contains(filePath.toAbsolutePath().toString())) {
									// directoryList에는 watch하지 않는 폴더도 모두 들어있음.
									this.directoryList.remove(filePath.toAbsolutePath().toString());

									// watch하는 경로라면 삭제 진행.
									if (this.watchKeyMap.containsKey(filePath.toAbsolutePath().toString())) {
										this.removePath(filePath, key);
									}

									log.info(String.format("Directory Deleted. Path=%s",
											filePath.toAbsolutePath().toString()));
								} else {
									fileWatchListener.onFileDelete(filePath.toFile());
								}
							} else if (kind.equals(StandardWatchEventKinds.ENTRY_MODIFY)) {
								if (filePath.toFile().isFile()) {
									// 파일이 변경된 경우에만 수행.
									fileWatchListener.onFileChange(filePath.toFile());
								}
							} else if (kind.equals(StandardWatchEventKinds.OVERFLOW)) {
								fileWatchListener.onFileOverflow(filePath.toFile());
							} else {
								log.error("Invalid kind of event. Kind=" + kind.name());
							}
						}

					} catch (Exception ex) {
						log.error(ex.getMessage(), ex);
					} finally {
						if (!key.reset()) {
							try {
								this.removePath(null, key);

								if (this.watchKeyMap.isEmpty()) {
									log.info("WatchKeyList is Empty. Close the WatchService.");
									watchService.close();
								}
							} catch (IOException e) {
								log.error(e.getMessage(), e);
							}
						}
					}
				}
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
		}
	}
}
