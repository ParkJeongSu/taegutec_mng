package ezieco.eziflow.engine.repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.namespace.QName;

import org.w3c.dom.Document;

import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.repository.spec.BpelSpec;
import ezieco.eziflow.engine.repository.spec.BpelSpecImpl;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractEziFlowSpecRepo implements EziFlowSpecRepo {
	protected final Map<QName, BpelSpec> flowSpecMap = new ConcurrentHashMap<>();

	@Override
	public List<BpelSpec> getFlowSpecList() {
		// 스트림 대신 ArrayList 생성자로 직접 감싸는 방식으로 개선
		return Collections.unmodifiableList(new ArrayList<>(flowSpecMap.values()));
	}

	@Override
	public BpelSpec newFlowSpec(QName qname) {
		BpelSpec eziFlowSpec = this.flowSpecMap.get(qname);
		if (eziFlowSpec == null) {
			// TODO: 캐시 적용 등 추가 검토 가능
			throw new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.QNAME_FIND_ERROR).args(qname).build());
		}
		// deepCopy()의 비용이 크다면, 불변 객체로 변경하거나 복사 전략을 재검토할 수 있음
		return eziFlowSpec.deepCopy();
	}

	public void addBpelProcesses(Document[] documents) {
		// 문서 배열 처리 - 배열의 크기가 크지 않다면 for-each 문으로도 충분합니다.
		for (Document doc : documents) {
			addBpelProcess(doc);
		}
	}

	public void addBpelProcess(Document document) {
		addBpelProcess(new BpelSpecImpl(document));
	}

	public void deleteBpelProcess(QName qName) {
		BpelSpec instance = this.flowSpecMap.remove(qName);
		if (instance != null) {
			log.info("Deleted BPEL process: {}", instance);
		}
	}

	/**
	 * Adds or updates a BPEL process in the flowSpecMap.
	 *
	 * @param flowSpec The BPEL process to be added or updated.
	 */
	public void addBpelProcess(BpelSpecImpl flowSpec) {
		BpelSpec instance = this.flowSpecMap.put(flowSpec.getQname(), flowSpec);
		if (instance == null) {
			log.info("Added BPEL process: {}", flowSpec);
		} else {
			log.info("Updated BPEL process: {}", flowSpec);
		}
	}
}
