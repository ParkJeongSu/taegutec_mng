package ezieco.eziflow.engine.repository.spec;

import java.util.concurrent.atomic.AtomicLong;

import javax.xml.namespace.QName;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import ezieco.eziflow.engine.utils.EziFlowConst;
import ezieco.eziflow.engine.utils.xml.XMLUtility;
import ezieco.eziflow.engine.utils.xml.XmlNodeUtils;
import lombok.Getter;

/*
 * Bpel 파일을 메모리에 올려 사용하수 있게 해준다.
 * 
 */
public class BpelSpecImpl implements BpelSpec {

	private static AtomicLong uniqueId = new AtomicLong(1);

	private String id;

	@Getter
	private final QName qname;

	@Getter
	private final Document document;

	public BpelSpecImpl(Document document) {
		this(String.valueOf(uniqueId.getAndIncrement()), document);
	}

	public BpelSpecImpl(String id, Document document) {
		this.id = id;
		this.document = document;
		this.qname = this.init();
	}

	private QName init() {
		Node node = this.document.getDocumentElement();
		return new QName(XmlNodeUtils.getAttribute(node, EziFlowConst.TARGET_NAMESPACE),
				XmlNodeUtils.getAttribute(node, EziFlowConst.NAME));
	}

	@Override
	public BpelSpec deepCopy() {
		Document cloneDocument = XMLUtility.getInstance().cloneDocument(this.document);
		return new BpelSpecImpl(this.id, cloneDocument);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{ \"qname\": \"").append(this.qname.toString()).append("\", \"id\": \"").append(this.id)
				.append("\" }");
		return sb.toString();
	}
}
