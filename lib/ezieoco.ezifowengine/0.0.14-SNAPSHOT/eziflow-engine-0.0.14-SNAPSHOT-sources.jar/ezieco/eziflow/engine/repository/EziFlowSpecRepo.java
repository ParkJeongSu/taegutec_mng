package ezieco.eziflow.engine.repository;

import java.util.List;

import javax.xml.namespace.QName;

import ezieco.eziflow.engine.repository.spec.BpelSpec;

public interface EziFlowSpecRepo {
	List<BpelSpec> getFlowSpecList();

	void read();

	void init();

	void reload();

	void pauseFileWatchAction();

	void resumeFileWatchAction();

	BpelSpec newFlowSpec(QName qname);
}
