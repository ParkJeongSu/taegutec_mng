package ezieco.eziflow.engine.core.impl;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import ezieco.eziflow.engine.core.SingletonRegistry;

public class SingletonManager implements SingletonRegistry {

	private final Map<Class<?>, Object> singletonInstances = new ConcurrentHashMap<>();

	private SingletonManager() {
	}

	private static class SingletonHolder {
		private static final SingletonManager INSTANCE = new SingletonManager();
	}

	public static SingletonManager getInstance() {
		return SingletonHolder.INSTANCE;
	}

	@Override
	public void registerSingleton(Class<?> singletonClass, Object singletonInstance) {
		Object existingInstance = singletonInstances.putIfAbsent(singletonClass, singletonInstance);
		if (existingInstance != null) {
			throw new IllegalStateException("Singleton instance already exists: " + singletonClass.getName());
		}
	}

	@Override
	public boolean hasSingleton(Class<?> singletonClass) {
		return singletonInstances.containsKey(singletonClass);
	}

	@Override
	public String[] getAllSingletonClassNames() {
		return singletonInstances.keySet().stream().map(Class::getName).toArray(String[]::new);
	}

	@Override
	public int getTotalSingletons() {
		return singletonInstances.size();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> Optional<T> getSingletonInstance(Class<T> singletonClass) {
		return Optional.ofNullable((T) singletonInstances.get(singletonClass));
	}
}
