package ezieco.eziflow.engine.core;

public interface EziFlowAppContext {
	Object getBean(String beanId);

	<T> T getBean(String name, Class<T> requiredType);
}
