package ezieco.eziflow.engine.core;

import javax.xml.namespace.QName;

import ezieco.eziflow.engine.action.impl.ExecuteAction;
import ezieco.eziflow.engine.event.external.EventPublisher;

public interface ProcessCreationManager {
	ExecuteAction createProcess(QName qname, EventPublisher eventPublisher);
}
