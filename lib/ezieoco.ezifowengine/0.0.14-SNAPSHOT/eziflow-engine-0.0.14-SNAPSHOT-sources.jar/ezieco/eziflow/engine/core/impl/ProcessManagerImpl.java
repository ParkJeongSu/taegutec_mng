package ezieco.eziflow.engine.core.impl;

import javax.xml.namespace.QName;

import ezieco.eziflow.engine.action.impl.ExecuteAction;
import ezieco.eziflow.engine.core.EziFlowRuntimeContext;
import ezieco.eziflow.engine.core.ProcessCreationManager;
import ezieco.eziflow.engine.event.external.EventPublisher;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.EziFlowException;
import ezieco.eziflow.engine.repository.EziFlowSpecRepo;
import ezieco.eziflow.engine.repository.spec.BpelSpec;

// Class 이름 변경 필요
// QName을 이용해서 FlowSpecRepo 에서 spec을 찾아
// ExecuteAction 생성하고 초기화 시켜주는 class
public class ProcessManagerImpl implements ProcessCreationManager {

	private final EziFlowSpecRepo specRepo;

	public ProcessManagerImpl(EziFlowSpecRepo specRepo) {
		this.specRepo = specRepo;
	}

	public ExecuteAction createProcess(QName qname, EventPublisher eventPublisher) {
		BpelSpec bpelSpec = this.specRepo.newFlowSpec(qname);
		if (bpelSpec == null) {
			throw new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.QNAME_FIND_ERROR).args(qname).build());
		}

		ExecuteAction action = new ExecuteAction(bpelSpec.getQname(), new EziFlowRuntimeContext(), eventPublisher);
		if (action.init(bpelSpec.getDocument().getDocumentElement()) == null) {
			throw new EziFlowException(
					ErrorMessageInfo.builder().errorCodeProvider(ErrorCode.ACTION_INIT_ERROR).args(qname).build());
		}

		return action;
	}
}
