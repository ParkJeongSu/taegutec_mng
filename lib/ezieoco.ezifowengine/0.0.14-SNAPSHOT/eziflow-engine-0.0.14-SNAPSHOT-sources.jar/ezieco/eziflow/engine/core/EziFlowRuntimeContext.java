package ezieco.eziflow.engine.core;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.PostAction;
import ezieco.eziflow.engine.action.PreAction;
import ezieco.eziflow.engine.action.impl.ExecuteAction;
import ezieco.eziflow.engine.action.impl.Flow;
import ezieco.eziflow.engine.concurrent.ManagedThreadPool;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.data.PartnerData;
import ezieco.eziflow.engine.data.VariableData;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EziFlowRuntimeContext {

	private static final ThreadLocal<EziFlowRuntimeContext> context = new ThreadLocal<>();

	private final Map<Thread, Boolean> terminate = new ConcurrentHashMap<>();
	private final Map<Thread, Action> runningAction = new ConcurrentHashMap<>();

	@Getter
	@Setter
	private boolean received;

	@Getter
	@Setter
	private ExecuteAction executeAction;

	@Getter
	private Object[] requests;

	public void setRequests(Object... args) {
		this.requests = args;
	}

	@Getter
	@Setter
	private Object response;

	@Getter
	private Object defaultCorrelationId;

	@Getter
	@Setter
	private PartnerData partnerData;

	@Setter
	private PreAction[] preActions;

	public PreAction[] getPreActions() {
		return this.preActions == null ? new PreAction[0] : this.preActions;
	}

	@Setter
	private PostAction[] postActions;

	public PostAction[] getPostActions() {
		return this.postActions == null ? new PostAction[0] : this.postActions;
	}

	@Getter
	private VariableData variableData = new VariableData(this);

	private final ManagedThreadPool flowThreadPoolManager;

	public EziFlowRuntimeContext() {
		this.flowThreadPoolManager = SingletonManager.getInstance().getSingletonInstance(ManagedThreadPool.class).get();
	}

	public void setTerminate(boolean terminate) {
		try {
			this.terminate.put(Thread.currentThread(), terminate);
		} catch (Exception e) {
			log.error("Failed to set terminate flag for thread: {}", Thread.currentThread(), e);
		}
	}

	public void setTerminate(Thread thread, boolean terminate) {
		this.terminate.put(thread, terminate);
	}

	public void setTerminateForMainThread() {
		setTerminate(false);
	}

	public void setDefaultCorrelationId(Object defaultCorrelationId) {
		if (this.defaultCorrelationId != null) {
			this.flowThreadPoolManager.removeReservedCorrelations(this.defaultCorrelationId);
		}
		this.defaultCorrelationId = defaultCorrelationId;
	}

	public boolean isTerminate(Action action) {
		return terminate.computeIfAbsent(Thread.currentThread(), thread -> checkTerminate(action));
	}

	private boolean checkTerminate(Action action) {
		Action parent = action.getParent();
		if (parent == null) {
			return false;
		} else if (parent instanceof Flow) {
			return ((Flow) parent).isTerminate();
		} else {
			return parent.isTerminate(parent);
		}
	}

	public Action getCurrentThreadAction() {
		return runningAction.get(Thread.currentThread());
	}

	public Optional<Action> getAnyRunningAction() {
		return runningAction.values().stream().findFirst();
	}

	public void setRunningAction(Action action) {
		this.runningAction.put(Thread.currentThread(), action);
	}

	public void setCurrentRuntimeContext() {
		EziFlowRuntimeContext.context.set(this);
	}

	public void removetRuntimeContext() {
		EziFlowRuntimeContext.context.remove();
	}

	public static EziFlowRuntimeContext currenttRuntimeContext() {
		return EziFlowRuntimeContext.context.get();
	}
}
