package ezieco.eziflow.engine.core;

import java.util.Optional;

public interface SingletonRegistry {
	void registerSingleton(Class<?> singletonClass, Object singletonInstance);

	<T> Optional<T> getSingletonInstance(Class<T> singletonClass);

	boolean hasSingleton(Class<?> singletonClass);

	String[] getAllSingletonClassNames();

	int getTotalSingletons();
}
