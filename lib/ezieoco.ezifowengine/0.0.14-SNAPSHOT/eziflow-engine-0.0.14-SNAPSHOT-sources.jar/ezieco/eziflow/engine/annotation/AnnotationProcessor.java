package ezieco.eziflow.engine.annotation;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnnotationProcessor {

	/**
	 * 지정한 패키지에서 어노테이션이 달린 클래스들을 찾아, type에 맞게 인스턴스를 생성한 후 리스트로 반환합니다.
	 */
	public <T> List<T> getAnnotatedClassInstances(String packageName, Class<? extends Annotation> annotation,
			Class<T> type) throws Exception {
		List<T> instances = new ArrayList<>();
		List<Class<?>> annotatedClasses = findAnnotatedClasses(packageName, annotation);
		for (Class<?> clazz : annotatedClasses) {
			if (type.isAssignableFrom(clazz)) {
				try {
					T instance = type.cast(clazz.getDeclaredConstructor().newInstance());
					instances.add(instance);
				} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
						| java.lang.reflect.InvocationTargetException | NoSuchMethodException | SecurityException e) {
					log.error("Failed to create instance of class: {}", clazz.getName(), e);
					throw new Exception("Failed to create instance of class: " + clazz.getName(), e);
				}
			}
		}
		return instances;
	}

	public static List<Class<?>> findAnnotatedClasses(String packageName, Class<? extends Annotation> annotation)
			throws Exception {
		List<Class<?>> annotatedClasses = new ArrayList<>();

		String path = packageName.replace('.', '/');
		log.info("Scanning package: {} (converted path: {})", packageName, path);

		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		Enumeration<URL> resources = classLoader.getResources(path);

		while (resources.hasMoreElements()) {
			URL resource = resources.nextElement();
			if (resource == null) {
				log.error("Package not found: {}", packageName);
				throw new IllegalArgumentException("Package not found: " + packageName);
			}
			log.info("Resource found: {}", resource);
			String protocol = resource.getProtocol();
			log.info("Resource protocol: {}", protocol);

			try {
				if ("file".equals(protocol)) {
					File directory = new File(resource.getFile());
					if (directory.isDirectory()) {
						log.info("Scanning directory: {}", directory.getAbsolutePath());
						findClassesInDirectory(directory, packageName, annotation, annotatedClasses);
					} else {
						log.warn("Expected directory but found file: {}", directory.getAbsolutePath());
					}
				} else if ("jar".equals(protocol)) {
					String rawPath = resource.getPath();
					log.info("Raw jarPath: {}", rawPath);
					// fat jar 내부의 nested JAR인 경우 처리 (예: BOOT-INF/lib/...)
					if (rawPath.contains("BOOT-INF/lib/")) {
						String fatJarPath = extractFatJarPath(rawPath);
						log.info("Fat jar path: {}", fatJarPath);
						scanFatJar(fatJarPath, packageName, annotation, annotatedClasses);
					} else {
						scanJarFile(rawPath, packageName, annotation, annotatedClasses);
					}
				} else {
					log.warn("Unsupported resource protocol: {}", protocol);
				}
			} catch (IOException e) {
				log.error("Failed to process resource: {}", resource, e);
				throw e;
			}
		}

		log.info("Found {} annotated classes in package: {}", annotatedClasses.size(), packageName);
		return annotatedClasses;
	}

	private static String extractFatJarPath(String rawPath) throws IOException {
		int exclIndex = rawPath.indexOf("!");
		String outer = rawPath.substring(0, exclIndex);
		if (outer.startsWith("nested:")) {
			outer = outer.substring(7);
		} else if (outer.startsWith("jar:")) {
			outer = outer.substring(4);
		}
		// Spring Boot 2.x의 경우 "file:" 접두어가 남아 있을 수 있으므로 제거
		if (outer.startsWith("file:")) {
			outer = outer.substring(5);
		}
		outer = URLDecoder.decode(outer, "UTF-8");
		// Windows 환경: "/D:/..." 형태이면 선행 "/" 제거
		if (System.getProperty("os.name").toLowerCase().contains("win") && outer.matches("^/[A-Za-z]:/.*")) {
			outer = outer.substring(1);
		}
		return outer;
	}

	private static void scanFatJar(String fatJarPath, String packageName, Class<? extends Annotation> annotation,
			List<Class<?>> annotatedClasses) throws IOException {
		log.info("Scanning fat jar: {}", fatJarPath);
		try (JarFile fatJar = new JarFile(new File(fatJarPath))) {
			Enumeration<JarEntry> entries = fatJar.entries();
			while (entries.hasMoreElements()) {
				JarEntry entry = entries.nextElement();
				if (entry.getName().startsWith("BOOT-INF/lib/") && entry.getName().endsWith(".jar")) {
//					log.info("Found nested jar: {}", entry.getName());
					File tempJar = File.createTempFile("nested", ".jar");
					tempJar.deleteOnExit();
					try (java.io.InputStream is = fatJar.getInputStream(entry);
							java.io.OutputStream os = new java.io.FileOutputStream(tempJar)) {
						byte[] buffer = new byte[4096];
						int read;
						while ((read = is.read(buffer)) != -1) {
							os.write(buffer, 0, read);
						}
					}
					try (JarFile nestedJar = new JarFile(tempJar)) {
						findClassesInJar(nestedJar, packageName, annotation, annotatedClasses);
					}
				}
			}
		}
	}

	private static void scanJarFile(String jarPath, String packageName, Class<? extends Annotation> annotation,
			List<Class<?>> annotatedClasses) throws IOException {
		if (jarPath.startsWith("jar:")) {
			jarPath = jarPath.substring(4);
		}
		if (jarPath.startsWith("file:")) {
			jarPath = jarPath.substring(5);
		}
		int excl = jarPath.indexOf("!");
		if (excl != -1) {
			jarPath = jarPath.substring(0, excl);
		}
		jarPath = URLDecoder.decode(jarPath, "UTF-8");
		if (System.getProperty("os.name").toLowerCase().contains("win") && jarPath.matches("^/[A-Za-z]:/.*")) {
			jarPath = jarPath.substring(1);
		}
		log.info("Scanning JAR file: {}", jarPath);
		try (JarFile jarFile = new JarFile(new File(jarPath))) {
			findClassesInJar(jarFile, packageName, annotation, annotatedClasses);
		}
	}

	private static void findClassesInJar(JarFile jarFile, String packageName, Class<? extends Annotation> annotation,
			List<Class<?>> annotatedClasses) {
		Enumeration<JarEntry> entries = jarFile.entries();
		String packagePath = packageName.replace('.', '/');
		while (entries.hasMoreElements()) {
			JarEntry entry = entries.nextElement();
			String entryName = entry.getName();
			if (entryName.startsWith(packagePath) && entryName.endsWith(".class")) {
				String className = entryName.replace('/', '.').substring(0, entryName.length() - 6);
				try {
					Class<?> clazz = Class.forName(className);
					if (clazz.isAnnotationPresent(annotation)) {
						annotatedClasses.add(clazz);
					}
				} catch (ClassNotFoundException e) {
					log.error("Failed to load class: " + className, e);
				} catch (NoClassDefFoundError e) {
					log.warn("Failed to load class (dependency issue): " + className, e);
				}
			}
		}
	}

	private static void findClassesInDirectory(File directory, String packageName,
			Class<? extends Annotation> annotation, List<Class<?>> annotatedClasses) throws Exception {
		File[] files = directory.listFiles();
		if (files == null) {
			log.warn("Could not list files in directory: {}", directory.getAbsolutePath());
			return;
		}
		for (File file : files) {
			if (file.isDirectory()) {
				findClassesInDirectory(file, packageName + "." + file.getName(), annotation, annotatedClasses);
			} else if (file.getName().endsWith(".class")) {
				String className = getClassNameFromFile(packageName, file.getName());
				try {
					Class<?> clazz = Class.forName(className);
					if (clazz.isAnnotationPresent(annotation)) {
						annotatedClasses.add(clazz);
					}
				} catch (ClassNotFoundException e) {
					log.error("Failed to load class: " + className, e);
				} catch (NoClassDefFoundError e) {
					log.warn("Failed to load class (dependency issue): " + className, e);
				}
			}
		}
	}

	private static String getClassNameFromFile(String packageName, String fileName) {
		return packageName + '.' + fileName.substring(0, fileName.length() - 6);
	}
}
