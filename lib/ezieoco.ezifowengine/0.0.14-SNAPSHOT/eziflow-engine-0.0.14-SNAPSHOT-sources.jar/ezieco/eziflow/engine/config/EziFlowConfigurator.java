package ezieco.eziflow.engine.config;

import ezieco.eziflow.engine.core.EziFlowAppContext;
import ezieco.eziflow.engine.expression.EziFlowExpression;
import ezieco.eziflow.engine.expression.EziFlowExpressionImpl;
import ezieco.eziflow.engine.management.EziFlowMeterRegistryProvider;
import ezieco.eziflow.engine.management.impl.SimpleMeterRegistryProvider;
import ezieco.eziflow.engine.repository.EziFlowSpecRepo;
import ezieco.eziflow.engine.repository.file.impl.EziFlowFileSpecRepo;
import lombok.Getter;

public class EziFlowConfigurator {

	@Getter
	private final EziFlowProperties eziFlowProperties;

	@Getter
	private final EziFlowAppContext eziFlowAppContext;

	@Getter
	private final EziFlowSpecRepo eziFlowSpecRepo;

	@Getter
	private final EziFlowExpression eziFlowExpression;

	@Getter
	private final EziFlowMeterRegistryProvider meterRegistryProvider;

	private EziFlowConfigurator(Builder builder) {
		this.eziFlowProperties = builder.eziFlowProperties;
		this.eziFlowAppContext = builder.eziFlowAppContext;
		this.eziFlowExpression = builder.eziFlowExpression != null ? builder.eziFlowExpression
				: new EziFlowExpressionImpl();
		this.eziFlowSpecRepo = builder.eziFlowSpecRepo != null ? builder.eziFlowSpecRepo
				: new EziFlowFileSpecRepo(eziFlowProperties.getBpelProperties());
		this.eziFlowSpecRepo.init();
		this.meterRegistryProvider = builder.meterRegistryProvider != null ? builder.meterRegistryProvider
				: new SimpleMeterRegistryProvider();
	}
	
	public static Builder builder(EziFlowProperties eziFlowProperties, EziFlowAppContext eziFlowAppContext) {
		return new Builder(eziFlowProperties, eziFlowAppContext);
	}

	// EziFlowProperties, EziFlowAppContext 생성자로 받기 위하여 아래와 같이 구현
	public static class Builder {
		private final EziFlowProperties eziFlowProperties;
		private final EziFlowAppContext eziFlowAppContext;
		private EziFlowSpecRepo eziFlowSpecRepo;
		private EziFlowExpression eziFlowExpression;
		private EziFlowMeterRegistryProvider meterRegistryProvider;

		Builder(EziFlowProperties eziFlowProperties, EziFlowAppContext eziFlowAppContext) {
			this.eziFlowProperties = eziFlowProperties;
			this.eziFlowAppContext = eziFlowAppContext;
		}

		public Builder withEziFlowSpecRepo(EziFlowSpecRepo eziFlowSpecRepo) {
			this.eziFlowSpecRepo = eziFlowSpecRepo;
			return this;
		}

		public Builder withEziFlowExpression(EziFlowExpression eziFlowExpression) {
			this.eziFlowExpression = eziFlowExpression;
			return this;
		}

		public Builder withMeterRegistryProvider(EziFlowMeterRegistryProvider meterRegistryProvider) {
			this.meterRegistryProvider = meterRegistryProvider;
			return this;
		}

		public EziFlowConfigurator build() {
			return new EziFlowConfigurator(this);
		}
	}
}
