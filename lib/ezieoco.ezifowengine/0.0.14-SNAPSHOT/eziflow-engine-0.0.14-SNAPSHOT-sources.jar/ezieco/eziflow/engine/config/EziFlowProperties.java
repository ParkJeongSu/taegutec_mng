package ezieco.eziflow.engine.config;

import ezieco.eziflow.engine.concurrent.ThreadPoolRejectedPolicy;
import ezieco.eziflow.engine.repository.file.WatchFolderOption;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Data
public class EziFlowProperties {

	private ThreadProperties threadProperties = new ThreadProperties();
	private BPELProperties bpelProperties = new BPELProperties();

	@Data
	public static class ThreadProperties {
		private static final int DEFAULT_CORE_POOL_SIZE = calculateDefaultPoolSize();
		private static final int DEFAULT_MAX_POOL_SIZE = DEFAULT_CORE_POOL_SIZE * 2;
		private static final int DEFAULT_QUEUE_SIZE = DEFAULT_CORE_POOL_SIZE * 2;

		@Setter(AccessLevel.NONE)
		private int corePoolSize = DEFAULT_CORE_POOL_SIZE;
		
		@Setter(AccessLevel.NONE)
		private int maxPoolSize = DEFAULT_MAX_POOL_SIZE;
		
		@Setter(AccessLevel.NONE)
		private int queueSize = DEFAULT_QUEUE_SIZE;
		private long keepAliveTime = 60000;
		
		private int correlationCleanupInterval = 10000;
		private int correlationDataRetentionPeriod = 60000;
		private ThreadPoolRejectedPolicy rejectedHandler = ThreadPoolRejectedPolicy.EZI_FLOW_DEFAULT_POLICY;

		public void setCorePoolSize(int corePoolSize) {
			if (corePoolSize <= 0) {
				throw new IllegalArgumentException("corePoolSize must be greater than 0.");
			}
			this.corePoolSize = corePoolSize;
		}

		public void setMaxPoolSize(int maxPoolSize) {
			if (maxPoolSize <= 0) {
				throw new IllegalArgumentException("maxPoolSize must be greater than 0.");
			}
			this.maxPoolSize = maxPoolSize;
		}

		public void setQueueSize(int queueSize) {
			if (queueSize < 0) {
				throw new IllegalArgumentException("queueSize cannot be negative.");
			}
			this.queueSize = Math.min(queueSize, DEFAULT_QUEUE_SIZE);
		}
		
		public void setCorrelationCleanupInterval(int interval) {
			if(interval <= 0) {
				throw new IllegalArgumentException("correlationCleanupInterval must be greater than 0.");
			}
			
			this.correlationCleanupInterval = interval;
		}
		
		public void setCorrelationDataRetentionPeriod(int period) {
			if(period <= 0) {
				throw new IllegalArgumentException("correlationDataRetentionPeriod must be greater than 0.");
			}
			
			this.correlationDataRetentionPeriod = period;
		}

		private static int calculateDefaultPoolSize() {
			return Runtime.getRuntime().availableProcessors();
		}
	}

	@Data
	public static class BPELProperties {
		private String[] bpelFolders = { "bpels" };
		private WatchFolderOption option = WatchFolderOption.EXCLUDE_SUB_FOLDER;
	}
}
