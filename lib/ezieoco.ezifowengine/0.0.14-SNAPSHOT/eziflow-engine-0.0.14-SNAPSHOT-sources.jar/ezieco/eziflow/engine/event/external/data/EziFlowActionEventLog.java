package ezieco.eziflow.engine.event.external.data;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.action.ActionEnum;
import ezieco.eziflow.engine.event.EventType;

public class EziFlowActionEventLog {
	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

	private final String name;
	private final EventType eventType;
	private final ActionEnum actionType;
	private final Action action;
	private Exception exception;

	// Private constructor
	private EziFlowActionEventLog(String name, EventType eventType, ActionEnum actionType, Action action) {
		this.name = name;
		this.eventType = eventType;
		this.actionType = actionType;
		this.action = action;
	}

	// Getters
	public String getName() {
		return name;
	}

	public EventType getEventType() {
		return eventType;
	}

	public ActionEnum getActionType() {
		return actionType;
	}

	public Action getAction() {
		return action;
	}

	public Exception getException() {
		return exception;
	}

	// Setter for exception
	public void setException(Exception exception) {
		this.exception = exception;
	}

	// Builder pattern for creating instances
	public static Builder builder(String name, EventType eventType, Action action) {
		return new Builder(name, eventType, action);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{ ");
		sb.append("\"name\": \"").append(name).append("\", ");
		sb.append("\"event\": \"").append(eventType != null ? eventType.toString() : "").append("\", ");
		sb.append("\"actionType\": \"").append(actionType != null ? actionType.toString() : "").append("\", ");
		sb.append("\"exception\": \"").append(exception != null ? exception.getMessage() : "").append("\", ");
		sb.append("\"startTime\": \"").append(formatTime(action.getStartTime())).append("\", ");
		sb.append("\"endTime\": \"").append(formatTime(action.getEndTime())).append("\", ");
		sb.append("\"elapsed(sec)\": \"").append(calculateElapsedSeconds()).append("\" ");
		sb.append("}");
		return sb.toString();
	}

	private String formatTime(LocalDateTime time) {
		return time != null ? formatter.format(time) : "";
	}

	private String calculateElapsedSeconds() {
		if (action.getStartTime() != null && action.getEndTime() != null) {
			long milliseconds = Duration.between(action.getStartTime(), action.getEndTime()).toMillis();
			return String.format("%.3f", milliseconds / 1000.0);
		}
		return "";
	}

	// Builder class
	public static class Builder {
		private final String name;
		private final EventType eventType;
		private final Action action;
		private ActionEnum actionType;
		private Exception exception;

		Builder(String name, EventType eventType, Action action) {
			this.name = name;
			this.eventType = eventType;
			this.action = action;
			this.actionType = action != null ? action.getActionType() : null;
		}

		public Builder setException(Exception exception) {
			this.exception = exception;
			return this;
		}

		public EziFlowActionEventLog build() {
			EziFlowActionEventLog log = new EziFlowActionEventLog(name, eventType, actionType, action);
			log.setException(exception);
			return log;
		}
	}
}
