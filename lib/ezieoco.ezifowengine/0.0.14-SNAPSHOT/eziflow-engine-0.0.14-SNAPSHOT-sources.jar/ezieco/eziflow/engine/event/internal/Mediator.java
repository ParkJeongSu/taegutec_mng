package ezieco.eziflow.engine.event.internal;

import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;

public interface Mediator {
	void register(EziFlowBridgeListener<EziFlowEvent> listener);

	void unregister(EziFlowBridgeListener<EziFlowEvent> listener);

	void eventOccurred(EziFlowEvent event);
}
