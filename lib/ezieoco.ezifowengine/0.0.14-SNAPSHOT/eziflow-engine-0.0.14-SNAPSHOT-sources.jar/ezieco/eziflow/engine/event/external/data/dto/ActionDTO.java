package ezieco.eziflow.engine.event.external.data.dto;

public interface ActionDTO {

}
