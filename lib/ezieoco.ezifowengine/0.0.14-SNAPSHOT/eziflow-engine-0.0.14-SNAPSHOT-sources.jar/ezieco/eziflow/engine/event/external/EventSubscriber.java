package ezieco.eziflow.engine.event.external;

import ezieco.eziflow.engine.event.external.data.EziFlowActionEventLog;

/**
 * 
 * 엔진에서 발생한 이벤트를 전달받기 위한 인터페이스
 * 
 * @author cglee
 *
 */
public interface EventSubscriber {
	void onAction(EziFlowActionEventLog eventDelivery);
}
