package ezieco.eziflow.engine.event.external.impl;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import ezieco.eziflow.engine.event.external.EventPublisher;
import ezieco.eziflow.engine.event.external.EventSubscriber;
import ezieco.eziflow.engine.event.external.data.EziFlowActionEventLog;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.ErrorMessages;
import ezieco.eziflow.engine.utils.StackTraceFormatter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PubSubMediator implements EventPublisher {
	private final List<EventSubscriber> subscriberList = new CopyOnWriteArrayList<>();

	@Override
	public void registerSubscriber(EventSubscriber subscriber) {
		if (this.subscriberList.contains(subscriber)) {
			log.info("There are duplicate subscriber registrations. " + subscriber);
			return;
		}

		subscriberList.add(subscriber);
	}

	@Override
	public void eventOccured(EziFlowActionEventLog eventDelivery) {
		try {

			for (EventSubscriber sub : this.subscriberList) {
				sub.onAction(eventDelivery);
			}

		} catch (Exception e) {
			this.logNotificationError(eventDelivery.getEventType().name(), e);
		}
	}

	private void logNotificationError(String event, Exception e) {
		try {
			String error = StackTraceFormatter.getCompleteStackTrace(e);
			log.error(ErrorMessages.instance().getMessage(ErrorMessageInfo.builder()
					.errorCodeProvider(ErrorCode.EVENT_NOTIFICATION_ERROR).args(event, error).build()));
		} catch (Exception ex) {
			log.error(e.getLocalizedMessage(), ex);
		}
	}
}
