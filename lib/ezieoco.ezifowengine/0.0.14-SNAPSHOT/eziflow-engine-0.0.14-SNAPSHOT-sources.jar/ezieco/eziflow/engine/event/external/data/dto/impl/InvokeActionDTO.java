package ezieco.eziflow.engine.event.external.data.dto.impl;

import ezieco.eziflow.engine.event.external.data.dto.ActionDTO;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class InvokeActionDTO implements ActionDTO {
	private final String name;
	private final String className;
	private final String methodName;
}
