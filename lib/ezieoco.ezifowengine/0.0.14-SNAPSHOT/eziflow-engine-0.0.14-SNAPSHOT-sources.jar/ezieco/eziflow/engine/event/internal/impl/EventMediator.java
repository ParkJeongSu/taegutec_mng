package ezieco.eziflow.engine.event.internal.impl;

import java.util.concurrent.CopyOnWriteArrayList;

import ezieco.eziflow.engine.event.internal.EziFlowBridgeListener;
import ezieco.eziflow.engine.event.internal.Mediator;
import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;
import ezieco.eziflow.engine.exception.ErrorCode;
import ezieco.eziflow.engine.exception.ErrorMessageInfo;
import ezieco.eziflow.engine.exception.ErrorMessages;
import ezieco.eziflow.engine.utils.StackTraceFormatter;
import lombok.extern.slf4j.Slf4j;

// 메시지 전송자.

@Slf4j
public class EventMediator implements Mediator {
	private final CopyOnWriteArrayList<EziFlowBridgeListener<EziFlowEvent>> listeners = new CopyOnWriteArrayList<>();

	@Override
	public void register(EziFlowBridgeListener<EziFlowEvent> listener) {
		// 중복 체크 꼭 필요하지 않으면 제거 권장
		if (!listeners.contains(listener)) {
			listeners.add(listener);
		} else {
			log.info("Listener already registered: {}", listener);
		}
	}

	@Override
	public void unregister(EziFlowBridgeListener<EziFlowEvent> listener) {
		if (!listeners.remove(listener)) {
			log.info("Attempt to unregister non-existent listener: {}", listener);
		}
	}

	@Override
	public void eventOccurred(EziFlowEvent event) {
		// 사이즈 캐싱으로 약간의 성능 개선
		final int size = listeners.size();
		for (int i = size - 1; i >= 0; i--) {
			EziFlowBridgeListener<EziFlowEvent> listener = listeners.get(i);
			try {
				listener.onDeliverEvent(event);
			} catch (Exception e) {
				logNotificationError(event.getType().toString(), e);
			}
		}
	}

	private void logNotificationError(String eventType, Exception e) {
		try {
			String errorDetails = StackTraceFormatter.getCompleteStackTrace(e);
			String errorMessage = ErrorMessages.instance().getMessage(ErrorMessageInfo.builder()
					.errorCodeProvider(ErrorCode.EVENT_NOTIFICATION_ERROR).args(eventType, errorDetails).build());
			log.error(errorMessage, e);
		} catch (Exception ex) {
			log.error("Error logging notification error: " + e.getMessage(), ex);
		}
	}
}
