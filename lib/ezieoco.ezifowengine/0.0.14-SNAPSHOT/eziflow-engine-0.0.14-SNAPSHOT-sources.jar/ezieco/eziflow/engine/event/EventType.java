package ezieco.eziflow.engine.event;

public enum EventType {
	BEFORE_ACTION, 
	AFTER_ACTION, 
	ACTION_FAILED,
	ACTION_TIMEOUT, 
	ACTION_INTERRUPTED,
	ACTION_COMPLETED
}
