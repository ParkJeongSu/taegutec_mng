package ezieco.eziflow.engine.event.internal.data;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.event.EventType;

public class EziFlowInternalEvent extends EziFlowEvent {

    private EziFlowInternalEvent(Builder builder) {
        super(builder);
    }

    public static Builder newBuilder(EventType type, Action action) {
        return new Builder(type, action);
    }

    public static class Builder extends EziFlowEvent.Builder<Builder> {
        Builder(EventType type, Action action) {
            super(type, action);
        }

        @Override
        protected Builder self() {
            return this;
        }

        @Override
        public EziFlowInternalEvent build() {
            return new EziFlowInternalEvent(this);
        }
    }
}

