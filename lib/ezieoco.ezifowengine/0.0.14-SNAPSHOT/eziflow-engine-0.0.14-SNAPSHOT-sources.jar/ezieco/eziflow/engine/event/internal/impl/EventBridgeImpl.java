package ezieco.eziflow.engine.event.internal.impl;

// 이벤트 구독자와 연결해 준다.
import java.util.EnumMap;
import java.util.Map;

import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.internal.EziFlowBridgeListener;
import ezieco.eziflow.engine.event.internal.EziFlowInternalListener;
import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EventBridgeImpl implements EziFlowBridgeListener<EziFlowEvent> {

	private final String className;

	// EnumMap 사용하여 성능 및 메모리 최적화
	private final Map<EventType, EziFlowInternalListener<? super EziFlowEvent>> customListenerMap = new EnumMap<>(
			EventType.class);

	public EventBridgeImpl(String name) {
		this.className = name;
	}

	@Override
	public void onDeliverEvent(EziFlowEvent event) {
		final EziFlowInternalListener<? super EziFlowEvent> listener = customListenerMap.get(event.getType());
		if (listener != null) {
			listener.onFlowEvent(event);
		}

		if (log.isDebugEnabled()) {
			log.debug("Class={}, EventType={}, Action={}", className, event.getType(), event.getAction());
		}
	}

	@Override
	public void overrideFlowEvent(EventType eventType, EziFlowInternalListener<? super EziFlowEvent> listener) {
		customListenerMap.put(eventType, listener);
	}
}
