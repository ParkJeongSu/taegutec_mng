package ezieco.eziflow.engine.event.internal;

import ezieco.eziflow.engine.event.EventType;
import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;

public interface EziFlowBridgeListener<E extends EziFlowEvent> extends EziFlowListener {
    void onDeliverEvent(E event);

    void overrideFlowEvent(EventType eventType, EziFlowInternalListener<? super E> listener);
}
