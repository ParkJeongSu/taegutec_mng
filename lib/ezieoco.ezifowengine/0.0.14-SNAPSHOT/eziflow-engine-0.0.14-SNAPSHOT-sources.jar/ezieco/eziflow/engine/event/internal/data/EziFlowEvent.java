package ezieco.eziflow.engine.event.internal.data;

import ezieco.eziflow.engine.action.Action;
import ezieco.eziflow.engine.event.EventType;

public abstract class EziFlowEvent {
	private EventType type;
	private Action action;
	private Exception exception;

	protected EziFlowEvent(Builder<?> builder) {
		this.type = builder.type;
		this.action = builder.action;
		this.exception = builder.exception;
	}

	public EventType getType() {
		return type;
	}

	public Action getAction() {
		return action;
	}

	public Exception getException() {
		return exception;
	}

	public abstract static class Builder<T extends Builder<T>> {
		private final EventType type;
		private final Action action;
		private Exception exception;

		protected Builder(EventType type, Action action) {
			this.type = type;
			this.action = action;
		}

		public T setException(Exception exception) {
			this.exception = exception;
			return self();
		}

		protected abstract T self();

		public abstract EziFlowEvent build();
	}
}
