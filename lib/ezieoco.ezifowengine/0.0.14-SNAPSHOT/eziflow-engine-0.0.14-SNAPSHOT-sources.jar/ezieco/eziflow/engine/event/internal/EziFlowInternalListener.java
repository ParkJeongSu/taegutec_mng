package ezieco.eziflow.engine.event.internal;

import ezieco.eziflow.engine.event.internal.data.EziFlowEvent;

@FunctionalInterface
public interface EziFlowInternalListener<E extends EziFlowEvent> extends EziFlowListener {
    void onFlowEvent(E event);
}

