package ezieco.eziflow.engine.event.external;

import ezieco.eziflow.engine.event.external.data.EziFlowActionEventLog;

/**
 * 엔진에서 발생하는 이벤트를 전달하기 위한 인터페이스
 * 
 * @author cglee
 *
 */
public interface EventPublisher {
	void registerSubscriber(EventSubscriber subscriber);

	void eventOccured(EziFlowActionEventLog eventDelivery);
}
