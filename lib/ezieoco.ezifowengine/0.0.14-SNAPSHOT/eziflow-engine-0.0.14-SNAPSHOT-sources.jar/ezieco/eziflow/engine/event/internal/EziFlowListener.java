package ezieco.eziflow.engine.event.internal;

public interface EziFlowListener {
}
