package ezieco.eziflow.engine.impl;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.xml.namespace.QName;

import ezieco.eziflow.engine.EziFlowService;
import ezieco.eziflow.engine.action.impl.ExecuteAction;
import ezieco.eziflow.engine.concurrent.ManagedThreadPool;
import ezieco.eziflow.engine.core.ProcessCreationManager;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.event.external.EventPublisher;
import ezieco.eziflow.engine.event.external.EventSubscriber;
import ezieco.eziflow.engine.impl.data.ExecutionParams;
import ezieco.eziflow.engine.runtime.EziFlowInstance;
import ezieco.eziflow.engine.runtime.impl.EziFlowInstanceimpl;
import ezieco.eziflow.engine.utils.EziFlowConst;

public class EziFlowServiceImpl implements EziFlowService {

	private final EventPublisher publisher;
	private final ProcessCreationManager processCreationManager;
	private final ManagedThreadPool managedThreadPool;

	public EziFlowServiceImpl() {
		this.publisher = SingletonManager.getInstance().getSingletonInstance(EventPublisher.class).get();
		this.processCreationManager = SingletonManager.getInstance().getSingletonInstance(ProcessCreationManager.class)
				.get();
		this.managedThreadPool = SingletonManager.getInstance().getSingletonInstance(ManagedThreadPool.class).get();
	}

	@Override
	public EziFlowInstance<?> execute(String name, Object... args) throws InterruptedException, ExecutionException {
//		ExecuteAction action = this.processManager.createProcess(new QName(FlowConst.DEFAULT_TARGETNAMESPACE, this.ensureBpelExtension(name)),
//				publisher);
//		
//		action.setSuperAction(FlowRuntimeContext.currenttRuntimeContext().getExecuteAction());
//		action.setReq(args);
//
//		FlowInstance<?> instance = new FlowInstanceimpl(action, threadPoolManager.submit(action));

		EziFlowInstance<?> instance = this.executeAsync(name, args);
		instance.get();
		return instance;
	}

	@Override
	public EziFlowInstance<?> executeAsync(String name, Object... args) {
		ExecuteAction action = this.processCreationManager.createProcess(
				new QName(EziFlowConst.DEFAULT_TARGETNAMESPACE, this.ensureBpelExtension(name)), publisher);

		if (action == null) {
			return null;
		}

		action.setSuperAction(action.getFlowRuntimeContext().getExecuteAction());
		action.setParent(action.getFlowRuntimeContext().getCurrentThreadAction());
		action.setReq(args);

		EziFlowInstance<?> instance = new EziFlowInstanceimpl(action, managedThreadPool.submit(action));
		return instance;
	}

	public EziFlowInstance<?> execute(ExecutionParams params) throws InterruptedException, ExecutionException {
		EziFlowInstance<?> instance = this.executeAsync(params);
		instance.get();
		return instance;
	}

	public EziFlowInstance<?> executeAsync(ExecutionParams params) {

		ExecuteAction action = this.processCreationManager.createProcess(
				new QName(EziFlowConst.DEFAULT_TARGETNAMESPACE, this.ensureBpelExtension(params.getName())), publisher);

		if (action == null) {
			return null;
		}

		action.setSuperAction(action.getFlowRuntimeContext().getExecuteAction());
		action.setParent(action.getFlowRuntimeContext().getCurrentThreadAction());
		action.setReq(params.getArgs());
		action.getFlowRuntimeContext().setPreActions(params.getPreActions());
		action.getFlowRuntimeContext().setPostActions(params.getPostActions());

		EziFlowInstance<?> instance = new EziFlowInstanceimpl(action, managedThreadPool.submit(action));
		return instance;
	}

	@Override
	public void registerSubscriber(EventSubscriber eventSubscriber) {
		this.publisher.registerSubscriber(eventSubscriber);
	}

	@Override
	public void awake(Object corId, Object... args) {
		this.managedThreadPool.awake(corId, args);
	}

	private String ensureBpelExtension(String fileName) {
		final String ext = EziFlowConst.DEFAULT_EXTENSION;
		int extLength = ext.length();
		int fileLength = fileName.length();
		if (fileLength >= extLength && fileName.regionMatches(true, fileLength - extLength, ext, 0, extLength)) {
			return fileName;
		}
		return fileName + ext;
	}

	@Override
	public void shutdown() {
		managedThreadPool.shutdown();
	}

	@Override
	public List<Runnable> shutdownNow() {
		return managedThreadPool.shutdownNow();
	}

	@Override
	public List<Runnable> shutdown(long timeout, TimeUnit unit) {
		return managedThreadPool.shutdown(timeout, unit);
	}

	@Override
	public boolean hasCorrelationId(String id) {
		return this.managedThreadPool.hasCorrelationId(id);
	}
}
