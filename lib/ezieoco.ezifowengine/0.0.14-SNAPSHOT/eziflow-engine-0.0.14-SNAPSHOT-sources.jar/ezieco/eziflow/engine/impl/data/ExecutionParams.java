package ezieco.eziflow.engine.impl.data;

import java.util.Arrays;
import java.util.Objects;

import ezieco.eziflow.engine.action.PostAction;
import ezieco.eziflow.engine.action.PreAction;

public class ExecutionParams {
	private final String name;
	private final Object[] args;
	private final PreAction[] preActions;
	private final PostAction[] postActions;

	private ExecutionParams(Builder builder) {
		this.name = builder.name;
		this.args = builder.args.clone();

		// PreActions 리스트는 변경 불가능한 리스트로 설정
		this.preActions = builder.preActions == null ? new PreAction[0]
				: Arrays.copyOf(builder.preActions, builder.preActions.length);

		// PostActions 리스트는 변경 불가능한 리스트로 설정
		this.postActions = builder.postActions == null ? new PostAction[0]
				: Arrays.copyOf(builder.postActions, builder.postActions.length);
	}

	public String getName() {
		return name;
	}

	public Object[] getArgs() {
		return args.clone();
	}
	
	public PreAction[] getPreActions() {
		return this.preActions;
	}

	public PostAction[] getPostActions() {
		return this.postActions;
	}

	public static Builder builder(String name, Object... args) {
		return new Builder(name, args);
	}

	public static class Builder {
		private final String name;
		private final Object[] args;
		private PreAction[] preActions;
		private PostAction[] postActions;

		Builder(String name, Object... args) {
			this.name = Objects.requireNonNull(name, "name must not be null or empty");
			if (name.isEmpty()) {
				throw new IllegalArgumentException("name must not be empty");
			}
			this.args = Objects.requireNonNull(args, "args must not be null");
			if (args.length == 0) {
				throw new IllegalArgumentException("args must not be empty");
			}
		}

		// PreAction 하나를 받을 때 리스트로 변환하여 저장
		public Builder preAction(PreAction... preAction) {
			this.preActions = preAction;
			return this;
		}

		// PostAction 하나 이상을 받을 때 배열로 저장
		public Builder postAction(PostAction... postAction) {
			this.postActions = postAction;
			return this;
		}

		public ExecutionParams build() {
			return new ExecutionParams(this);
		}
	}
}
