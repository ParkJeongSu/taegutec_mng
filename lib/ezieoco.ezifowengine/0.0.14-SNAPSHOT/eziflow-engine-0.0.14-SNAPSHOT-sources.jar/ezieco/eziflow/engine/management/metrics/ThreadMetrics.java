package ezieco.eziflow.engine.management.metrics;

import java.util.concurrent.ThreadPoolExecutor;

import ezieco.eziflow.engine.concurrent.ExecutorProvider;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;

public class ThreadMetrics {
	private final Gauge activeThreads;
	private final Gauge availableThreads;
	private final Gauge queueSizeUsed;
	private final Gauge queueSizeAvailable;

	public ThreadMetrics(MeterRegistry registry, ExecutorProvider executorProvider) {
		ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executorProvider.getExecutorService();

		this.activeThreads = Gauge
				.builder("eziflow4j.threadpool.activeThreads", threadPoolExecutor, ThreadPoolExecutor::getActiveCount)
				.description("Number of threads that are actively executing tasks").register(registry);

		this.availableThreads = Gauge
				.builder("eziflow4j.threadpool.availableThreads", threadPoolExecutor,
						pool -> pool.getMaximumPoolSize() - pool.getActiveCount())
				.description("Number of threads available for new tasks").register(registry);

		this.queueSizeUsed = Gauge
				.builder("eziflow4j.threadpool.queueSizeUsed", threadPoolExecutor, pool -> pool.getQueue().size())
				.description("Number of tasks in the queue that are waiting to be executed").register(registry);

		this.queueSizeAvailable = Gauge
				.builder("eziflow4j.threadpool.queueSizeAvailable", threadPoolExecutor,
						pool -> pool.getQueue().remainingCapacity())
				.description("Available capacity left in the queue for new tasks").register(registry);
	}
}
