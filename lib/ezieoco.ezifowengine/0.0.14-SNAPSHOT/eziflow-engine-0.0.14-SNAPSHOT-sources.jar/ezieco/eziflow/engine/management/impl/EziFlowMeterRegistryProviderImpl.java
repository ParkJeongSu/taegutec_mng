package ezieco.eziflow.engine.management.impl;

import java.util.Objects;

import ezieco.eziflow.engine.management.EziFlowMeterRegistryProvider;
import io.micrometer.core.instrument.MeterRegistry;

public class EziFlowMeterRegistryProviderImpl implements EziFlowMeterRegistryProvider {

	private final MeterRegistry meterRegistry;

	public EziFlowMeterRegistryProviderImpl(MeterRegistry meterRegistry) {
		this.meterRegistry = Objects.requireNonNull(meterRegistry, "MeterRegistry must not be null");
	}

	@Override
	public MeterRegistry getMeterRegistry() {
		return meterRegistry;
	}
}
