package ezieco.eziflow.engine.management.metrics;

import java.util.concurrent.atomic.AtomicInteger;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

public class EziFlowMetrics {

	private static final String PROCESS = "process";

	private final Counter invocationCounter;
	private final Counter completionCounter;
	private final Counter errorCounter;
	private final Timer timer;
	private final Gauge activeGauge;
	private final AtomicInteger activeCount;

	public EziFlowMetrics(MeterRegistry registry, String bpelName) {
		this.activeCount = new AtomicInteger(0);
		this.invocationCounter = Counter.builder("eziflow4j.bpel.invocations").tags(PROCESS, bpelName)
				.register(registry);
		this.completionCounter = Counter.builder("eziflow4j.bpel.completions").tags(PROCESS, bpelName)
				.register(registry);
		this.errorCounter = Counter.builder("eziflow4j.bpel.errors").tags(PROCESS, bpelName).register(registry);
		this.timer = Timer.builder("eziflow4j.bpel.timer").tags(PROCESS, bpelName).register(registry);
		this.activeGauge = Gauge.builder("eziflow4j.bpel.active", activeCount, AtomicInteger::get)
				.tags(PROCESS, bpelName).description("Current number of active BPEL processes").register(registry);
	}

	// Getter methods for the metrics
	public Counter getInvocationCounter() {
		return invocationCounter;
	}

	public Counter getCompletionCounter() {
		return completionCounter;
	}

	public Counter getErrorCounter() {
		return errorCounter;
	}

	public Timer getTimer() {
		return timer;
	}

	public AtomicInteger getActiveCount() {
		return activeCount;
	}
}