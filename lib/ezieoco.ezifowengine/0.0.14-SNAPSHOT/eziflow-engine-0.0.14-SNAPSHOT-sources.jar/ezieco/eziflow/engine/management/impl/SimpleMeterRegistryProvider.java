package ezieco.eziflow.engine.management.impl;

import ezieco.eziflow.engine.management.EziFlowMeterRegistryProvider;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

public class SimpleMeterRegistryProvider implements EziFlowMeterRegistryProvider {
    private final MeterRegistry meterRegistry;
    
    public SimpleMeterRegistryProvider() {
		meterRegistry = new SimpleMeterRegistry();
	}

	@Override
	public MeterRegistry getMeterRegistry() {
		return this.meterRegistry;
	}

}
