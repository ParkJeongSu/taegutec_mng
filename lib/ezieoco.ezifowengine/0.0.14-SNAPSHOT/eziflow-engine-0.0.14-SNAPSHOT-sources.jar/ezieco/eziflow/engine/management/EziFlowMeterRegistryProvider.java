package ezieco.eziflow.engine.management;

import io.micrometer.core.instrument.MeterRegistry;

public interface EziFlowMeterRegistryProvider {
	MeterRegistry getMeterRegistry();
}
