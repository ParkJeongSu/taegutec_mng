package ezieco.eziflow.engine.management;

import java.util.function.Supplier;

public interface MetricManager {
	String getMetricsInfo(String bpelName);
	
	<T> T processBpel(String bpelName, Supplier<T> processSupplier);

	void processBpel(String bpelName, Runnable processRunnable);
	
    // 에러 발생 시 메트릭스 업데이트
    void incrementErrorMetrics(String bpelName);
}
