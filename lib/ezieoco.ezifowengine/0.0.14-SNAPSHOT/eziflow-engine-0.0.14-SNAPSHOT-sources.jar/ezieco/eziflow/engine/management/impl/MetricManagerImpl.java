package ezieco.eziflow.engine.management.impl;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import ezieco.eziflow.engine.concurrent.ExecutorProvider;
import ezieco.eziflow.engine.config.EziFlowProperties;
import ezieco.eziflow.engine.config.EziFlowProperties.ThreadProperties;
import ezieco.eziflow.engine.management.EziFlowMeterRegistryProvider;
import ezieco.eziflow.engine.management.MetricManager;
import ezieco.eziflow.engine.management.metrics.EziFlowMetrics;
import ezieco.eziflow.engine.management.metrics.GlobalMetrics;
import ezieco.eziflow.engine.management.metrics.ThreadMetrics;
import io.micrometer.core.instrument.Gauge;

public class MetricManagerImpl implements MetricManager {
	private final EziFlowProperties flowProperties;
	private final EziFlowMeterRegistryProvider meterRegistryProvider;
	private final GlobalMetrics globalMetrics;
	private final ThreadMetrics threadMetrics;

	public MetricManagerImpl(EziFlowProperties flowProperties, EziFlowMeterRegistryProvider registryProvider,
			ExecutorProvider executorProvider) {
		this.flowProperties = flowProperties;
		this.meterRegistryProvider = registryProvider;
		this.globalMetrics = new GlobalMetrics(registryProvider.getMeterRegistry());
		this.threadMetrics = new ThreadMetrics(registryProvider.getMeterRegistry(), executorProvider);
		registerThreadAndQueueMetrics();
	}

	private EziFlowMetrics createAndGetMetricsForBpel(String bpelName) {
		return new EziFlowMetrics(meterRegistryProvider.getMeterRegistry(), bpelName);
	}

	public <T> T processBpel(String bpelName, Supplier<T> processSupplier) {
		EziFlowMetrics metrics = createAndGetMetricsForBpel(bpelName);
		metrics.getActiveCount().incrementAndGet();
		globalMetrics.getActiveGlobalCount().incrementAndGet();
		metrics.getInvocationCounter().increment();
		globalMetrics.getTotalInvocations().increment();

		Callable<T> callable = () -> processSupplier.get();

		try {
			T result = metrics.getTimer().recordCallable(callable);
			metrics.getCompletionCounter().increment();
			globalMetrics.getTotalCompletions().increment();
			return result;
		} catch (Exception e) {
			// 여기 예외를 타는 경우는 없다.
			metrics.getErrorCounter().increment();
			globalMetrics.getTotalErrors().increment();
			throw new RuntimeException("Error in BPEL process: " + e.getMessage(), e);
		} finally {
			metrics.getActiveCount().decrementAndGet();
			globalMetrics.getActiveGlobalCount().decrementAndGet();
		}
	}

	@Override
	public void processBpel(String bpelName, Runnable processRunnable) {
		EziFlowMetrics metrics = createAndGetMetricsForBpel(bpelName);
		metrics.getActiveCount().incrementAndGet();
		globalMetrics.getActiveGlobalCount().incrementAndGet();
		metrics.getInvocationCounter().increment();
		globalMetrics.getTotalInvocations().increment();

		try {
			metrics.getTimer().record(processRunnable);
			metrics.getCompletionCounter().increment();
			globalMetrics.getTotalCompletions().increment();
		} catch (Exception e) {
			// 여기 예외를 타는 경우는 없다.
			metrics.getErrorCounter().increment();
			globalMetrics.getTotalErrors().increment();
			throw new RuntimeException("Error in BPEL process: " + e.getMessage(), e);
		} finally {
			metrics.getActiveCount().decrementAndGet();
			globalMetrics.getActiveGlobalCount().decrementAndGet();
		}
	}

	public String getMetricsInfo(String bpelName) {
		StringBuilder sb = new StringBuilder();
		EziFlowMetrics flowMetrics = createAndGetMetricsForBpel(bpelName);

		sb.append("Metrics for BPEL Process: ").append(bpelName).append("\n");
		sb.append("Active Processes: ").append(flowMetrics.getActiveCount().get()).append("\n");
		sb.append("Total Invocations: ").append(flowMetrics.getInvocationCounter().count()).append("\n");
		sb.append("Total Completions: ").append(flowMetrics.getCompletionCounter().count()).append("\n");
		sb.append("Total Errors: ").append(flowMetrics.getErrorCounter().count()).append("\n");
		sb.append("Average Duration (ms): ")
				.append(flowMetrics.getTimer().totalTime(TimeUnit.MILLISECONDS) / flowMetrics.getTimer().count())
				.append("\n");
		sb.append("\nGlobal Metrics:\n");
		sb.append("Active Global Processes: ").append(globalMetrics.getActiveGlobalCount().get()).append("\n");
		sb.append("Global Total Invocations: ").append(globalMetrics.getTotalInvocations().count()).append("\n");
		sb.append("Global Total Completions: ").append(globalMetrics.getTotalCompletions().count()).append("\n");
		sb.append("Global Total Errors: ").append(globalMetrics.getTotalErrors().count()).append("\n");

		return sb.toString();
	}

	private void registerThreadAndQueueMetrics() {
		ThreadProperties threadProperties = flowProperties.getThreadProperties();
		Gauge.builder("threadpool.coreSize", threadProperties, ThreadProperties::getCorePoolSize)
				.description("Core number of threads in the thread pool")
				.register(meterRegistryProvider.getMeterRegistry());
		Gauge.builder("threadpool.maxSize", threadProperties, ThreadProperties::getMaxPoolSize)
				.description("Maximum number of threads in the thread pool")
				.register(meterRegistryProvider.getMeterRegistry());
		Gauge.builder("threadpool.queueSize", threadProperties, ThreadProperties::getQueueSize)
				.description("Size of the queue for pending tasks").register(meterRegistryProvider.getMeterRegistry());
	}

	@Override
	public void incrementErrorMetrics(String bpelName) {
		EziFlowMetrics metrics = createAndGetMetricsForBpel(bpelName);
		metrics.getErrorCounter().increment();
		globalMetrics.getTotalErrors().increment();
	}
}