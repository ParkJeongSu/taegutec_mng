package ezieco.eziflow.engine.management.metrics;

import java.util.concurrent.atomic.AtomicInteger;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;

public class GlobalMetrics {
	private final Counter totalInvocations;
	private final Counter totalCompletions;
	private final Counter totalErrors;
	private final Gauge totalActive;
	private final AtomicInteger activeGlobalCount;

	public GlobalMetrics(MeterRegistry registry) {
		this.activeGlobalCount = new AtomicInteger(0);
		this.totalInvocations = Counter.builder("eziflow4j.total.invocations").register(registry);
		this.totalCompletions = Counter.builder("eziflow4j.total.completions").register(registry);
		this.totalErrors = Counter.builder("eziflow4j.total.errors").register(registry);
		this.totalActive = Gauge.builder("eziflow4j.total.active", activeGlobalCount, AtomicInteger::get)
				.description("Total number of active processes").register(registry);
	}

	// Getter methods for the metrics
	public Counter getTotalInvocations() {
		return totalInvocations;
	}

	public Counter getTotalCompletions() {
		return totalCompletions;
	}

	public Counter getTotalErrors() {
		return totalErrors;
	}

	public Gauge getTotalActive() {
		return totalActive;
	}

	public AtomicInteger getActiveGlobalCount() {
		return activeGlobalCount;
	}
}