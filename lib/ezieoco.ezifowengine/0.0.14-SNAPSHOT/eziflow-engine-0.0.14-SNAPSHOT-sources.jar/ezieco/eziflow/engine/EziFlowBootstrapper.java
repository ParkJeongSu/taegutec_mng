package ezieco.eziflow.engine;

import java.util.concurrent.RejectedExecutionHandler;

import ezieco.eziflow.engine.concurrent.ExecutorProvider;
import ezieco.eziflow.engine.concurrent.ManagedThreadPool;
import ezieco.eziflow.engine.concurrent.ThreadPoolRejectedPolicyBuilder;
import ezieco.eziflow.engine.concurrent.impl.EziFlowThreadPoolManagerImpl;
import ezieco.eziflow.engine.config.EziFlowConfigurator;
import ezieco.eziflow.engine.core.EziFlowAppContext;
import ezieco.eziflow.engine.core.ProcessCreationManager;
import ezieco.eziflow.engine.core.impl.ProcessManagerImpl;
import ezieco.eziflow.engine.core.impl.SingletonManager;
import ezieco.eziflow.engine.event.external.EventPublisher;
import ezieco.eziflow.engine.event.external.impl.PubSubMediator;
import ezieco.eziflow.engine.expression.EziFlowExpression;
import ezieco.eziflow.engine.impl.EziFlowServiceImpl;
import ezieco.eziflow.engine.management.MetricManager;
import ezieco.eziflow.engine.management.impl.MetricManagerImpl;
import ezieco.eziflow.engine.repository.EziFlowSpecRepo;

public abstract class EziFlowBootstrapper {

	private EziFlowBootstrapper() {
	}

	public static EziFlowService run(EziFlowConfigurator config) {
		initializeRejectedExecutionHandler(config);
		ExecutorProvider executorProvider = initializeThreadPoolManager(config);
		initializeMetricManager(config, executorProvider);
		initializeProcessManager(config);
		registerSingletons(config);

		return new EziFlowServiceImpl();
	}

	private static void initializeRejectedExecutionHandler(EziFlowConfigurator config) {
		RejectedExecutionHandler rejectedExecutionHandler = ThreadPoolRejectedPolicyBuilder.create(
				config.getEziFlowProperties().getThreadProperties().getRejectedHandler(),
				config.getEziFlowProperties().getThreadProperties());
		SingletonManager.getInstance().registerSingleton(RejectedExecutionHandler.class, rejectedExecutionHandler);
	}

	private static EziFlowThreadPoolManagerImpl initializeThreadPoolManager(EziFlowConfigurator config) {
		EziFlowThreadPoolManagerImpl threadPoolManager = new EziFlowThreadPoolManagerImpl(
				config.getEziFlowProperties());
		threadPoolManager.init();
		SingletonManager.getInstance().registerSingleton(ManagedThreadPool.class, threadPoolManager);
		return threadPoolManager;
	}

	private static void initializeMetricManager(EziFlowConfigurator config, ExecutorProvider executorProvider) {
		MetricManagerImpl metricManager = new MetricManagerImpl(config.getEziFlowProperties(),
				config.getMeterRegistryProvider(), executorProvider);
		SingletonManager.getInstance().registerSingleton(MetricManager.class, metricManager);
	}

	private static void initializeProcessManager(EziFlowConfigurator config) {
		ProcessCreationManager processManager = new ProcessManagerImpl(config.getEziFlowSpecRepo());
		SingletonManager.getInstance().registerSingleton(ProcessCreationManager.class, processManager);
	}

	private static void registerSingletons(EziFlowConfigurator config) {
		registerEventPublisher();
		registerFlowAppContext(config);
		registerFlowSpecRepo(config);
		registerFlowExpression(config);
	}

	private static void registerEventPublisher() {
		SingletonManager.getInstance().registerSingleton(EventPublisher.class, new PubSubMediator());
	}

	private static void registerFlowAppContext(EziFlowConfigurator config) {
		SingletonManager.getInstance().registerSingleton(EziFlowAppContext.class, config.getEziFlowAppContext());
	}

	private static void registerFlowSpecRepo(EziFlowConfigurator config) {
		SingletonManager.getInstance().registerSingleton(EziFlowSpecRepo.class, config.getEziFlowSpecRepo());
	}

	private static void registerFlowExpression(EziFlowConfigurator config) {
		SingletonManager.getInstance().registerSingleton(EziFlowExpression.class, config.getEziFlowExpression());
	}
}
