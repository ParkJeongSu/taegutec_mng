package ezieco.eziflow.engine.exception;

public interface ErrorCodeProvider {
	String getName();
	String getKey();
}
