package ezieco.eziflow.engine.exception;

public interface ErrorMessageConverter {

	String getMessage(ErrorMessageInfo errorMessageInfo);
}
