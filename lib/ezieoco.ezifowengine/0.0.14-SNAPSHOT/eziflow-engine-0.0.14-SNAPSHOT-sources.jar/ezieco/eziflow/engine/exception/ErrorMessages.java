package ezieco.eziflow.engine.exception;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringUtils;

public class ErrorMessages implements ErrorMessageConverter {

	private static final String BUNDLE_NAME_KO = ".error-ko";
	private static final String BUNDLE_NAME_EN = ".error-en";

	private ResourceBundle resourceBundle = null;

	private static class SingletonHelper {
		private static final ErrorMessages INSTANCE = new ErrorMessages();
	}

	public static ErrorMessages instance() {
		return SingletonHelper.INSTANCE;
	}

	private ErrorMessages() {
		Locale locale = Locale.getDefault();
		if (locale.equals(Locale.KOREA) || locale.equals(Locale.KOREAN))
			resourceBundle = ResourceBundle.getBundle(ErrorMessages.class.getPackage().getName() + BUNDLE_NAME_KO);
		else
			resourceBundle = ResourceBundle.getBundle(ErrorMessages.class.getPackage().getName() + BUNDLE_NAME_EN);
	}

	@Override
	public String getMessage(ErrorMessageInfo errorMessageInfo) {
		if (!validateErrorMessageInfo(errorMessageInfo))
			return StringUtils.EMPTY;

		return createErrorMessageWithErrorCode(errorMessageInfo);
	}

	private boolean validateErrorMessageInfo(ErrorMessageInfo errorMessageInfo) {
		return errorMessageInfo != null && errorMessageInfo.getErrorCodeProvider() != null
				&& !StringUtils.isBlank(errorMessageInfo.getErrorCodeProvider().getKey());
	}

	private String createErrorMessageWithErrorCode(ErrorMessageInfo errorMessageInfo) {
		StringBuilder sb = new StringBuilder().append("[").append(errorMessageInfo.getErrorCodeProvider().getName())
				.append("] ").append(format(errorMessageInfo));

		return sb.toString();
	}

	private String format(ErrorMessageInfo errorMessageInfo) {
		try {
			String template = resourceBundle.getString(errorMessageInfo.getErrorCodeProvider().getKey());
			return MessageFormat.format(template, errorMessageInfo.getArgs());
		} catch (MissingResourceException e) {
			return '!' + errorMessageInfo.getErrorCodeProvider().getKey() + '!';
		}
	}
}
