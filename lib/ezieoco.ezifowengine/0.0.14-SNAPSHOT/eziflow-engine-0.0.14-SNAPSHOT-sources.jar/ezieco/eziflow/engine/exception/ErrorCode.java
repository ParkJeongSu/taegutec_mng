package ezieco.eziflow.engine.exception;

public enum ErrorCode implements ErrorCodeProvider {
	QNAME_FIND_ERROR("flow.qname.find"), 
	ASSIGN_NEED_BOTH("flow.assign.need_both"), 
	ASSIGN_ERROR("flow.assign.error"),
	VARIABLE_NEED_SET("flow.variable.need_set"), 
	INVALID_VARIABLETYPE("flow.invalid.variable_type"),
	EMPTY_VARIABLENAME("flow.empty.variable_name"), 
	DUPLICATE_INPUT("flow.duplicate.input"),
	THREAD_POOL_ERROR("flow.thread_pool.error"),
	INVALID_CONDITION_RESULT("flow.invalid.condition_result"),
	INVALID_EXPRESSION("flow.invalid.expression"),
	READ_NODE_ERROR("flow.read_node.error"),
	EVENT_NOTIFICATION_ERROR("flow.event_notification.error"),
	RECEIVE_TIMEOUT("flow.receive_timeout"),
	INVALID_PARTNERLINK("flow.invalid.partner_link"),
	INVALID_INVOKE_OPERATION("flow.invalid.invoke_operation"),
	INVALID_ARGUMENT("flow.invalid.argument"),
	INVALID_INVOKE("flow.invalid.invoke"),
	REFLECTION_INVOKE_ERROR("flow.reflection.invoke.error"),
	INVOKEWF_ERROR("flow.invoke_wf.error"),
	NO_SUCH_METHOD("flow.no_such.method"),
	INVALID_COLLECTION_TYPE("flow.invalid.collection_type"),
	INVALID_FAULTVARIABLE_TYPE("flow.invalid.fault_variable_type"),
	REFLECTION_CREATE_ERROR("flow.reflection.create.error"),
	REFLECTION_THROW_ERROR("flow.reflection.throw.error"),
	NO_SUCH_CONSTRUCTOR("flow.no_such.constructor"),
	USER_DEFINED_EXCEPTION("flow.user_defined.exception"),
	EXCEPTION_IN_FUNCTION("flow.exception_in_function"),
	NO_WAIT_CORID("flow.no_wait_corid"),
	INVALID_CORRELATION_ID("flow.invalid.correlation_id"),
	NO_THREADPOOL_NAME("flow.no_threadpool_name"),
	NO_DEFAULT_THREADPOOL("flow.no_default_threadpool"),
	NULL_POINTER_ERROR("flow.nullpointer.error"),
	BEAN_ALREADY_EXISTS("flow.bean.error-001"),

	// 추가된 오류 코드
	BPEL_SPEC_NOT_FOUND("flow.bpel_spec.not_found"),
	ACTION_INIT_ERROR("flow.action.init_error"),

	UNEXPECTED_ERROR("flow.unexpected");

	private String key;

	ErrorCode(String key) {
		this.key = key;
	}

	@Override
	public String getName() {
		return this.name();
	}

	@Override
	public String getKey() {
		return this.key;
	}
}
