package ezieco.eziflow.engine.exception;

import java.util.Locale;

import lombok.Getter;

@Getter
public class ErrorMessageInfo {
	private ErrorCodeProvider errorCodeProvider;
	private Object[] args;
	private Locale locale;

	// Private 생성자
	private ErrorMessageInfo(ErrorCodeProvider errorCodeProvider, Object[] args, Locale locale) {
		this.errorCodeProvider = errorCodeProvider;
		this.args = args;
		this.locale = locale;
	}

	public static class ErrorMessageInfoBuilder {
		private ErrorCodeProvider errorCodeProvider;
		private Object[] args;
		private Locale locale;

		public ErrorMessageInfoBuilder errorCodeProvider(ErrorCodeProvider errorCodeProvider) {
			this.errorCodeProvider = errorCodeProvider;
			return this;
		}

		// varargs로 args를 처리
		public ErrorMessageInfoBuilder args(Object... args) {
			this.args = args;
			return this;
		}

		public ErrorMessageInfoBuilder locale(Locale locale) {
			this.locale = locale;
			return this;
		}

		public ErrorMessageInfo build() {
			return new ErrorMessageInfo(errorCodeProvider, args, locale);
		}
	}

	public static ErrorMessageInfoBuilder builder() {
		return new ErrorMessageInfoBuilder();
	}
}
