package ezieco.eziflow.engine.exception;

import org.w3c.dom.Node;

import ezieco.eziflow.engine.utils.StackTraceFormatter;
import ezieco.eziflow.engine.utils.xml.XPathGenerator;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EziFlowException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	private Node node;

	public EziFlowException(String message) {
		super(message);
	}
	
	public EziFlowException(String message, Node node) {
		super(message);
		this.node = node;
	}

	public EziFlowException(String message, Throwable throwable) {
		super(message, throwable);
	}

    public EziFlowException(ErrorMessageInfo info) {
    	this(ErrorMessages.instance().getMessage(info));
     }
    
    public EziFlowException(ErrorMessageInfo info, Node node) {
    	this(ErrorMessages.instance().getMessage(info), node);
     }
    
    public EziFlowException(ErrorMessageInfo info, Throwable throwable) {
        this(ErrorMessages.instance().getMessage(info), throwable);
    }
    
    public EziFlowException(ErrorMessageInfo info, Throwable throwable, Node node) {
        this(ErrorMessages.instance().getMessage(info), throwable);
        this.node = node;
    }

	public void loggingThrow() {
		logging();
		throw this;
	}

	public void logging() {
		log.error(StackTraceFormatter.getCompleteStackTrace(getCause()));
	}

	@Override
	public String toString() {
		String output = super.toString();
		return (node != null) ? output + " [" + XPathGenerator.generateXPath(node) + "]" : output;
	}
}
