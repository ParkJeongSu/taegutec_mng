package ezieco.eziflow.engine.fault;

import ezieco.eziflow.engine.action.Action;

public interface Faultable {
	Action getFaultAction();

	void setFaultAction(Action action);
}
